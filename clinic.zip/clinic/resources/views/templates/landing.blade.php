<!doctype html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<meta name="csrf-token" content="{{ csrf_token() }}">
	<link type="text/css" rel="stylesheet" href="{!! URL::asset('css/materialize.min.css') !!}"  media="screen,projection"/>
	<link type="text/css" rel="stylesheet" href="{!! URL::asset('css/style.css') !!}"  media="screen,projection"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>

	<!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> -->
	
	<script type="text/javascript" src="{!! URL::asset('js/jquery-2.1.1.min.js') !!}"></script>
    <script type="text/javascript" src="{!! URL::asset('js/materialize.min.js') !!}"></script>
	<title>
		{{ $title }}
	</title>
</head>
<body onload="startTime()">
	<header>
		<div class="date-time white-text" style="padding-left: 0px; text-align:center;">
			<div class="date" >
				<p id="date"></p>
			</div>
			<div class="time" id="time"></div>
		
		</div>
	</header>
    <div class="container">
        @yield('content')
    </div>
     <footer>
     	
     			<span>Bacabac Clinic | Copyright 2015</span>
         	
    </footer>

    <script>

	    function startTime() {
	    var today=new Date();
	    var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
	    var months = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
	    var day = ("0" + today.getDate()).slice(-2).toString();
	    var month = today.getMonth();
	    var year = today.getFullYear();
	    var h=today.getHours();
	    var m=today.getMinutes();
	    var s=today.getSeconds();
	    m = checkTime(m);
	    s = checkTime(s);
	    var timeCat = 'AM';
	    var hours;
	    if(h>12){
	    	timeCat = 'PM';
	    	hours = h-12;
	    }else{
	    	h = checkTime(h);
	    	hours = h;
	    }
	        
	    document.getElementById('time').innerHTML = hours+":"+m+":"+s + " " + timeCat;
	    document.getElementById('date').innerHTML = months[today.getMonth()] + " " + day + " " + year + " | " + days[today.getDay()];
	    var t = setTimeout(function(){startTime()},500);
		}

		function checkTime(i) {
		    if (i<10) {i = "0" + i};  // add zero in front of numbers < 10
		    return i;
		}
		
    </script>

</body>
</html>