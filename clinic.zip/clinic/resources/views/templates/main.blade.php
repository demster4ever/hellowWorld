<!doctype html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<meta name="csrf-token" content="{{ csrf_token() }}">
	<link type="text/css" rel="stylesheet" href="{!! URL::asset('css/materialize.min.css') !!}"  media="screen,projection,print"/>
	<link type="text/css" rel="stylesheet" href="{!! URL::asset('css/pagination_style.css') !!}"  media="screen,projection,print"/>
	<link type="text/css" rel="stylesheet" href="{!! URL::asset('css/style.css') !!}"/>
	<script type="text/javascript" src="{!! URL::asset('js/jquery-2.1.1.min.js') !!}"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<script src="{!!  URL::asset('js/socket.io.js') !!}"></script>
	<script src="{!!  URL::asset('js/angular.js') !!}"></script>
	<script src="{!!  URL::asset('js/app.js') !!}"></script>
	<script src="{!!  URL::asset('js/app2.js') !!}"></script>
	<script type="text/javascript" src="{!! URL::asset('js/materialize.min.js') !!}"></script>

	<link type="text/css" rel="stylesheet" href="{!! URL::asset('jquery-ui-1.11.4/jquery-ui.css') !!}"  media="screen,projection,print"/>
	<!--<script type="text/javascript" src="{!! URL::asset('jquery-ui-1.11.4/external/jquery/jquery.js') !!}"></script>-->
	<script type="text/javascript" src="{!! URL::asset('jquery-ui-1.11.4/jquery-ui.js') !!}"></script>

	<!--<script src="{!!  URL::asset('js/ui-bootstrap-tpls-0.13.4.js') !!}"></script>-->
</head>
<div class="js">
<body>
	<div id="preloader"></div>
	<div class="wrapper">
		<nav class="grey darken-4">
			<ul id="nav-mobile" class="side-nav fixed grey darken-4" style="width: 240px;">
				<div class="card teal" style="width: 240px;color:inherit;">
				 	<!-- <li class="teal white-text">
				 		<nav class="white-text">
					          <h2><a class="page-title center">Bacabac Clinic</a></h2>
					    </nav>
				 	</li> -->
				 	<li class="teal">
				 		<div class="card-content center">
				 			<!-- <i class="material-icons large">account_circle</i> -->
				 			 <h6 class="condensed light">BACABAC CLINIC</h6>
				 	@if(Session::has('img'))
				 			<div class="avatar" style="background-image: url('{!!  URL::asset(''.Session::get('img')) !!}');">	 				
				 					<!-- <img src="{!!  URL::asset(''.Session::get('img')) !!}" class=""> -->
				 				
				 			 				
				 			</div>
					@endif
							@if(Session::has('name'))
							<h5>{!! Session::get('name') !!}</h5>
							@endif
						</div>
				 	</li>
				 	<li class="teal white-text">
				 		<div class="collection" style="margin-bottom: 10px;margin-top: -15;">
					    <a href="#!" class="collection-item" style="height: 24px;">Patients Left<span class="new badge orange darken-4" id="p_waiting">
					    	@if(Session::has('pWait'))
							
							    {!! Session::get('pWait') !!}
							
							@endif
					    	

					    </span></a>
					    <!-- <a href="#!" class="collection-item">New Patients<span class="new badge">4</span></a>
					    <a href="#!" class="collection-item">Alan<span class="badge">14</span></a> -->
					  	</div>
					  	<!-- <a class="waves-effect waves-light btn print-window">Print Page</a>-->	 
					  	<!-- <button onclick="openWindow()">Try it</button>  -->
				 	</li>
				</div>

				<div class="side grey lighten-4">

		            <div class="scroller white-text">
				 	
				     <ul class="collapsible main-nav-list navigation black-text" data-collapsible="accordion">

				      	<!--Main-->
				      	<li class="nav_btn">
				 			<a href="{!! URL::route('main_index')!!}" class="collapsible-header" onClick="loadPreloader;">
				 				<i class="small icon material-icons mdi-action-dashboard" style="margin-bottom: 10px;margin-top: 0px;
								"></i>Dashboard</a>
					 	</li>


					 	<!--Appointments-->
						<li class="nav_btn">
					 		<a href="{!! URL::route('cur_appt')!!}" class="collapsible-header" onClick="loadPreloader;">
					 			<i class="small icon material-icons mdi-action-assignment-ind" style="margin-bottom: 10px;
								    margin-top: 0px;"></i>Appointments</a>
					 	</li>
					 			
			

					 	<!--Patients-->
				  		
					    <li>

					      <div class="collapsible-header nav_btn"><i class="mdi-social-person"></i>Patients </div>

					      <div class="collapsible-body">

								<ul class="collapsible" data-collapsible="accordion">
					  		
								    <li class="nav_btn">

			              				<a  href="{!! URL::route('add_patient') !!}"><i class="left material-icons mdi-social-person-add"style="margin-top: 19px; margin-bottom: 10px;"></i>New Patient</a>

								    </li>

								    <li class="nav_btn">

			              				<a href="{!! URL::route('view_patients') !!}"><i class="left material-icons mdi-social-people" style="margin-top: 19px; margin-bottom: 10px;"></i>Patient List</a>

								    </li>

								   
								</ul>

					      </div>

					    </li>
				   
				
				        <!--Reports-->
				       <!--  <li class="nav_btn">

					      <div class="collapsible-header nav_btn"><i class="mdi-action-view-list"></i>Reports</div>		       
					          <div class="collapsible-body">

					            <ul class="collapsible" data-collapsible="accordion" >

					            	<li class="nav_btn">

			              				<a  href="#"><i class="left material-icons mdi-maps-local-pharmacy"style="margin-top: 19px; margin-bottom: 10px;"></i>Laboratories</a>

								    </li>

								    <li class="nav_btn">

			              				<a  href="#"><i class="left material-icons mdi-notification-event-note"style="margin-top: 19px; margin-bottom: 10px;"></i>Appointments</a>

								    </li>

								    <li class="nav_btn">

			              				<a  href="#"><i class="left material-icons mdi-editor-attach-money"style="margin-top: 19px; margin-bottom: 10px;"></i>Billing</a>

								    </li>
						        
					            </ul>

					          </div>

				        </li> -->

				   

				        <!--Admin-->
				        <li class="nav_btn">

				        	<div class="collapsible-header nav_btn"><i class="mdi-action-settings-applications"></i>Admin</div>		         

				          <div class="collapsible-body">

					          
				          		<ul class="collapsible" data-collapsible="accordion">						    		       

									 <li class="inside-nav white black-text">

									     <div class="collapsible-header nav_btn"><i class="left material-icons mdi-maps-local-pharmacy" style="margin: 0 1rem 0 1rem;"></i>Laboratory Test</div>

									      <div class="collapsible-body black-text" style="color:#000;">

												<ul class="collapsible main-nav-list " data-collapsible="accordion">
									  		
												    <li class="nav_btn" style"">

							              				<a class="collapsible-header black-text" href="{!! URL::route('group') !!}"><i class="left material-icons mdi-content-add-circle-outline"style="margin-top: 19px; margin-bottom: 10px; margin: 0 1rem 0 1rem;"></i>Test Group</a>

												    </li>

												    <li class="nav_btn ">
														<a class="collapsible-header black-text" href="{!! URL::route('sub') !!}"><i class="left material-icons mdi-content-add-circle-outline"style="margin-top: 19px; margin-bottom: 10px; margin: 0 1rem 0 1rem;"></i>Sub Test Group</a>

												    </li>

												     <li class="nav_btn ">

							              				<a class="collapsible-header black-text" href="{!! URL::route('labtest') !!}"><i class="left material-icons mdi-content-add-circle-outline" style="margin-top: 19px; margin-bottom: 10px; margin: 0 1rem 0 1rem;"></i>Detailed Test</a>

												    </li>
												</ul>

									      </div>
				
					    			</li>
								
								    <li class="nav_btn">

			              				<a  href="{!! URL::route('medicines') !!}"><i class="left material-icons mdi-notification-event-note"style="margin-top: 19px; margin-bottom: 10px;"></i>Medicines</a>

								    </li>

								   <!--  <li class="nav_btn">

			              				<a  href="#"><i class="left material-icons mdi-content-content-paste"style="margin-top: 19px; margin-bottom: 10px;"></i>Diseases</a>

								    </li>

								     <li class="nav_btn">

			              				<a  href="#"><i class="left material-icons mdi-editor-attach-money"style="margin-top: 19px; margin-bottom: 10px;"></i>Charges</a>

								    </li> -->
						        
					            </ul>          
				         
				          </div>
				        </li> 
				        <!--Logout-->
				        <li class="nav_btn">

				    		<a class="collapsible-header" href="{!! URL::route('help') !!}"><i class="small material-icons mdi-communication-live-help" style="margin-bottom: 10px;margin-top: 0px;
								"></i>Help</a>
				    	</li>

				        <!--Logout-->
				        <li class="nav_btn">

				    		<a class="collapsible-header " href="#"  onClick="logout()"><i class="small material-icons mdi-action-settings-power" style="margin-bottom: 10px;margin-top: 0px;
								"></i>Logout</a>
				    	</li>
				      </ul>
				  </div>
				  </div>
		 	</ul>
		</nav>
		
		<header style=" background-color: black;opacity: 0.5;">
			@yield('header')

			<p class="flow-text">

			<div class="date-time white-text col " >
				<div class="date" >
					<p id="date"></p>
				</div>
			
				<h4 style="margin-top:-4px; color: green;"><div class="time" id="time">
								
				</div></h4>

				<!-- <div class="search-box">
					<div class="box-300">
						@include('layouts.partials.search')
					</div>
				</div> -->
			</div>
			</p>
		
		</header>

		<div class="content-container">
			<div class="row">
				<div class="borderbar col s8 offset-s2">    	
			    	<nav class="teal" style="padding:0px;">
					    <div class="nav-wrapper">

					      {!! Form::open(array('url' => '/patient/search')) !!}
					        
						        <div class="input-field">
						          		<input id="search" type="search" name="search_input" placeholder="Search Patient Name" required >
						          		<label for="search"><i class="material-icons mdi-action-search"></i></label>
						        </div>
						     		        
					      {!! Form::close() !!}
					    </div>
					</nav>
				</div>
			</div>
		        @yield('content')
		        @yield('message')
	    </div>
	    
	    <footer class="teal">
	    	<div class="row">
				<div class="col s6 offset-s4">  
		    		Bacabac Clinic | Copyright 2015
		    	</div>
	    	</div>
	    </footer>
	  
	</div>

 <!-- Modal Trigger -->
  

  <!-- Modal Structure -->

  <div id="logout" title="Logout">
    <div>
      <p>You are about to logout. Would like to proceed?</p>
      <br>
    </div>
    <div class="modal-footer white-text">
     
      <a href="#" style="float:right;" class="white-text modal-action modal-close waves-effect waves-green red btn-flat" onClick="cancelLogout()">No</a>
      <a href="{!! URL::route('index') !!}" style="float:right;" class="white-text modal-action modal-close waves-effect waves-green green btn-flat">Yes</a>
    </div>
  </div>


	<!-- {!! HTML::script('js/jquery.js') !!}
	{!! HTML::script('js/jquery-ui.js') !!} -->
	<script type="text/javascript">
	  	
	 	/**/
	  	/*$('.Trigger-logout').leanModal({
	      dismissible: true, // Modal can be dismissed by clicking outside of the modal
	      opacity: .5, // Opacity of modal background
	      in_duration: 300, // Transition in duration
	      out_duration: 200, // Transition out duration
	     
	     	}

	  	 );*/
	  	
	    
	    function logout() {
	    	$( "#logout" ).dialog( "open" );
	    }
	    function cancelLogout() {
	    	$( "#logout" ).dialog( "close" );
	    }

	    function openWindow() {
    		window.open("http://192.168.254.5/clinic/public/doc/medcert", "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=0, left=0, width=1050, height=750");
    	}
    	
    	function openPrescriptions() {
    		window.open("http://192.168.254.5/clinic/public/doc/presc", "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=0, left=0, width=1050, height=750");
    	}

    	function openFitToWork() {
    		window.open("http://192.168.254.5/clinic/public/doc/ftw", "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=0, left=0, width=1050, height=750");
    	}
    </script>
	@yield('autosearch')

	<script>

		jQuery(document).ready(function($) {  

		$(window).load(function(){
			$('#preloader').fadeOut('slow',function(){$(this).remove();});
			$( "#logout" ).dialog({
			  movable: false,
		      resizable: false,
		      closeOnEscape: false,
		      autoOpen:false,
		      position: { my: "top", at: "top", of: window },
		      modal: true,
		      width: 700,
		      /*buttons: {
		        "Delete all items": function() {
		          $( this ).dialog( "close" );
		        },
		        Cancel: function() {
		          $( this ).dialog( "close" );
		        }
		      }*/
		    });
			startTime();
		});

		 $('ul.tabs').tabs();


		});

	    function startTime() {
		    var today=new Date();
		    var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
		    var months = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
		    var day = ("0" + today.getDate()).slice(-2).toString();
		    var month = today.getMonth();
		    var year = today.getFullYear();
		    var h=today.getHours();
		    var m=today.getMinutes();
		    var s=today.getSeconds();
		    m = checkTime(m);
		    s = checkTime(s);
		    var timeCat = 'AM';
		    var hours;
		    if(h>12){
		    	timeCat = 'PM';
		    	hours = h-12;
		    }else{
		    	h = checkTime(h);
		    	hours = h;
		    }
		        
		    document.getElementById('time').innerHTML = hours+":"+m+":"+s + " " + timeCat;
		    document.getElementById('date').innerHTML = months[today.getMonth()] + " " + day + " " + year + " | " + days[today.getDay()];
		    var t = setTimeout(function(){startTime()},500);
		}

		function checkTime(i) {
		    if (i<10) {i = "0" + i};  // add zero in front of numbers < 10
		    return i;
		}

		$('.print-window').click(function() {
		    window.print();
		});


		function loadPreloader(){
			var iDiv = document.createElement('div');
			iDiv.id = 'preloader';
			document.getElementsByTagName('body')[0].appendChild(iDiv);
		}

    </script>
    
    <script>
       
		var socket = io('http://192.168.254.5:3000');
		//var socket = io('http://192.168.1.3:3000');

        socket.on("test-channel:App\\Events\\LoginEvent", function(message){
                document.getElementById('p_waiting').innerHTML = message.user.p_waiting;
        });

        socket.on("test-channel:App\\Events\\NewEntryEvent", function(message){
        		Materialize.toast('<span>New Patient </span>', 6000);
                
        });

    </script>

</body>
</div>
</html>