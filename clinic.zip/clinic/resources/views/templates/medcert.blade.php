<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<script type="text/javascript" src="{!! URL::asset('js/jquery-2.1.1.min.js') !!}"></script>
	<link rel="stylesheet" type="text/css" href="{!! URL::asset('css/style_med_cert.css') !!}" media="screen,projection,print">
	<title>Release Document</title>
</head>
	<body>
		<div class="content-warp">
			@yield('content')

		</div>


	</body>
</html>