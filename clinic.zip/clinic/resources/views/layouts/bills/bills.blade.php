@extends('templates/main')
{!! Html::style('css/style.css') !!} 

@section('search')
		<span >
			<input name="search_input"  type="text" placeholder="Search Patient">
			{!! Form::submit('Search')!!}
		</span>
@endsection
@section('content')

<div class="page">
	<div class="row">
		<div class="billing-content col s6">
			<div class="billing-header grey darken-4">
				<div class="billing-id-container col s7">
					<h5>Billing ID: <d>{!! $billing->id !!}</d> </h5>
				</div>
				<div class="billing-date-container col 5">
					<h5>Date: <d class="truncate">{!! $billing->billing_date !!}</d></h5>
				</div>
			</div>
			<div class="billing-name-container">
				<div class="billing-patient-id-container">
					<h5>Patient's Id:<d> {!! $patient->patient_id !!}</d></h5>
				</div>
				<div class="billing-patient-name-container">
					<h5>Patient's Name: <d>{!! $patient->first_name !!} {!! $patient->last_name !!}</d></h5>
				</div>
			</div>
			<div class="billing-details">
			
				<div class="billing-description-header s-border-l s-border-r grey lighten-2 ">

					<div class="bill-desc-head desciption col s8">Charge Description</div>
				    <div class="bill-desc-head2 col s4">amount</div>

				</div>
				<div class="billing-description-content">

					<ul class="collection col s12">
					@if (count($bills) > 0)
						@foreach($bills as $bill)	
					      <li class="collection-item col s12">
					      	<div class="desciption col s8">{!! $bill->charge_description !!}</div>
					      	<div class="price col s4 s-border-l" style="color:blue; font-style: italic;">Php {!! $bill->amount !!}</div>

					      </li>
				      	@endforeach
				    @else
				    	
				    	<li class="collection-item col s12">
					      	<div class="desciption col s8" style="text-align:center; font-style: italic;">Nothing to display charges.</div>
					      	<div class="col s4 s-border-l" style="text-align:center; font-style: italic;">n/a</div>
					     </li>
					@endif
				    </ul>


				</div>
				
				<div class="total-bill col s12">

					<div class="total col s8">Total</div>
				    <div class="price col s4" style="color:green; font-size:1.5rem; font-style: bold-italic;">
				    	@if(count($total) > 0)
				    		<div>{!! $total !!}</div>
				  		@else
				  			<div style="text-align:center;">n/a</div>
				  		@endif
				    </div>

				</div>
				<div class="payment col s12">
					{!! Form::open(array('route'=> 'paybill')) !!}
					<div class="cash col s12">
						<span class="col s6">Amount Rendered:</span>
						<input type="text" name="amount" class="col s6" placeholder="0.00" style="font-size:2rem;" >
						<input type="hidden" name="billing_date" value="{!! $billing->billing_date !!}">
						<input type="hidden" name="id" value="{!! $billing->id !!}">
					</div>
					<div class="none-bold col s12">
					    <button class="btn waves-effect waves-light col s2 offset-s10 " type="submit" name="action">pay
						 <i class="mdi-editor-attach-money left"></i>
						</button>
					</div>
					{!! Form::close() !!}	
						

				</div>


			</div>	
				
		</div>
	</div>
</div>

<script type="text/javascript" src="{!! URL::asset('js/materialize.min.js') !!}"></script>		

@endsection
