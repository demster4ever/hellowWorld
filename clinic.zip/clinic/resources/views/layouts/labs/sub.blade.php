@extends('templates/main')
{!! Html::style('css/style.css') !!} 

@section('content')
	
<div class="page">
<div class="content">
	<div class="row">
		<div class="card col s12">		
		   <div class="row">
			 <div class="">

			 	<div class="vital-header grey darken-4"><d class="orange-text">Test Sub Groups</d></div>
			 	
		 	  <table class="striped">
		        <thead class="">
		          <tr class="">

		          	  <th class="col s1" data-field="test_id">Test Id</th>           
		              <th class="col s3"data-field="test_name">Sub Test Name</th>
		              <th class="col s3"data-field="remarks"> Description</th>
		              <th class="col s3"data-field="group_name"> Group</th>
		              <th class="col s2"data-field="remarks"> Actions</th>

		          </tr>
		        </thead>

		     </table>

			<div class="scroller2">

				<table class="striped">

			      	<tbody>
				          @foreach( $test_sub_group as $sub_group)
				          {!! Form::open(array('route' => 'sgroupup'))!!}
					          <tr>
					          	
					          	<td class="col s1">{!! $sub_group->id !!}</td>
					            <td class="col s3"><input type="text" name="sgroup_name" value="{!! $sub_group->name !!}"> </td>		           
					            <td class="col s3"><input type="text" name="sgroup_description" value="{!! $sub_group->description !!}"></td>
					            <td class="col s3">{!! $sub_group->group_name !!}</td>			           
								<td class="col s2">

									
									 	<button type="submit"  class="tooltipped green btn-flat" id="update" data-position="top" data-delay="50" data-tooltip="Update" >
											<i class="white-text large mdi-content-save" ></i>
										</button>
									

									
										<a href="{!! URL::route('sgroupdel',array('id' => $sub_group->id)) !!}" class="tooltipped red btn-flat" id="delete" data-position="top" data-delay="50" data-tooltip="Delete" >
											<i class="white-text large mdi-action-delete" ></i>
										</a>
									
									<input type="hidden" name="test_id" value="{!! $sub_group->id !!}">
								</td>
								
					          </tr>

					         {!! Form::close() !!}
				         @endforeach

			          
					</tbody>
				</table>
			</div>
			<a class="waves-effect waves-light btn modal-trigger" href="#mod" id="modal-trigger">New Sub Test Group</a>
				</div>
			</div>
			
		</div>
	</div>
</div>
</div>


		
			 <!-- Modal Structure -->

			 	
			  <div id="mod" class="sub-test-add-modal modal">
			    <div class="modal-content row" style="margin:0;">
			     <!-- <form class="col s12">  -->
					{!! Form::open(array('url' => 'save_subtest')) !!} 
					<div class="">
  				
					      
					       <div class="input-field col s12 teal">
						         	<h4 class="white-text"style="margin-bottom: 0px;padding-top: 5px;padding-bottom: 5px;">Sub Test Add</h4>
					        </div>

		
							  						  	
	 							<div class="input-field col s12 s-border-t s-border-b s-border-l s-border-r">

								<select class="browser-default" name="group_name" value="">
									@foreach($test_group as $group)
									<option value={!!$group->id!!}>{!! $group->group_name !!}</option>
									@endforeach
								</select>											

						        </div>
						  
						  	
	 							<div class="input-field col s12">
						          <input id="sub_group_test_name" name="sub_name" type="text" class="validate">
						          <label for="sub_group_test_name">Name</label>	     	
						        </div>
						     

						
						        <div class="input-field col s12">
						    		 <textarea id="sub_group_test_desc" class="materialize-textarea"name="sub_description"></textarea><label for="sub_group_test_desc">Description</label>	     	
						        </div>
					       

					    	<div class="col s6 offset-s6">

							    <button class="col s5  btn waves-effect waves-light green tooltipped" data-position="bottom" data-delay="50" data-tooltip="save" type="submit" name="action">
								    <i class="mdi-content-save left" ></i>save
								</button>

					    		<div class="col s5 offset-s1 modal-action modal-close btn red tooltipped" data-position="bottom" data-delay="50" data-tooltip="Cancel" >
					    		 	<i class="mdi-navigation-cancel left"></i>Cancel
					    		</div>
						    	
					    	</div>
					     					       
						</div>

					{!! Form::close() !!}
				<!-- </form> -->

	  		 		</div>
			    </div>
		
	<script type="text/javascript" src="{!! URL::asset('js/materialize.min.js') !!}"></script>
	
	<script>
	
            $('.modal-trigger').leanModal({
		      dismissible: true, // Modal can be dismissed by clicking outside of the modal
		      opacity: .3, // Opacity of modal background
		      in_duration: 300, // Transition in duration
		      out_duration: 200, // Transition out duration
		      
		     	}
		  	 );

    </script>
</div>
</div>


@endsection