@extends('templates/main')
{!! Html::style('css/style.css') !!} 

@section('content')
	
<div class="page">
	<div>
		<div class="content">
			<div class="row">
				<div class="card col s12">		
				    <div class="row">
					    <div class="">

				    		<div class="vital-header grey darken-4"><d class="orange-text">Test Groups</d></div>


						    <div class="scroller2">

						 	    <table class="striped">
								 	  	<thead>
								          <tr>
								          	  <td data-field="test_name">Test Id</td>		              
								              <td data-field="test_name"> Test Name</td>
								              <td data-field="remarks"> Description</td>
								              <td data-field="remarks"> Actions</td>
								          </tr>
								        </thead>	
							      	<tbody >
							      	
							      	@foreach( $test_group as $group)
							      		{!! Form::open(array('route' => 'groupup'))!!}
							         	<tr>
								          	<td class="col s1">{!! $group->id !!}</td>
								            <td class="col s4"><input type="text" id="group_name" name="group_name" value="{!! $group->group_name !!}"></td>		           
								            <td class="col s5"><input type="text" id="group_description" name="group_description" value="{!! $group->group_description !!}">
								            </td>		           
											<td class="butn-td col s3">
											
											 	<button type="submit"  class="tooltipped green btn-flat" id="update" data-position="left" data-delay="50" data-tooltip="Update" >
													<i class="white-text large mdi-content-save" ></i>
												</button>
											            
												
												<a href="{!! URL::route('groupdel',array('id' => $group->id)) !!}" class="tooltipped red btn-flat" id="delete" data-position="right" data-delay="50" data-tooltip="Delete" >
													<i class="white-text large mdi-action-delete" ></i>
												</a>
												
											</td>
											<input type="hidden" name="test_id" value="{!! $group->id !!}">
										
							          	</tr>
							          	{!! Form::close() !!}
							         @endforeach
							       	 
									</tbody>
								</table>
							</div>

							<a class="waves-effect waves-light btn modal-trigger" href="#mod" id="modal-trigger">New Test Group</a>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		<!-- </div> -->
			 	
		<div id="mod" class="group-test-add-modal modal">
			<div class="modal-content row" style="margin:0;">

				{!! Form::open(array('url' => 'save_testgroup')) !!} 		 

			        <div class="input-field col s12 teal">
				         	<h4 class="white-text"style="margin-bottom: 0px;padding-top: 5px;padding-bottom: 5px;">Group Test Add</h4>
			        </div>

					<div class="input-field col s12 ">
			          <input id="sub_group_test_name" name="name" type="text" class="validate">
			          <label for="sub_group_test_name">Name</label>	     	
		        	</div>
		     
			      
			        <div class="input-field col s12 ">
			    		 <textarea id="sub_group_test_desc" name="description" class="materialize-textarea" length="120"></textarea><label for="sub_group_test_desc">Description</label>	     	
			        
			        </div>
			     
			    	<div class="col s6 offset-s6">

					    <button class="col s5  btn waves-effect waves-light green tooltipped" data-position="bottom" data-delay="50" data-tooltip="save" type="submit" name="action">
						    <i class="mdi-content-save left" ></i>save
						</button>	

			    		<div class="col s5 offset-s1 modal-action modal-close btn red tooltipped" data-position="bottom" data-delay="50" data-tooltip="Cancel" >
			    		 	<i class="mdi-navigation-cancel left"></i>Cancel
			    		</div>

			    		
					   
			    	</div>

				{!! Form::close() !!}
				
		 	</div>

		</div>
    
	</div>
</div>
<script type="text/javascript" src="{!! URL::asset('js/materialize.min.js') !!}"></script>
	
<script>
 	/**/
  	$('.modal-trigger').leanModal({
      dismissible: true, // Modal can be dismissed by clicking outside of the modal
      opacity: .5, // Opacity of modal background
      in_duration: 300, // Transition in duration
      out_duration: 200, // Transition out duration
      
     	}
  	 );

  	// $('#update').click(function(){
  	// 	$.ajax({
   //          url: '{!! URL('groupUp/') !!}',
   //          type: 'POST',
   //          data: { id:$('#test_id').val(), group_name: $('#group_name').val(), group_description: $('#group_description').val()}, 
            
   //      });

  	// });


    </script>

@endsection


