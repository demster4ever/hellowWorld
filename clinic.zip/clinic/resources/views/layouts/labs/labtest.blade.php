@extends('templates/main')
{!! Html::style('css/style.css') !!} 

@section('content')
	
<div class="page">
	<div class="content">
		<div class="row">
			<div class="card col s12">		
			   <div class="row">
				 <div class="">

				 	<div class="vital-header grey darken-4"><d class="orange-text">Tests</d></div>

				 	  <table class="striped">
				        <thead>
				          <tr>	
				          	  <th class="col s1"data-field="test_id">Id</th>	              
				              <th class="col s3" data-field="test_name">Lab Test Name</th>
				              <th class="col s3"class="col s1"data-field="remarks"> Description</th>
				              <th class="col s1"class="col s1"class="col s1"data-field="remarks"> Units</th>
							  <th class="col s2" data-field="remarks"> Range</th>
				              <th class="col s2" data-field="remarks"> Actions</th>
				          </tr>
				        </thead>
				      
				      </table>

				    <div class="scroller2">

				       <table class="striped">
				       	<tbody>
						@foreach( $test as $t)
						
							{!! Form::open(array('route' => 'testup'))!!}
					          <tr>
					          	<td class="col s1">{!! $t->id !!}</td>
					            <td class="col s3"><input type="text" name="name" value="{!! $t->name !!}"> </td>		           
					            <td class="col s3"><input type="text" name="description" value="{!! $t->description !!}"></td>
					            <td class="col s1"><input type="text" name="units" value="{!! $t->units !!}"></td>
					            <td class="col s2"><input type="text" name="range" value="{!! $t->range !!}"></td>			           
								<td class="col s2">
									 <button type="submit"  class="tooltipped green btn-flat" id="update" data-position="top" data-delay="50" data-tooltip="Update" >
										<i class="white-text large mdi-content-save" ></i>
									</button>
									
									<a href="{!! URL::route('testdel',array('id' => $t->id)) !!}" class="tooltipped red btn-flat" id="delete" data-position="top" data-delay="50" data-tooltip="Delete" >
										<i class="white-text large mdi-action-delete" ></i>
									</a>
								
								</td>
								<input type="hidden" name="test_id" value="{!! $t->id !!}">
					          </tr>
				          	{!! Form::close() !!}

				        @endforeach
				          
					</tbody>
					</table>
				</div>
					<a class="waves-effect waves-light btn modal-trigger" href="#mod" id="modal-trigger">New Test</a>
				  </div>
				</div>
				
			</div>
		</div>
	</div>
	</div>
	 		 
				 <!-- Modal Structure -->

				 	
				  <div id="mod" class="test-add-modal modal ">
				    <div class="modal-content row">
				     {!! Form::open(array('url' => 'save_test')) !!} 		  
						 
						 	 
					       <div class="input-field col s12 teal">
						         	<h4 class="white-text"style="margin-bottom: 0px;padding-top: 5px;padding-bottom: 5px;">New Laboratory Test</h4>
					        </div>
						     

								 				  	
 							<div class="input-field col s12" style="s-border-t s-border-b s-border-l s-border-r">

								<select class="browser-default" name="sub_id">
									@foreach($test_sub_group as $sgroup)
									<option value={!!$sgroup->id!!}>{!! $sgroup->name !!}</option>
									@endforeach
								</select>											

					        </div>
							      

							     				  	
 							<div class="input-field col s12">
					          <input id="test_name" name="name" type="text" class="validate">
					          <label for="test_name">Test Name</label>	     	
					        </div>
					      

												  	
 							<div class="input-field col s12">
					          <input id="test_desc" name="description" type="text" class="">
					          <label for="test_desc">Test Description</label>	     	
					        </div>
					     

					   
					      	<div class="input-field col s6" >
					          <input id="test_units" name="units" type="text" class="validate">
					          <label for="test_units">Test Units</label>	     	
					        </div>						  	
 							<div class="input-field col s6 ">
					          <input id="test_range" name="range" type="text" class="validate">
					          <label for="test_range">Test Range</label>	     	
					        </div>
					     
						

					    <div class="col s6 offset-s6">
							    		
					    		
							    	
							    	
					    		<button class="col s5 btn waves-effect waves-light green tooltipped" data-position="bottom" data-delay="50" data-tooltip="save" type="submit" name="action">
								    <i class="mdi-content-save left" ></i>save
								</button>
							    		 
								<div class="col s5 offset-s1 modal-action modal-close btn red tooltipped" data-position="bottom" data-delay="50" data-tooltip="Cancel" >
					    		 	<i class="mdi-navigation-cancel left"></i>Cancel
					    		</div>

							    	
						    	
					    	</div>
				    	
				       						       
						     					       
						
					 {!! Form::close() !!}
		  		 		</div>
				    </div>
		
			
		<script type="text/javascript" src="{!! URL::asset('js/materialize.min.js') !!}"></script>
			
		<script>

	        $('.modal-trigger').leanModal({
		      dismissible: true, // Modal can be dismissed by clicking outside of the modal
		      opacity: .5, // Opacity of modal background
		      in_duration: 300, // Transition in duration
		      out_duration: 200, // Transition out duration
		      
		     	}
		  	 );
	     
	    </script>
	</div>
</div>


@endsection