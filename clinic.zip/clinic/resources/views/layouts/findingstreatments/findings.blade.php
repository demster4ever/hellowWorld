@extends('templates/main')
<!-- {!! Html::style('css/style.css') !!}  -->


@section('search')
	<span>
	
			<div class="input-field">
			<input name="search_input"  type="text" placeholder="Search Patient" class="validate">
			<a href="#">Search</a>			
			</div>
	</span>
@endsection
@section('content')
	
	<div class="page">
		<!-- {!! Form::open(array('route' => 'add_findings')) !!}
		<div class="block-group">
			<span >
				<input class="block-group" name="findings"  type="text">
				Findings
			</span>
			<span >
				<input class="block-group" name="treatments" placeholder = " " type="text">
				Treatments
			</span>
			
			
		</div>
		
		<div class="block-group">
			{!! Form::submit('Add Findings')!!}
		</div>
		
				
		{!! Form::close() !!} -->
	</div>
@endsection