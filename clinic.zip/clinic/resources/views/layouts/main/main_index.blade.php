@extends('templates/main')
{!! Html::style('css/style.css') !!} 

@section('content')

	<div ng-app='paymentApp' ng-controller='payBillController'>

	
	<div class="page-main" >
		
		<div class="row">

			
			<div>
				@if(count($patients)>0)
					<H5>Today's Patients</H5>
					<div class="main-patient-list-header col s7">
					
						<table class="borderd striped">
					        <thead>
					          <tr class="collection-header orange col s12">
					              <th class="col s1"data-field="actions" style="border-radius:0px;">Action</th>
					              <th class="col  "data-field="status" style="border-radius:0px;"></th>
					              <th class="col s3 offset-s2"data-field="name" style="border-radius:0px;">Patient Name</th>
					              <th class="col s2"data-field="gender" style="border-radius:0px;">Gender</th>
					              <th class="col s3 "data-field="doctor" style="border-radius:0px;">Doctor Assigned</th>
					              <th class="col s1"data-field="status" style="border-radius:0px;">Status</th>
					          </tr>
					        </thead>
					    </table>
					</div>
				@else
					<H5 style="font-style:italic;"> No Patient's Yet.</H5>
				@endif
				
			<div class="main-patient-list col s7">	    
				    <table class="borderd striped">
				        <tbody>
				        	

					        	@foreach($patients as $patient)
						          <tr>
						            <td style="border-radius:0px;"><a href="{!! URL::route('patient', array('id' => $patient->patient_id )) !!}" class="waves-effect waves-light btn" style="text-transform:none;">View</a></td>
						            <td style="border-radius:0px; display:inline-block;"> 
						            	<div class="mini-avatar" >
							 				<img src="{!!  URL::asset(''.$patient->img_path) !!}" class="materialboxed">
							 			</div>

						            </td>
						            <td style="border-radius:0px;text-transform: capitalize;">{!!  $patient->last_name!!}, {!! $patient->first_name; $patient->middle_name!!}</td>
						            <td style="border-radius:0px;">{!!  $patient->gender!!}</td>
						            						            
						            <td style="border-radius:0px;">Noel B. Bacabac, M.D.</td>
						          	@if($patient->status_id == 1)
						            	<td style="border-radius:0px; color:blue;">Waiting</td>
						        	@elseif($patient->status_id == 2)
						        		<td style="border-radius:0px; color:red;">Cancelled</td>
						        	@elseif($patient->status_id == 3)
						        		<td style="border-radius:0px; color:gray;">Done</td>
						        	@else
						        		<td style="border-radius:0px; color:green;">Current</td>
						        	@endif


						          </tr>
						        @endforeach
				         	<tr></tr>
				         						          	
				        </tbody>
				      </table>

			</div>
			
			</div>
			
			<div class="dashboard card row" style="background: none;">

				<!-- status -->
				 <div class="doctor-status col s12">

				 		
						<div class="col s1 orange" style="height:inherit;width: 11px;padding:0;margin-left: -11px;"></div>
						<div class="col s11 orange-text">

						 	
						 	<div  class="col s11"><h6 id="patName" class="truncate" style="text-transform:capitalize;">
						 		@if(count($current_patient)>0)
						 			@foreach($current_patient as $cur_pat)
						 				Patient Id: {!! $cur_pat->patient_id !!}
						 				{!! $cur_pat->last_name !!}, {!! $cur_pat->first_name !!}
						 			@endforeach
						 		@else
								 NONE
								@endif
								</h6>

						 		<p>CONSULTING PATIENT</p>

						 	</div>					 		

					 	</div>
						<!-- <div class="col s1 orange" style="height:inherit;width: 10px;padding:0;"></div>

					 	<div class="avail col s4 orange-text">

					 		<h6 id="docStat" class="red-text">Not available</h6>
					 		<p>the doctor is</p>

					 	</div>	 -->			 	
				 </div>
				<!-- end status -->


				<!-- new patient -->
				<div>
				 <a href="{!! URL::route('add_patient') !!}" class="new-patient-grid col s6" style="text-align: center;">
					<div class="caption center-align">
						<i class="medium mdi-social-person-add"></i>
						<h5>New Patient</h5>
						<h6 class="green-text text-darken-4">Register new patient, click here.</h6>
					</div>
				 		<!-- <h5 class="back"><strong class="red-text" style="margin-top: 10px;">New Patient</strong></h5> -->
				 </a>
				</div>

				<!-- scheduler -->
				<div>
				 	<a id="scheduler" href="#scheduler-modal" data-target="scheduler-modal"  style="text-align: center; " class="modal-trigger scheduler col s6">
				 		<i class="medium mdi-device-access-time"></i>
				 		<h5>Schedule</h5>
						<h6 class="green-text text-darken-4">Set a schedule for patient.</h6>
				 	<!-- <h4 class="back">Scheduler</h4> -->
				 	
				 		<!-- <h5 class="back"><strong style="margin-top: 10px; color: grey">Scheduler</strong></h5> -->


				 	</a>
				</div>
				<br>
				<!-- Patients-->
				<div>
				 <a href="{!! URL::route('view_patients') !!}" class="new-patient-grid col s6" style="text-align: center;">
					<div class="caption center-align">
						<i class="medium mdi-action-face-unlock"></i>
						<h5>Patients</h5>
						<h6 class="green-text text-darken-4">Check patients, click here.</h6>
					</div>
				 		<!-- <h5 class="back"><strong class="red-text" style="margin-top: 10px;">New Patient</strong></h5> -->
				 </a>
				</div>

				<!-- documents -->
				<div>
				 	<a id="releasedocs" href="#"  style="text-align: center;" class="modal-trigger scheduler col s6" data-position="left" data-delay="50" 
				 	data-tooltip="Advise to Rest,Fit to Work, Prescription">
				 		
				 		<i class="medium mdi-content-content-paste"></i>
						<h5>Documents</h5>
						<h6 class="green-text text-darken-4">Release Documents for patient.</h6>
				 	<!-- <h4 class="back">Scheduler</h4> -->
				 		<!-- <h5 class="back"><strong style="margin-top: 10px; color: grey">Scheduler</strong></h5> -->


				 	</a>
				</div>
				
			</div> 

		</div>
					
	</div>
	<div class="pagination-holder row">
				@if (count($patients) > 0)
					{!! str_replace('/?', '?', $patients->render()) !!}
				@endif
			</div>
	<!-- Modal Structure -->

  	<div  id="scheduler-modal" class="modal scheduler-modal row" >
  		<div >
  			<div class="scheduler-modal-header grey darken-4"><d class="orange-text">Scheduler</d></div>
			<nav>
			    <div class="nav-wrapper">
			      <form ng-submit="search()" >
			        <div class="input-field">
			          <input id="search" type="search" ng-model="name" required placeholder="Search Name or Last Name">
			          <label for="search"><i class="mdi-action-search"></i></label>			          
			          <input type="submit" style="position: absolute; left: -9999px; width: 1px; height: 1px;"/>
			        </div>
			      </form>
			    </div>
			</nav>

		    <div class="result-header" >
				<ul class="collection col s12 ">
					<!-- header results -->
			        <li class="collection-item row s-border-b">
			        	<div class=" col s5">Patient Name</div>
			        	<div class="s-border-l col s7">Schedule</div>
			        </li>
			    </ul>
			</div>
	        <!-- end header results -->
	        <div class="result-scroller" style="height: 60%;">

	        	<ul class="collection col s12 ">

		        <li class="collection-item" style="padding-top:3px;" ng-repeat='schedule in schedules'>
		        	
		        	
		        	{!! Form::open(array('route' => 'schedule')) !!}
			        	<div class="shceduler-date-holder col s12 ">
								<div class="col s5 truncate">
									<% schedule.first_name %> <% schedule.last_name %>
								</div>
			        			<div class="col s7">
			        				
				        		
				        			<select name="month" style="height: 40px;" class="col s3 browser-default s-border-b s-border-t s-border-l s-border-r">
								      <option value="" disabled selected>Month</option>
								      <?php  
								      		$months = array('','Jan','Feb', 'Mar', 'Apr','May', 'Jun', 'Jul',
								      		 'Aug','Sept','Oct','Nov','Dec');
									        for($i=1; $i<13; $i++)
									        { 
									        	$num_padded = sprintf("%02d", $i);
									      		echo "<option value=$num_padded>$months[$i]</option>";
									  		} 
								  		?>

								    </select>

				        			<select name="day" style="height: 40px;" class="col s3 browser-default s-border-b s-border-r s-border-t">
								      <option value="" disabled selected>Day</option>
								       <?php  
									        for($i=1; $i<=31; $i++)
									        { 
									      		 echo "<option value=$i>$i</option>";
									  		} 
								  		?>
								    </select>
								    <select name="year" style="height: 40px;" class="col s4 browser-default s-border-b s-border-l s-border-t ">
								      <option value="" disabled selected>Year</option>
								        <?php  
									        for($i=2016; $i<=2030; $i++)
									        { 
									      		 echo "<option value=$i>$i</option>";
									  		} 
								  		?>
								    
								    </select>

				        			
				       
					        		<button class="btn-flat col s1 offset-s1 green tooltipped white-text" type="submit" data-position="left" data-delay="50" data-tooltip="Schedule" style="margin-left: 30px;height: 31px;width: 40px;float: right;">
										<i class="small mdi-navigation-check "></i>
									</button>
									<input type="hidden" name="id" value="<% schedule.patient_id %>">
			        			</div>
							    
						</div>
					
		        	{!! Form::close() !!}
		        	
		        </li>

				</ul>
			</div>

		    <div class="modal-foot">
				<a href="{!! URL::route('add_patient') !!}" class=" modal-action modal-close waves-effect waves-green btn">Add patient</a>
			    <a href="#!" class=" modal-action modal-close waves-effect waves-green btn">Cancel</a>
		    </div> 

		</div>
     
  	</div>

  	</div>
  
  	</div>

  	<!-- ===documents=== -->

  	<div  id="docs"  title="Documents">
	  	<div class="card row" style="padding-top: 20px;padding-bottom:20px;">	
	  		<div class="col s12">
	  			<div class="XL-Buttons col s3 ">
				 	<a href="#!" class="waves-effect waves-light btn-Large col s12 " onclick="openWindowtemplate()">
					 	<div class="col s12" style="padding-top: 3px; color:#fff;"><i class="mdi-action-class" ></i></div>						 		
						<div class="col s12 " style="padding-top: 20px; line-height: 1; color:#fff;" >Advise To Rest</div>

					</a>
				</div>
				<div class="XL-Buttons col s3">
				 	<a data-target="prescription-modal" id="prescription" onclick="openPrescriptionstemplate()" 
				 	href="#prescription-modal" class="modal-trigger waves-effect waves-light btn-Large col s12 blue">
					 	<div class="col s12" style="padding-top: 3px;  color:#fff;"><i class="mdi-editor-insert-drive-file" ></i></div>						 		
						<div class="col s12"  style="padding-top: 20px;margin-left: -17px;color:#fff;" >Prescription</div>
					</a>
				</div>
				<div class="XL-Buttons col s3">
				 	<a href="#!" class="waves-effect waves-light btn-Large col s12 orange" onclick="openFitToWorktemplate()">
						<div class="col s12" style="padding-top: 3px; color:#fff;"><i class="mdi-action-thumb-up" ></i></div>				 		
						<div class="col s12" style="padding-top: 20px;line-height: 1;color:#fff;" >Fit To Work</div>
					</a>
				</div>
				<div class="XL-Buttons col s3">
				 	<a href="#!" class="waves-effect waves-light btn-Large col s12 red" onclick="openCleanSheettemplate()">
						<div class="col s12" style="padding-top: 3px; color:#fff;"><i class="mdi-editor-insert-drive-file" ></i></div>				 		
						<div class="col s12" style="padding-top: 20px;line-height: 1;color:#fff;overflow-wrap: break-word;" >Recommendation</div>
					</a>
				</div>
	  		</div>
		</div>
	     
	</div>	
<!-- <script type="text/javascript" src="{!! URL::asset('js/materialize.min.js') !!}"></script> -->
<script type="text/javascript">

	$('#scheduler').leanModal({
		  dismissible: false,
	      opacity: .91, // Opacity of modal background
	      in_duration: 300, // Transition in duration
	      out_duration: 200, // Transition out duration
	      }
	  	);

	$('.materialboxed').materialbox();
	
</script>
<!--
DISABLED for TESTING

 <link type="text/css" rel="stylesheet" href="{!! URL::asset('jquery-ui-1.11.4/jquery-ui.css') !!}"  media="screen,projection,print"/>
<script type="text/javascript" src="{!! URL::asset('jquery-ui-1.11.4/external/jquery/jquery.js') !!}"></script>
<script type="text/javascript" src="{!! URL::asset('jquery-ui-1.11.4/jquery-ui.js') !!}"></script> -->
<script type="text/javascript">

	$("#releasedocs").click(function(){
		$( "#docs" ).dialog("open");
	});

	$( "#docs" ).dialog({
		  movable: false,
	      resizable: false,
	      autoOpen:false,
	      modal:true,
	      position: { my: "bottom", at: "center", of: window },
	      width: 700,
	      buttons: {
	        Cancel: function() {
	          $( this ).dialog( "close" );
	        }
	      }
	    });

	$( "#documents" ).dialog({
		  movable: false,
	      resizable: false,
	      closeOnEscape: false,
	      autoOpen:false,
	      position: { my: "bottom", at: "center", of: window },
	      modal: true,
	      width: 700,
	      /*buttons: {
	        "Delete all items": function() {
	          $( this ).dialog( "close" );
	        },
	        Cancel: function() {
	          $( this ).dialog( "close" );
	        }
	      }*/
	    });
</script>
<script type="text/javascript">
		function openWindowtemplate() {
    		window.open("http://localhost/clinic/public/doc/medcerttemplate", "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=0, left=0, width=1050, height=750");
    	}
    	
    	function openPrescriptionstemplate() {
    		window.open("http://localhost/clinic/public/doc/presctemplate", "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=0, left=0, width=1050, height=750");
    	}

    	function openFitToWorktemplate() {
    		window.open("http://localhost/clinic/public/doc/ftwtemplate", "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=0, left=0, width=1050, height=750");
    	}
    	function openCleanSheettemplate() {
    		window.open("http://localhost/clinic/public/doc/rectemplate", "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=0, left=0, width=1050, height=750");
    	}
</script>

<script type="text/javascript">
	
		var pay = angular.module('paymentApp',[], function($interpolateProvider) {
			$interpolateProvider.startSymbol('<%');
			$interpolateProvider.endSymbol('%>');
		});

		pay.controller('payBillController', function($scope, $http, $timeout) {

			$scope.billings = [];
			$scope.billings_paid = [];
			$scope.schedules = [];

			$scope.init = function() {
				$http.get("bill/getBillingInfo")
				.success(function(data, status, headers, config) {
					$scope.billings = data;
					
				});
			}
			$scope.init_paid = function() {
				$http.get("bill/getBillingInfo_paid")
				.success(function(data, status, headers, config) {
					$scope.billings_paid = data;
					
				});
			}

			$scope.showBill = function(index) {
				var s = $scope.billings[index];
				var id = s.id;
				// $http.get('bill/viewBillingInfo/' + s.id)
				window.location.href ="bill/viewBillingInfo/" + id;	
			
			}

			$scope.search = function() {
					
				$http.get("search", {params:{"name": $scope.name}})
				.success(function(data, status, headers, config) {
					$scope.schedules = data;
					
				});
			}

			$scope.init();
			$scope.init_paid();



		});
			
</script>

<script type="text/javascript">
	   
	var socket = io('http://192.168.254.5:3000');
	socket.on("test-channel:App\\Events\\ConsultationStatus", function(message){
                document.getElementById('patName').innerHTML = message.stat.name;

                // if(message.status.stat==0){
                // 	document.getElementById('docStat').innerHTML = 'Available';
                // }else{
                // 	document.getElementById('docStat').innerHTML = 'Not Available';
                // }	
    });
</script>	
@endsection

@section('footer')
	
@endsection
