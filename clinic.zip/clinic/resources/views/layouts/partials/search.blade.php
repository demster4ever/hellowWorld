{!! Form::open(array('url' => '/patient/search')) !!}
	
		<span >
			<input name="search_input"  type="text" placeholder="Search Patient">
			{!! Form::submit('Search')!!}
		</span>

{!! Form::close() !!}