@extends('templates/medcert')


@section('content')
<!-- <div class="header unprint">
	<h2>Too Long Hopital Name</h2>
	<p>Blk. 34, Something Address</p>
	<p>Tel. No. 09123455661</p>
</div>
<div class="title-div unprint">Medical Certificate</div>
<div class="date unprint">
	Date:<input id="date" type="text" placeholder="mm/dd/yyyy" size="10">
</div> -->
<div class="patient-info" style="margin-top: 280px; height: 81px;">	
		<input class="patient-name " placeholder="Name" style="color:#000; border:none;" type="text" value="" size="35">
		<input class="patient-age " placeholder="Age" style="color:#000; border:none;" type="text" value="" size="2">
		<input class="patient-sex " placeholder="Sex" style="color:#000; border:none;" type="text" value="" size="2">
		<input class="patient-address " placeholder="Address" style="color:#000; border:none;" type="text" value="" size="40">
		<input class="patient-date " placeholder="Date" style="color:#000; border:none;" type="text" value=""size="14">
		
</div>
<div class="paragraph" style="height:auto; font-size:14px; line-height:20px;">
		<div style="height: 10px"></div>
		<div class="non-editable" style="padding-left: 50px;  width:100%">

					
						

						<table style="width:100%; line-height:20px;">
						  <tr>
						    <td></td>
						    <td><div style="font-size: 16px; background-color: #F5F5DC; padding-right:5px;" class="editable"><div class="">
						    	<input style="border:none;" placeholder="Brand Name" type="text" value="" size="35"></div></div></td> 
						    <td></td>
						    <td></td>
						  </tr>
						  <tr>
						    <td></td>
						    <td><div style="font-size: 16px; background-color: #F5F5DC; padding-left:10px;padding-right:5px;" class="editable"><div class="">
						    	<input style="border:none;" placeholder="Generic Name"type="text" value="" size="35"></div></div></td> 
						    <td></td>
						    <td></td>
						  </tr>
						  <tr>
						    <td>Sig:</td>
						    <td><div><div style="font-size: 16px; background-color: #F5F5DC; padding-left:10px;padding-right:5px;" class="editable">
						    	<input style="border:none; text-align:left; display:inline; "type="text" value="" size="35"></div></div></td> 
						    <td></td>
						    
						  </tr>
						</table>
						<div style="height: 10px"></div>
						<table style="width:100%; line-height:20px;">
						  <tr>
						    <td></td>
						    <td><div style="font-size: 16px;  background-color: #F5F5DC; padding-right:5px;" class="editable"><div class="">
						    	<input style="border:none;" placeholder="" type="text" value="" size="35"></div></div></td> 
						    <td></td>
						    <td></td>
						  </tr>
						  <tr>
						    <td></td>
						    <td><div style="font-size: 16px; background-color: #F5F5DC; padding-left:10px;padding-right:5px;" class="editable"><div class="">
						    	<input style="border:none;" placeholder=""type="text" value="" size="35"></div></div></td> 
						    <td></td>
						    <td></td>
						  </tr>
						  <tr>
						    <td>Sig:</td>
						    <td><div><div style="font-size: 16px; background-color: #F5F5DC; padding-left:10px;padding-right:5px;" class="editable">
						    	<input style="border:none; text-align:left; display:inline; "type="text" value="" size="35"></div></div></td> 
						    <td></td>
						    
						  </tr>
						</table>
						<div style="height: 10px"></div>
						<table style="width:100%; line-height:20px;">
						  <tr>
						    <td></td>
						    <td><div style="font-size: 16px;  background-color: #F5F5DC; padding-right:5px;" class="editable"><div class="">
						    	<input style="border:none;" placeholder="" type="text" value="" size="35"></div></div></td> 
						    <td></td>
						    <td></td>
						  </tr>
						  <tr>
						    <td></td>
						    <td><div style="font-size: 16px; background-color: #F5F5DC; padding-left:10px;padding-right:5px;" class="editable"><div class="">
						    	<input style="border:none;" placeholder=""type="text" value="" size="35"></div></div></td> 
						    <td></td>
						    <td></td>
						  </tr>
						  <tr>
						    <td>Sig:</td>
						    <td><div><div style="font-size: 16px; background-color: #F5F5DC; padding-left:10px;padding-right:5px;" class="editable"> 
						    	<input style="border:none; text-align:left; display:inline; "type="text" value="" size="35"></div></div></td> 
						    <td></td>
						    
						  </tr>
						</table>
		
		</div>
		<div>
			<p class="non-editable notify"><strong>Note:</strong><br><note class="editable" style=" background-color: #F5F5DC; padding:5px;"></note></p>
		</div>
</div>
<!-- Doc Info -->
<div class="doc-info">
	<ul>
		<li><b>MA. TERESA ROWENA V. BACABAC-EBREO, M.D.</b></li>
		<li>License No: <input type="text" class="ptr" size="15" value=""></li>
		<li>PTR No: <input type="text" class="ptr" size="15" value=""></li>
		<li>S2 No: <input type="text" class="s2" size="15"></li>
	</ul>
	
	
</div>
<div class="unprint">
	<div class="floater">
		<button class="print print-window btn" type="submit" name="action"><img src="{!!URL::asset('img/printer.svg')!!}"style="width: 40px;float: left;margin-right: 5px;margin-top: -6px;">Print</button>
	</div>
</div>

<script>

		$('.print-window').click(function() {
		    window.print();
		});

		$('.editable').each(function(){
		    this.contentEditable = true;
		});

		$('.non-editable').each(function(){
		    this.contentEditable = false;
		});

		
</script>

@endsection