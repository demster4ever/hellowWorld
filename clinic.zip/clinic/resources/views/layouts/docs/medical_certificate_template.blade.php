@extends('templates/medcert')


@section('content')
<!-- <div class="header unprint">
	<h2>Too Long Hopital Name</h2>
	<p>Blk. 34, Something Address</p>
	<p>Tel. No. 09123455661</p>
</div>
<div class="title-div unprint">Medical Certificate</div>
<div class="date unprint">
	Date:<input id="date" type="text" placeholder="mm/dd/yyyy" size="10">
</div> -->
<div class="patient-info" >	
		<input class="patient-name fordisplay" style="color:#fff; border:none;" type="text" value="" size="35">
		<input class="patient-age fordisplay" style="color:#fff; border:none;" type="text" value="" size="2">
		<input class="patient-sex fordisplay" style="color:#fff; border:none;" type="text" value="" size="2">
		<input class="patient-address fordisplay" style="color:#fff; border:none;" type="text" value="" size="40">
		<input class="patient-date fordisplay" style="color:#fff; border:none;" type="text" value=""size="14">
		
</div>
<div class="paragraph border-all" style="text-transform:none; font-size:18px; width:100%;">
	
		<div style="display: block;  clear: both; margin-top:10px;"> 
			<div style="float:right; margin-right:40px" class=""><b class="editable" id="datenow"> </b></div>
		</div>
		<br><p class="non-editable disappear fordisplay">To whom it may concern:</p><br><br>
		<div> 
			<div class="non-editable first_para fordisplay" style="float:left; margin-left:50px; width:auto;">This is to certify that</div>
			<div class="print-remove" style="overflow:hidden; text-align:center; background-color: #F5F5DC; padding-left:10px;padding-right:5px;"> <b class="editable">
				<input type="text" value="" size="35"  style="border:none; font-weight:bold;"> </b> </div>
		</div>
		<div style="display: block;  clear: both; margin-top:20px;"> 
			<div class="non-editable first_para fordisplay" style="float:left;width:auto;">is advised to rest for </div>
			<div class="editable" style="overflow:hidden; text-align:center;float:left;text-transform:none;
			 background-color: #F5F5DC; width: 30%; padding-left:5px;padding-right:5px;"> 
			 	<b class="editable" style="text-transform:none;"> day(s)</b> </div>
			<div style="float:left;" class="fordisplay"> because of </div>
		</div>
		<div style="display: block;  clear: both; margin-top:75px;">
			<div class="print-remove" style="overflow:hidden; background-color: #F5F5DC; padding-left:10px;padding-right:5px;">
					<b>
				<p style="margin:3px;" class="indent-bold-underlined"> 
					<input style="border:none;font-weight:bold;"type="text" value="" size="35"> </b>
			
				</p>
					</b>
			</div>
			
		</div>
		<div class="" style="font-size: 18px;float:left;margin-left:50px;width:auto; margin-top:5px">Thank you!</div>		
		
</div>

<!-- Doc Info -->
<!-- <div class="doc-info">
	<ul>
		<li><input type="text" class="ptr" size="15" value="PTR No. 0000000"></li>
		<li><input type="text" class="s2" size="15"value="S2 No. 0000000"></li>
	</ul>
	
	
</div> -->

<div class="unprint">
	<div class="floater">
		<button class="print print-window btn" style="color:white;text-transform:none;" type="submit" name="action"><img src="{!!URL::asset('img/printer.svg')!!}"style="width: 40px;float: left;margin-right: 5px;margin-top: -6px; ">Print</button>
	</div>
</div>

<script>

		$('.print-window').click(function() {
		    window.print();
		});

		$('.editable').each(function(){
		    this.contentEditable = true;
		});

		$('.non-editable').each(function(){
		    this.contentEditable = false;
		});


		
</script>

<script>

 	var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth()+1; //January is 0!

    var yyyy = today.getFullYear();
    if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 
    var today = dd+'/'+mm+'/'+yyyy;
    $('#datenow').append(today);
</script>
@endsection