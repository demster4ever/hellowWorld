@extends('templates/main')
{!! Html::style('css/style.css') !!} 

@section('header')
	
@endsection
@section('search')
	<span>
		<input name="search_input"  type="text" placeholder="Search Patient">
		<a href="{!! URL::route('search_patients') !!}">Search</a>
	</span>
@endsection

@section('content')
	
	<div class="page-main" ng-app="todoApp">
		
		<div class="row">
			<div class="col s3">
			 <!-- TODO: Convert to route and pass user id --> 
			 	<div class="card">      			
      				<div class="card-image grey lighten-4 col s12" style="display:block;float:left;">
		               <img src="{!! URL::asset(''.$patient->img_path) !!}" style="margin-bottom:10px;margin-top:10px;">
		              <!-- {!! Html::image(''.$patient->img_path) !!} -->
		          	</div>
		            <div class="card-content" style="width:100%;font-size:14px;display:block;float:left; padding-top: 5px;"> 
			           	<div class="blue darken-2 white-text truncate" style="margin-top: 5px;font-size:18px;padding-left: 5px;">{!! $patient->last_name!!}, {!! $patient->first_name!!} {!! $patient->middle_name!!}</div>
			            <i class="mdi-content-add-circle green-text tiny"></i> Age:  {!! $patient->age!!} yr(s).old <br>
						<i class="mdi-content-add-circle green-text tiny"></i> Gender:  {!! $patient->gender!!}<br>
						<i class="mdi-content-add-circle green-text tiny"></i> Date of Brith:  {!! $patient->date_of_birth!!}<br>
						<i class="mdi-content-add-circle green-text tiny"></i> Marital Status:  {!! $patient->marital_status !!}<br>
						<i class="mdi-content-add-circle green-text tiny"></i> Occupation:  {!! $patient->occupation!!}<br>
						<i class="mdi-content-add-circle green-text tiny"></i> Address:  {!! $patient->address!!}<br>
						<i class="mdi-content-add-circle green-text tiny"></i> Contacts:  {!! $patient->contact!!}<br><br>
						<a id="" href="{!! URL::route('patient',array('id' => $patient->patient_id)) !!}" class="waves-effect waves-blue btn"  style="text-transform: none;font-style: regular; display: block;" data-delay="50" data-tooltip="Patient's History"><i class="mdi-action-history">View History</i></a><!-- TODO: Convert to route and pass user id -->					  
					</div>

					
    				</div>
    			<div class="floating-buttons" style="text-align:right;">
    					
    					<!-- <a id="view-history" href="#view-history-modal" data-target="view-history-modal" class="modal-trigger btn-floating btn-large blue tooltipped" data-position="bottom" data-delay="50" data-tooltip="Patient's History"><i class="mdi-action-history">history</i></a><!-- TODO: Convert to route and pass user id -->					   -->
				</div>			
			</div>
			<div class="card panel grey lighten-2 col s9">
				<div class="row">
						<div class="findings-box col s6" ng-controller="todoController">
							<div class="box-title">Findings</div>

									
								<div class="search-box-mini">
									<div class="row">
										<div class="col s10">									
											<div class="">
												<input  id="auto_find"  name="findngs_input" Type="text" autocomplete="on" ng-model="todo.title"/>
												<label for="auto_find">Finding(s)</label><div id="cont" class=""></div>
											</div>					
										</div>
										<div class="col s2">
											<button ng-click="addTodo()" class="btn-floating btn-tiny green tooltipped" data-position="left" 
											data-delay="50" data-tooltip="Add"style="margin-top:18px;" ><i class="mdi-content-add"></i></button>
										</div> 
									</div>									
								</div>


								<div class="findings-results">	
									<div class="row"style="overflow-y:auto; overflow-x:hidden; height:300px;">
											<table class="collection " style="text-align:left;" >
												<tr ng-repeat='todo in todos' class="row collection-item" >
																							
													<td>
														<div style="width:350px; max-width:350px; word-wrap: break-word;">
															<%  todo.findings %>	
														</div>
											  													  			
											  		</td>
										

													<td >
														<a href="#!" ng-click="deleteTodo($index)" class="btn-floating red tooltipped" data-position="left" data-delay="50" data-tooltip="Remove" ><i class="small mdi-navigation-close left"></i>	
													</td>
												</tr>
											</table>
									</div>
								</div>

						</div>

						<div class="treatment-box col s6"  ng-controller="todo2Controller">

							<div class="box-title"> Treatments</div>
							<div class="search-box-mini">
									<div class="row">

										<div class="col s10">									
											<div class="">
												<input  name="treatments_input" Type="text" autocomplete="on" ng-model="todo2.title"/>
												<label for="auto_find">Treatment(s)</label>
											</div>					
										</div>
										<div class="col s2">
											<button ng-click="addTodo2()" class="btn-floating btn-tiny green tooltipped" data-position="left" 
											data-delay="50" data-tooltip="Add"style="margin-top:18px;" ><i class="mdi-content-add"></i></button>
										</div> 

									</div>		
							</div>
							<div class="treatments-results">

								<div class="row"style="overflow-y:auto; overflow-x:hidden; height:300px;">


									<table class="collection " style="text-align:left; overflow-y:hidden; overflow-x:hidden;">
										<tr ng-repeat='todo2 in todos2' class="row collection-item">
											<td class="col s10">
												
									  			<%  todo2.treatment %>
									  			
									  		</td>
											<td class="col s2">
												
												<a href="#!" ng-click="deleteTodo2($index)" class="btn-floating red tooltipped" data-position="left" data-delay="50" data-tooltip="Remove" ><i class="small mdi-navigation-close left"></i>	
											</td>
										</tr>
									</table>
										
								</div>


							</div>
				</div> 

			</div>
					<div class="notes col s12 card grey lighten-3 ">
						 
						 <label for="remarks">Remarks</label>
				         <textarea id="remarks" maxlength="300" ></textarea>
	            		       
	        
					</div>

					<div class="row">
						<div class=" col s12" style="padding: 0;margin: 0;">														
						 <div class="XL-Buttons col s3 ">
						 	
						 	<a href="#!" class="waves-effect waves-light btn-Large col s12 " onclick="openWindow()">
							 	<div class="col s12"><i class="mdi-action-class" ></i></div>						 		
								<div class="col s12 " style="padding-top: 10px; line-height: 1;" >Advise to Rest</div>

							</a>
						 </div>
						 <div class="XL-Buttons col s2 ">
						 	<a data-target="prescription-modal" id="prescription" href="#prescription-modal" class="modal-trigger waves-effect waves-light btn-Large col s12 blue">

							 	<div class="col s12"><i class="mdi-editor-insert-drive-file" ></i></div>						 		
								<div class="col s12"  style="padding-top: 10px;margin-left: -17px;" >Prescription</div>
							</a>
						 </div>
						 <div class="XL-Buttons col s2 ">
						 	<a href="#!" class="waves-effect waves-light btn-Large col s12 orange" onclick="openFitToWork()">

								<div class="col s12"><i class="mdi-action-thumb-up" ></i></div>				 		
								<div class="col s12" style="padding-top: 10px;line-height: 1;" >Fit To Work</div>


							</a>
						 </div>
						 <div class="XL-Buttons col s3 ">
						 	
						 	<a data-target="add-lab-modal" id="add-lab" href="#add-lab-modal" class="modal-trigger waves-effect waves-light btn-Large col s12 red">

							 	<!-- <div class="row"><i class="large material-icons" >local_hospital</i></div>						 		
								<div class="row">Laboratory Test</div> -->
								<div class="col s12"><i class="mdi-maps-local-hospital" ></i></div>				 		
								<div class="col s12" style="padding-top: 10px;line-height: 1;" >Laboratory Test</div>

							</a>
							
						 </div>
						 <div class="XL-Buttons col s2">
						 	
						 	<a data-target="done-modal" href="#done-modal" id="done" class="waves-effect waves-light btn-Large col s12 green modal-trigger" >
							 	<div class="col s12"><i class="mdi-navigation-check" ></i></div>				 		
								<div class="col s12" style="padding-top: 10px;" >Done</div>
							</a>
							
						 </div>
						</div>
					</div>
			</div>
		</div>

		
		<!-- Prescription -->
		<div id="prescription-modal" class="modal bottom-sheet" ng-controller="todo2Controller">
			<div class="closer right">
			    		<a href="#!" class="waves-effect waves-light btn-floating col s12 modal-action modal-close red tooltipped" data-position="left" data-delay="50" data-tooltip="Close" 
			    		style="margin: 10px 10px;"><i class="large mdi-navigation-close" ></i></a>
			</div>
			<div class="modal-content grey darken-4"style="height: inherit;" >
			    	<!-- Content of Prescription Modal -->
			    <h4 class="white-text">Prescriptions</h4>

			    <div class="card" style="height: inherit;" >
			    	<ng-form id="pres" name="pres">
			        <div class="row" >
			      	 
			      	      	<div class=" col s3">
					      		<h5>Generic Name</h5>			      	
						    	<div class="row" >
										<input type="text" class="validate" required placeholder="Ex. Ibuprofen" name="pres_input"id="generic" autocomplete="on" ng-model="prescription.generic">
										<div class="help-block error" style="color:red;" ng-show="pres.pres_input.$error.required">Generic name required.</div>
								</div>
					      	</div>

					      	<div class="border-l border-r col s3">
					      		<h5>Brand Name</h5>			      	
						    	<div class="row">
						    			<div class="border col s8">
						    				<input type="text" class="validate" required id="brand"  placeholder="Ex. Genselax" name="brand_input"autocomplete="on" ng-model="prescription.brand">
											<select class="browser-default" id="brand-select" name="brand" value="" onchange="updateBrandInput();" ></select>
											

						    			</div>
										<div class="col s4">
											<input type="text" placeholder="500mg" id="dosage" ng-model="prescription.dosage">
											<!-- <select class="  browser-default" name="dosage" value="" id="dosage-select" onchange="updateDosageInput();">
												
											</select> -->
										</div>
								</div>
					      	</div>

					      	<div class="border col s2">
					      		<h5>Dosage</h5>			      	
						    	<div class="row">
										
										<div class=" col s12">
											<input type="text" placeholder="Ex.1 capsule 3x a day" id="dosageType" ng-model="prescription.intake">
											<select class=" browser-default" name="brand" ng-model="dType" ng-change="showSelectValue(dType)" id="dosageTypeSelect" >
												<option value=" times a day" id="perDay" selected>times a day</option>
												<option value=" every[ ]hrs" id="everyNoOfHours">every[ ]hrs</option>
												<option value=" minute(s) before meal" id="minbmeal">minute(s) before meal</option>
												<option value=" minute(s) after meal" id="minameal">minute(s) after meal</option>
											</select>
										</div>
								</div>
					      	</div>

					      	<div class="col s2">
					      		<h5>Duration</h5>			      	
						    	<div class="row">
									<input type="text" placeholder="Ex. 3 days" id="durationType" ng-model="prescription.duration">
									<select class=" browser-default" name="brand" ng-model="durType" ng-change="showSelectDur(durType)" id="durationTypeSelect" >
										<option value="hour(s)" id="hr" selected>hour(s)</option>
										<option value="day(s)" id="day">day(s)</option>
										<option value="week(s)" id="week">week(s)</option>
										<option value="month(s)" id="month">month(s)</option>
										<option value="year(s)" id="year">year(s)</option>
									</select>
								</div>
					      	</div>
					      	
					      	<div class="border-l col s2">
						
								<div class="col s12">
									<div class="Big-Modal-Buttons" >
										<!-- <button ng-click="addPrescription()" class="btn-floating btn-tiny green tooltipped" data-position="left" 
											data-delay="50" data-tooltip="Add"style="margin-top:18px;" >Add</button> -->	
								 		 <a style="margin-bottom:3px; margin-top:-15px;" ng-click="addPrescription()" href="#!" 
								 		 class="waves-effect waves-light btn-Large col s12 tooltipped" data-position="top" data-delay="50" 
								 		 data-tooltip="Add" ng-hide="pres.pres_input.$error.required">
										 	<div class="col s12"><i class="large mdi-content-add" ></i></div>				 		
											<div class="col s12" style="padding-top: 35px" >add</div>
										</a>
 
								 	</div>	
								 	<div class="Big-Modal-Buttons" >

										<a href="#!" class="waves-effect waves-light btn-Large col s12 tooltipped green" data-position="top" 
										data-delay="50" data-tooltip="Done" onclick="openPrescriptions()">
										 	<div class="col s12"><i class="mdi-navigation-check" ></i></div>				 		
											<div class="col s12" style="padding-top: 35px" >Done</div>	
										</a>
								 	</div>										 	
							 	</div>
							 	<!-- <div class="col s6">
									<div class="Big-Modal-Buttons" >
								 		
								 	</div>									 	
							 	</div>		 -->								 	
					      	</div>
				      	
			      	</div>
			      	</ng-form>
			      <div class="pres-coll">
				       <ul class="collection with-header">
				        <li class="collection-header orange" style="padding:0; padding-top: 5px;"><h5>
				        	<div class="row" style="margin-bottom:5px; margin-top:5px; text-align:center" >

					        	<div class="col s4"><b>Generic Name</b></div>
					        	<div class="col s4"><b>Brand Name</b></div>
					        	<div class="col s2"><b>Dosages</b></div>
					        	<div class="col s1"><b>Duration</b></div>

					        	<div class="col s1">   		
								</div>
					        									      	
					      	</div>
					      </h5>
				        </li>


				        <!-- Item -->
				        <li class="pres-coll collection-item" style="padding:0;"  ng-repeat='prescription in prescriptions'>
				        	<div class="modalrow row" style="margin-bottom:5px; margin-top:5px; text-align:center" >

					        	<div class="border col s4"><b><% prescription.generic %></b><b ng-if="!prescription.generic">---</b></div>
					        	<div class="border col s4">
					        		<div class="col s8"><b><% prescription.brand %></b><b ng-if="!prescription.brand">---</b> </div>
					        		<div class="col s4"><b><% prescription.dosage %></b></div>
					        	</div>
					        	<div class="border col s2">
					        		<b><% prescription.intake %></b>
					        	</div>
					        	<div class="border col s1"><b><% prescription.days %></b></div>

					        	<div class="col s1">
					        		<div class="closer right">
							    		<a href="#!" ng-click="deletePrescription($index)" class="waves-effect waves-light btn-floating red tooltipped" data-position="left" data-delay="50" data-tooltip="Remove" 
							    		style="margin:0px 20px;"><i class="large mdi-navigation-close" ></i></a>

							    		
									</div>
								</div>
					        									      	
					      	</div>
				        </li>
				        <!-- item end -->
				       
				      </ul>
			      </div>
			    </div>
			      	
			</div>			   
		</div>
		<!-- End Of Modal -->

	
		<div ng-controller="subtestController">
			<!-- Lab Test -->
			<div id="add-lab-modal" class="modal bottom-sheet" >
				<div class="closer right">
			    		<a href="#!" class="waves-effect waves-light btn-floating col s12 modal-action modal-close red tooltipped" data-position="left" data-delay="50" data-tooltip="Close" 
			    		style="margin: 10px 10px;"><i class="large mdi-navigation-close" ></i></a>
				</div>
				<div class="modal-content grey darken-4"style="height: inherit;">
				    	<!-- Content of MOdal -->
				    	<h4 class="white-text">Laboratory Tests</h4>

				    <div class="card" style="height:100%;">
				    	<div class="card-panel grey lighten-3 row">
					      <div class="lab-test-collection col s12" style="height:50%; font-size:14px; padding:0; overflow-x: hidden ;overflow-y:auto;">
					      		
					      		<ul class="collapsible" data-collapsible="accordion" style="width:inherit;">
								    @if (count($archives) > 0)
								    	@foreach($archives as $archive)	
									    <li>
									      	<div class="collapsible-header" style="padding: 2px 2px 0 0;">
										      	<div class="col s3 truncate">Click to Open</div>
										      	<div class="col s9 btn green"> Laboratory Test:  {!! $archive->test_group_name !!}</div>
									      	</div>
									      	<div class="collapsible-body ">
									      		<div class="result-content row" style="margin: 15px 0 15px 0; color:teal">
									      			<div class="col s4  s-border-b test-res-name">Test Name</div>
									      			<div class="col s3  s-border-b test-res-name">Result</div>
									      			<div class="col s3  s-border-b test-res-range">Range</div>
									      			
									      			@foreach($archive->labhistory as $history)
									      			<div class="col s4 border-r s-border-b test-res-name">{!! $history->test !!}</div>
									      			<div class="col s3 border-r s-border-b test-res-name">{!! $history->result !!}</div>
									      			<div class="col s3 border-r s-border-b test-res-range">{!! $history->range !!}</div>
									      			
									      			@endforeach
									      		</div>			     
									      	</div>
									    </li>
									    
									    @endforeach
								    @else
								    	<div style="font-style:italic;">No laboratory tests yet.</div>
								    @endif

								</ul>
								
					      	</div>	
					    </div>				    
				    </div>
				      			      
				</div>			   
			</div>
			<!-- End Of Laboratory Modal -->	

			<!-- DOne -->
			<div class="row">
				<div id="done-modal" class="confirmation modal col s4 offset-s4" style="margin-top:10%;">
				    <div class="modal-content">
					    <h4>Confirmation</h4>
					    <p>Are you sure you're done with your patient?</p>
				    </div>
				    <div class="modal-footer">
				    	<a href="#" id="no" class="modal-action modal-close waves-effect waves-light btn-Large red" style="margin-left: 10px;">
									 	<!-- <div class="col s12"><i class="mdi-action-class" ></i></div>						 		
										<div class="col s12" style="padding-top: 35px" >No</div> -->
										No
						</a> 
				      	<a href="#" id="okDone" class="modal-action waves-effect waves-light btn-Large teal">
									 	<!-- <div class="col s12"><i class="mdi-action-class" ></i></div>						 		
										<div class="col s12" style="padding-top: 35px" >Yes</div> -->
										Yes
						</a>

				    </div>
				</div>
			</div>
			<div class="row">
				<div id="bill-modal" class="confirmation modal col s4 offset-s4" style="margin-top:10%;">
				    <div class="modal-content">
					   	 
					    <div class="col s12 orange">
					         <h4 class="white-text"style="margin-bottom: 0px;padding-top: 5px;padding-bottom: 5px;">Patient's Bill</h4>
				        </div>
				        <div id="result-bill"></div>
				        <div class="col s12" style="margin-bottom: 15px;margin-top: 20px;">
							<div class=" col s5 ">
						          <input id="desc" ng-model="desc" name="description" type="text" class="validate">
						          <label for="desc">Description</label>	     	
					        </div>
					     	<div class=" col s5 ">
						          <input id="amt" ng-model="amt" name="description" type="text" class="validate" style="text-align:right">
						          <label for="amt">Amount</label>	     	
					        </div>
					        <div class="col s2">
					        	<a href="#!" ng-click="addBill()" class="col s11 offset-s1 waves-effect waves-light large btn-flat teal">
								 <i class="small mdi-content-add white-text" ></i>
								</a>
						          	
					        </div>
				        </div>

				        <div class="row col s12 s-border-b s-border-t s-border-r s-border-l">
							<table class="collection " style="text-align:left;" >
								<thead>
									<tr>
										<td> Charge Description</td>
										<td> Amount</td>
									</tr>
								</thead>
								<tbody>
									<tr class="row collection-item" ng-repeat='bill in bills'>
										<td><% bill.charge_description %></td>
										<td><% bill.amount %></td>
										<td >
											<a href="#!"  ng-click="deleteBill($index)" class="col s6 offset-s6 btn-flat red tooltipped" data-position="left" data-tooltip="Remove" >
												<i class="white-text small mdi-navigation-close "></i>	
										</td>
									</tr>
								</tbody>
								
							</table>
				        </div>
						
					   
				    </div>
				    <div class="modal-footer">
				    	<a href="" id="bill-skip" class="waves-effect waves-light btn-Large red" style="margin-left: 10px;">
									 	<!-- <div class="col s12"><i class="mdi-action-class" ></i></div>						 		
										<div class="col s12" style="padding-top: 35px" >No</div> -->
										Skip
						</a> 
				      	<a href="#!" id="bill-submit" class="waves-effect waves-light btn-Large teal">
									 	<!-- <div class="col s12"><i class="mdi-action-class" ></i></div>						 		
										<div class="col s12" style="padding-top: 35px" >Yes</div> -->
										Submit
						</a>

				    </div>
				</div>
			</div>
		</div>
	</div>


DISABLED FOR TESTING

<script type="text/javascript" src="{!! URL::asset('js/materialize.min.js') !!}">

	  	$("#no").click(function() {
	 		 $('#done-modal').closeModal();
		});

	  	/*$("#okDone").click(function() {
		 
		 	$.ajax({
	            url: '{!! URL('bill/skip') !!}',
	            type: 'GET',
	            data: { 
                        remarks: $('#remarks').val()
                      },
	            success: function(data) {
        			 localStorage.removeItem('remarks');	
	               	 window.location.href ='{!! URL('next') !!}';	
	            },
	            error: function(xhr, status, error) {
				  var err = eval("(" + xhr.responseText + ")");
				  alert(err.Message);
				}
	        });
		});*/
</script>

<script type="text/javascript">

		window.onload = function() {
		 
		  var remarks = localStorage.getItem('remarks');

		  if (remarks != "undefined" || remarks != "null") {
		    document.getElementById('remarks').innerHTML =  remarks;
		  } else{
		    document.getElementById('welcomeMessage').innerHTML = "empty";
		  }
		}

		$('#add-lab').leanModal({
	      dismissible: true, // Modal can be dismissed by clicking outside of the modal
	      opacity: .5, // Opacity of modal background
	      in_duration: 300, // Transition in duration
	      out_duration: 200, // Transition out duration
	      }
	  	);

	  	$('#done').leanModal({
	      dismissible: true, 
	      opacity: .5, 
	      in_duration: 100, 
	      out_duration: 200,

	      }
	  	);
	  	$('#view-history').leanModal({
	      dismissible: true, // Modal can be dismissed by clicking outside of the modal
	      opacity: .5, // Opacity of modal background
	      in_duration: 300, // Transition in duration
	      out_duration: 200,
	       // Transition out duration
	      }
	  	);

	  	$('#prescription').leanModal({
	      dismissible: true, // Modal can be dismissed by clicking outside of the modal
	      opacity: .5, // Opacity of modal background
	      in_duration: 300, // Transition in duration
	      out_duration: 200, // Transition out duration
	      }
	  	);
	  	



		$("#okDone").click(function() {
		  $.ajax({
	            url: '{!! URL('bill/skip') !!}',
	            type: 'GET',
	            data: { 
                        remarks: $('#remarks').val()
                      },
	            success: function(data) {
        			 localStorage.removeItem('remarks');	
	               	 window.location.href ='{!! URL('next') !!}';	
	            },
	            error: function(xhr, status, error) {
				  var err = eval("(" + xhr.responseText + ")");
				  alert(err.Message);
				}
	        });
		});

		$("#bill-submit").click(function() {

		  $.ajax({
	            url: '{!! URL('bill/update') !!}',
	            type: 'GET',
	            data: { 
                        remarks: $('#remarks').val()
                      },
	            success: function(data) {
        			 localStorage.removeItem('remarks');		
	               	 window.location.href ='{!! URL('next') !!}';	
	            },
	            error: function(xhr, status, error) {
				  var err = eval("(" + xhr.responseText + ")");
				  alert(err.Message);
				}
	        });
		  
		});
</script>
@endsection

@section('autosearch')

	

	<script type="text/javascript">


		/*for setting & removing "active classes"
		$('.lab-test-collection').on('click', 'a', function() {
		$('.lab-test-collection .expand').removeClass('expand');
		$(this).addClass('expand');
		});
		end*/

		/*for setting & removing "active classes"*/
		$('.nav-list').on('click', 'a', function() {
			$('.nav-list a.active').removeClass('active');
			$(this).addClass('active');
		});
		/*end*/

		$('.nav-list2').on('click', 'a', function() {
			$('.nav-list2 a.active').removeClass('active');
			$(this).addClass('active');
		});
		$(function(){
			$("#auto_find").keyup(function(){
				$("#auto_find").autocomplete({
					source: '{!! URL('getdata') !!}',
					minLength: 1,
					select: function( event, ui ) {
		             	
						$("#cont").addClass(ui.item.value);
		             	document.getElementById('auto_find').value = ui.item.id;
		         	}
				});
				
		 	});
		});

		$(function(){
			//$("#generic").keyup(function(){
				$("#generic").autocomplete({
					//source: '{!! URL('medicines/generics') !!}',
					source: function(request, response) {
						$.ajax({
				            url: '{!! URL('medicines/generics') !!}' +'/'+ $('#generic').val(),
				            
				            success: function(data) {
				               response(data);
				            }
				        });  

				        $.ajax({
				            url: '{!! URL('medicines/brands') !!}' +'/'+ $('#generic').val(),
				            
				            success: function(data) {
				               //response(data);
				               var items = [];
				               var thelist = document.getElementById("brand-select"); 

							   while (thelist.hasChildNodes()){
								    thelist.removeChild(thelist.lastChild);
							   }
							   $.each(data, function(i, item) {

							          items.push('<option onselect="updateBrandInput();" value='+ item.value+'>'+item.value+'</option>');

							   });  // close each()

							   $('#brand-select').append( items.join('') );
				            }
				        });   // closes $.ajax function
				    },
					minLength: 1,
					select: function( event, ui ) {
		             	
		             	document.getElementById('generic').value = ui.item.value;
		             	$.ajax({
				            url: '{!! URL('medicines/brands') !!}' +'/'+ $('#generic').val(),
				            
				            success: function(data) {
				               //response(data);
				               var items = [];
				               var thelist = document.getElementById("brand-select"); 

							   while (thelist.hasChildNodes()){
								    thelist.removeChild(thelist.lastChild);
							   }

							   $.each(data, function(i, item) {

							          items.push('<option onselect="updateBrandInput();" value='+ item.value+'>'+item.value+'</option>');

							   });  // close each()

							   $('#brand-select').append( items.join('') );
				            }
				        });   
		         	}
				});
				
		 	// });
		});


		$(function(){
			$('#brand').focus(function(){

				$('#brand').autocomplete({
					source: function(request, response) {
						$.ajax({
				            url: '{!! URL('medicines/brands') !!}' +'/'+ $('#generic').val(),
				            success: function(data) {
				               response(data);
				            }
				        });

				        $.ajax({
				            url: '{!! URL('medicines/dosages/{any}/{any}') !!}',
				            type: 'GET',
	                		data: { generic: $('#generic').val(), brand: $('#brand').val()},
				            success: function(data) {
				               
				               var items = [];
				               var dosagelist = document.getElementById("dosage-select"); 

							   while (dosagelist.hasChildNodes()){
								    dosagelist.removeChild(dosagelist.lastChild);
							   }
							   $.each(data, function(i, item) {

							          items.push('<option value='+ item.value+'>'+item.value+'</option>');

							   });  

							   $('#dosage-select').append( items.join('') );
				            }
				        });
					},
					select: function( event, ui ) {
		             	
		             	document.getElementById('brand').value = ui.item.value;
		             	$.ajax({
				            url: '{!! URL('medicines/dosages/{any}/{any}') !!}',
				            type: 'GET',
	                		data: { generic: $('#generic').val(), brand: $('#brand').val()},
				            success: function(data) {
				               
				               var items = [];
				               var dosagelist = document.getElementById("dosage-select"); 

							   while (dosagelist.hasChildNodes()){
								    dosagelist.removeChild(dosagelist.lastChild);
							   }
							   $.each(data, function(i, item) {

							          items.push('<option value='+ item.value+'>'+item.value+'</option>');

							   });  

							   $('#dosage-select').append( items.join('') );
				            }
				        });   
		         	}
					

				});
				
		 	});
		});

		function openWindow() {
    		window.open("http://localhost/clinic/public/doc/medcert", "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=0, left=0, width=1050, height=750");
    	}
    	
    	function openPrescriptions() {
    		window.open("http://localhost/clinic/public/doc/presc", "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=0, left=0, width=1050, height=750");
    	}

    	function openFitToWork() {
    		window.open("http://localhost/clinic/public/doc/ftw", "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=0, left=0, width=1050, height=750");
    	}
    	
    	function populateBrands(){

    		var items = [];

		   $.each(data, function(i, item) {

		          items.push('<li><a href="yourlink?id=' + item.UserID + '">' + item.Username + '</a></li>');

		   }); 

		   $('#yourUl').append( items.join('') );
    	}
    	
    	function updateBrandInput(){
			var e = document.getElementById("brand-select");
			var brandSelected = e.options[e.selectedIndex].text;

			document.getElementById("brand").value=brandSelected;
			$.ajax({
	            url: '{!! URL('clinic/public/medicines/dosages/{any}/{any}') !!}',
	            type: 'GET',
        		data: { generic: $('#generic').val(), brand: $('#brand').val()},
	            success: function(data) {
	               
	               var items = [];
	               var dosagelist = document.getElementById("dosage-select"); 

				   while (dosagelist.hasChildNodes()){
					    dosagelist.removeChild(dosagelist.lastChild);
				   }
				   $.each(data, function(i, item) {

				          items.push('<option value='+ item.value+'>'+item.value+'</option>');

				   });  

				   $('#dosage-select').append( items.join('') );
	            }
	        });   
		}  

		function updateDosageInput(){
			var e = document.getElementById("dosage-select");
			var dosageSelected = e.options[e.selectedIndex].text;

			document.getElementById("dosage").value=dosageSelected;

		}  

	</script>

	<script>

		$('.print-window').click(function() {
		    window.print();
		});

		$('.editable').each(function(){
		    this.contentEditable = true;
		});

		$('.non-editable').each(function(){
		    this.contentEditable = false;
		});

		
	</script>
	
@endsection