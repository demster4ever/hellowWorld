@extends('templates/main')
{!! Html::style('css/style.css') !!} 

@section('content')
	
	<div class="page">
	<h5>Appointments</h5>
		<div class="content">
			<div class="card-panel teal lighten-4">
				<b>Currently, you have <strong>{!! $count !!}</strong> patient(s) waiting.</b>
			</div>

			<div class="row">	
				<div class="col s10">
						<table class="striped">
					        <thead>
					          <tr>
					          	@if(Session::get('roleid')!=3)
					              <th data-field="Actions"> Action</th>
					            @endif
					              <th data-field="avatar">  </th>
					              <th data-field="lastName">Patient Name</th>
					              <th data-field="lastName">Age</th>
					              <th data-field="lastName">Gender</th>
					              <th data-field="lastName">Marital Status</th>
					          </tr>	
					        </thead>
					        <tbody>
					         @foreach($patients as $patient)
					         
					          <tr>
					          	
					            <td>
					            	@if(Session::get('roleid')!=3)

					            		
					            			@if($patient->status_id == 1)
					            			<a href="{!! URL::route('consult', array('id' => $patient->patient_id )) !!}" class="waves-effect waves-light btn" >
					            				Consult
					            			</a>
					            			@else
					            			<a href="{!! URL::route('consult', array('id' => $patient->patient_id )) !!}" class="waves-effect waves-light btn green" >
					            			Continue
					            			</a>
					            			@endif
					            		
					            	@endif
					            </td>
					            <td style="border-radius:0px; display:inline-block;"> 
						            	<div class="mini-avatar" >
							 				<img src="{!!  URL::asset(''.$patient->img_path) !!}" class="materialboxed">
							 			</div>

						            	<!-- <div style="vertical-alignment:middle;">{!!  $patient->patient_id !!}</div> -->

						        </td>	
					            <td>{!!  $patient->last_name!!}, {!! $patient->first_name; $patient->middle_name!!}</td>
					          	<td> {!! $patient->age!!}</td>
					          	<td>{!! $patient->gender!!}</td>
					          	<td>{!! $patient->marital_status!!}</td>
					          	

					          </tr>
					          @endforeach
					        </tbody>
					     </table>
			
				 </div>
			</div>
			
		</div>
	</div>

	<div  id="dialog-confirm"  title="Reminder">
	  		<div >
	  			@if(count($current_patient)>0)
				@foreach($current_patient as $cpat)
					<!-- end header results -->
			        <div class="result-scroller" style="height: 50%; padding-bottom:10px;">
			        	<h6><b>You still have patient on a consultation process.</b> </h5>
			        	<h6 id="cons_pat_id" style="font-size: 14px;">Patient Id: {!! $cpat-> patient_id !!} </h6>
			        	<h6 id="cons_pat">Patient Name: {!! $cpat->first_name !!} {!! $cpat->last_name !!}</h6>
			        	<h6>Patient Gender: {!! $cpat->gender !!} </h6>
					</div>

				    <div class="modal-foot" style="">
						<a href="{!! URL::route('markAsDone', array('id' => $cpat-> patient_id )) !!}" style="text-transform:none; color:#fff;" class=" modal-action modal-close waves-effect waves-green btn">Mark as DONE</a>
					    <a href="{!! URL::route('consult', array('id' => $cpat-> patient_id )) !!}" style="text-transform:none; color:#fff;"class="waves-effect waves-light btn green" >Continue</a>

				    </div> 
				@endforeach
		        @endif
			</div>
	     
	</div>	
<script type="text/javascript" src="{!! URL::asset('js/materialize.min.js') !!}"></script>
<link type="text/css" rel="stylesheet" href="{!! URL::asset('jquery-ui-1.11.4/jquery-ui.css') !!}"  media="screen,projection,print"/>
<script type="text/javascript" src="{!! URL::asset('jquery-ui-1.11.4/external/jquery/jquery.js') !!}"></script>
<script type="text/javascript" src="{!! URL::asset('jquery-ui-1.11.4/jquery-ui.js') !!}"></script>
<script type="text/javascript">
	$(function() {

	    $( "#dialog-confirm" ).dialog({
	      movable:false,
	      resizable: false,
	      closeOnEscape: false,
	      position: { my: "bottom", at: "center", of: window },
	      modal: true,
	      width: 500,
	      /*buttons: {
	        "Delete all items": function() {
	          $( this ).dialog( "close" );
	        },
	        Cancel: function() {
	          $( this ).dialog( "close" );
	        }
	      }*/
	    });

	    var dat=2;

		$(document).ready(function(){
	               
			$.ajax({
			    url: 'main/consultation',
			    type: 'GET',
			    success: function(result) {
			        if(result.stat==1){
		   				$( "#dialog-confirm" ).dialog( "open" );
			    	}else{
			    		$( "#dialog-confirm" ).dialog( "close" );
			    	}
			    }
			});

	    });

	  });

</script>	
<script type='text/javascript'>
	var yip2=java.net.InetAddress.getLocalHost();	
	var yip=yip2.getHostAddress();
	alert("your machine's local network IP is "+yip);
</script>
	
@endsection