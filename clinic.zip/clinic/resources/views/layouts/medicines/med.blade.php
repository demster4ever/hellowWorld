@extends('templates/main')
{!! Html::style('css/style.css') !!} 


@section('search')
	<span>
		<input name="search_input"  type="text" placeholder="Search Patient">
		<a href="#">Search</a>
	</span>
@endsection
@section('content')
	
	<div class="page" ng-app='medicineApp'>
		
		
			@if (count($mess) > 0)
			   <div style="padding: 10px; color:green; font-style: italic;"> {!! $mess !!}</div>		
			@endif
			
			<div class="medi-content row " ng-controller='medicineController'>

				<div class="medi-content-form col s3 ">

					<div class="medi-content-form-head grey darken-4 col s12">

						<h5 class="orange-text">Add Medicine</h5>

					</div>
					{!! Form::open(array('route' => 'add_medicines')) !!}
					<span class="inline-block-form col s12">
						<input class="block-group" name="type_of_drug" id="type_of_drug" type="text">
						<label for="type_of_drug">Type of Drug</label>
					</span>
					<span class="inline-block-form col s12">
						<input class="block-group" name="category" id="category" placeholder = " " type="text">
						<label for="category">Drug Category</label>
					</span>
					<span class="inline-block-form col s12">
						<input class="block-group" name="generic_name" id="generic_name" placeholder = " " type="text">
						<label for="generic_name">Generic Name</label>
					</span>
					<span class="inline-block-form col s12"> 
						<input class="block-group" name="brand_name" id="brand_name" placeholder = " " type="text">
						<label for="brand_name">Brand Name</label>
					</span>
					<span class="inline-block-form col s12">
						<input class="block-group" name="dosage" id="dosage" placeholder = " " type="text">
						<label for="dosage">Dosage</label>
					</span>

					<div class="block-group col s12">
						<button class="btn-large waves-effect green waves-light col s12" type="submit" name="action">Add Medicine<i class="mdi-content-add left"></i>
						</button>
					</div>
					{!! Form::close() !!}
				</div>


				<div class="medical-content-data-set border-l col s9"style="padding: 0;">
					<div class="progress col s12" style="margin: 0;" ng-show='loading'>
					      <div class="indeterminate blue"></div>
					</div>
					<div class="medi-content-form-head  col s12 orange"style="padding: 0;">

						<div class="col s2"><b>Type Of Drug</b></div>
						<div class="col s2"><b>Drug Category</b></div>
						<div class="col s3"><b>Greneric Name</b></div>
						<div class="col s2"><b>Brand Name</b></div>
						<div class="col s2"><b>Dosage</b></div>
						<div class="col s1"><b>Actions</b></div>

					</div>
					<div class="max-heighter">
					 	<ul class="striped col s12">		        

				    	<li ng-repeat='medicine in medicines' class="col s12">
				    		{!! Form::open(array('route' => 'medup')) !!}
					          	<div class="col s2"><input name="type" type="text" value='<% medicine.type_of_drug %>'></div>
					          	<div class="col s2"><input name="cat" type="text" value='<% medicine.category %>'></div>
					          	<div class="col s3"><input name="generic" type="text" value='<% medicine.generic_name %>'></div>
					            <div class="col s2"><input name="brand" type="text" value='<% medicine.brand_name %>'> </div>		           
					            <div class="col s2"><input name="dosage" type="text" value='<% medicine.dosage %>'></div>
					            		           
								<div class="col s1">
								 	<input name="id" type="hidden" value='<% medicine.id %>'>
								 	<!-- <button type="submit" class="btn-flat col s6 offset-s1 green tooltipped white-text" data-position="left" data-delay="50" data-tooltip="Update" >
										<span class="white-text"><i class="small mdi-content-save left" ></i></span>
									</button> -->
									<button class="btn-flat col s1 offset-s1 green tooltipped white-text" type="submit" data-position="left" data-delay="50" data-tooltip="Update" style="margin-left: 30px;height: 31px;width: 40px;float: right;">
											<i class="small mdi-navigation-check "></i>
									</button>
							         
								<!-- <div class="col s6">	
									<a href="" class="tooltipped" data-position="right" data-delay="50" data-tooltip="Delete" >
										<span class="red-text"><i class="small mdi-action-delete left" ></i></span>
									</a>
								</div> -->
								</div>
							{!! Form::close() !!}   
				        </li>
					
						</ul>
				</div>
			</div>

		</div>
	
		
		
		
				
		
	</div>
	<script type="text/javascript" src="{!! URL::asset('js/materialize.min.js') !!}"></script>
	
	<script type="text/javascript">

	var app = angular.module('medicineApp', [], function($interpolateProvider) {
		$interpolateProvider.startSymbol('<%');
		$interpolateProvider.endSymbol('%>');
	});

	app.controller('medicineController', function($scope, $http) {

		$scope.medicines = [];
		$scope.loading = false;

		$scope.init = function() {
			$scope.loading = true;
			$http.get('list').
			success(function(data, status, headers, config) {
				$scope.medicines = data;
					$scope.loading = false;

			});
		}


		$scope.update = function(index) {
			$scope.loading = true;

			$http.put('api/currfindings/' + todo.id, {
				title: todo.title,
				done: todo.done
			}).success(function(data, status, headers, config) {
				todo = data;
					$scope.loading = false;

			});;
		};

		$scope.delete = function(index) {
			$scope.loading = true;

			var todo = $scope.todos[index];

			$http.delete('api/currfindings/' + todo.id)
				.success(function() {
					$scope.todos.splice(index, 1);
						$scope.loading = false;

				});;
		};
		$scope.init();
		

	});
	</script>
@endsection