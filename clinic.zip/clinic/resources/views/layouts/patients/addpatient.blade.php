@extends('templates/main')
{!! Html::style('css/style.css') !!} 

@section('header')
	<!-- <div class="head-container">
		<span> <p>Welcome!</p> <h3> {!! $name !!}</h3></span>
	</div>
	 -->

@endsection
@section('search')
	@include('layouts.partials.search')
@endsection
@section('content')
	
	<div class="page black-text">
	
		<!-- {!! Form::open(array('route' => 'save_patient')) !!}
		{!! $errors->first('first_name', ':message') !!} -->
		<div class="content">
			<div class="row">
				<div class="vital-header grey darken-4"><d class="orange-text">New Patient's Personal Data</d></div>
					<div class="col s3">
						<div class="">
					
									
									<input class="block-group" name="first_name" id="first_name"  type="text" class="validate">
									 <label for="first_name">First Name</label>
						 </div>
					</div>
						
					<div class="col s2">
						<div class="">

								 
								<input class="block-group" name="middle_name" id="middle_name" type="text" class="validate">
								<label for="middle_name">Middle Name</label>
						</div>
					</div>
					<div class="col s3">
						<div class="">

								
								<input class="block-group" name="last_name" id="last_name" type="text" class="validate">
								<label for="last_name">Last Name</label>
						</div>
					</div>
			</div>
					<div class="row">
						<div class="col s2">	
							<div class="">
								
								<input type="date" class="datepicker" name="date_of_birth" id="date_of_birth">
								<label for="date_of_birth">Date Of Birth</label>
						<!-- <input class="block-group" name="date_of_birth" id="date_of_birth" type="text" class="validate"> -->

							</div>
						</div>
						<div class="col s2">
							<div class="">
									
									<input class="block-group" name="age" id="age" type="text" class="validate">
									<label for="age">Age</label>
							</div>
						</div>
						
						
						<div class="col s2">
							<div class=" col s12">
								<!-- <input  placeholder = "" type="text"> -->
								<select class="browser-default" name="gender" id="gender" value="">
									<option value="Male" selected>Male</option>
									<option value="Female">Female</option>
								</select>
								
							</div>
						</div>
						<div class="col s2">	
							<div class=" col s12">
									<select class="browser-default" name="marital_status" id="marital_status" value="">
										<option value="Single" selected>Single</option>
										<option value="Married">Married</option>
										<option value="Widowed">Widowed</option>
										<option value="Separated">Seperated</option>
									</select>
													
							</div>
						</div>
		</div>
		<div class="row">
			<div class="col s3">
				<div class="">

						
						<input class="block-group" name="occupation" id="occupation" type="text" class="validate">
						<label for="occupation">Occupation</label>
				</div>
			</div>
			<div class="col s2">
				<div class="">

						
						<input class="block-group" name="company" id="company" type="text" class="validate">
						<label for="company">Company</label>
				</div>
			</div>
			<div class="col s3">
				<div class="">

						
						<input class="block-group" name="contact" id="contact" type="text" class="validate">
						<label for="contact">Contact</label>
				</div>
			</div>	
		</div>		
		<div class="row">
			<div class="col s8">
				<div class="">
						
						<input class="block-group" name="address" id="address" type="text" class="validate">
						<label for="address">Address</label>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col s6">				

				<!-- Div for buttons -->
				<div class="cam-controls col s4">
					
						<!-- first set of shown button -->
						<div class="cam-button1 col s12">

							<a class="waves-effect waves-light btn col s12"id="snap" style="display:none;"><i class="mdi-image-camera-alt left"></i>Capture</a>

						</div>
						<!-- second set of shown button -->
						<div class="cam-button1 col s12">
						
							
								<a class="waves-effect waves-light btn col s12"id="reset" style="display:none;"><i class="mdi-navigation-refresh left"></i>Reset</a>
							
							
								<a class="waves-effect waves-light btn col s12"id="upload" style="display:none;"><i class="mdi-file-file-upload left"></i>Upload</a>								
						</div>

					
				</div>	
				<!-- Div for PHOTO -->
				<div class="col s5">
				<div class="photo-holder ">
					<video id="video" style="width:400px; height:300px;"autoplay></video>
       				<canvas id="canvas" width="400" height="300">
				</div>
				</div>

				
			</div>
		</div>
		<div class="row">
			<div class="col s2">
									
				 <a class="waves-effect waves-light btn col s12"id="save" ><i class="mdi-navigation-check left"></i>Add</a>
				
			</div>
		</div>
		
				
		<!-- {!! Form::close() !!} -->
	</div>
	</div>
	<script type="text/javascript" src="{!! URL::asset('js/materialize.min.js') !!}"></script>
	
	

	
	<script>
	$(function () {
     	
      $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
	  });
           // Put event listeners into place
           window.addEventListener("DOMContentLoaded", function() {
               // Grab elements, create settings, etc.
               var canvas = document.getElementById("canvas"),
               	   fName = document.getElementById("first_name"),
               	   mName = document.getElementById("middle_name"),
               	   lName = document.getElementById("last_name"),
               	   bDate = document.getElementById("date_of_birth"),
               	   age = document.getElementById("age"),
               	   gender = document.getElementById("gender"),
               	   status = document.getElementById("marital_status"),
               	   occ = document.getElementById("occupation"),
               	   com = document.getElementById("company"),
               	   con = document.getElementById("contact"),
               	   add = document.getElementById("address"),
                   context = canvas.getContext("2d"),
                   video = document.getElementById("video"),
                   videoObj = { "video": true },
                   image_format= "jpeg",
                   jpeg_quality= 85,
                   errBack = function(error) {
                       console.log("Video capture error: ", error.code); 
                   };


               // Put video listeners into place
               if(navigator.getUserMedia) { // Standard
                   navigator.getUserMedia(videoObj, function(stream) {
                       video.src = stream;
                       video.play();
                       $("#snap").show();
                   }, errBack);
               } else if(navigator.webkitGetUserMedia) { // WebKit-prefixed
                   navigator.webkitGetUserMedia(videoObj, function(stream){
                       video.src = window.webkitURL.createObjectURL(stream);
                       video.play();
                       $("#snap").show();
                   }, errBack);
               } else if(navigator.mozGetUserMedia) { // moz-prefixed
                   navigator.mozGetUserMedia(videoObj, function(stream){
                       video.src = window.URL.createObjectURL(stream);
                       video.play();
                       $("#snap").show();
                   }, errBack);
               }
                     // video.play();       these 2 lines must be repeated above 3 times
                     // $("#snap").show();  rather than here once, to keep "capture" hidden
                     //                     until after the webcam has been activated.  

               // Get-Save Snapshot - image 
               document.getElementById("snap").addEventListener("click", function() {
                   context.drawImage(video, 0, 0, 400, 300);
                   // the fade only works on firefox?
                   $("#video").fadeOut("slow");
                   $("#canvas").fadeIn("slow");
                   $("#snap").hide();
                   $("#reset").show();
                   //$("#upload").show();
               });
               // reset - clear - to Capture New Photo
               document.getElementById("reset").addEventListener("click", function() {
                   $("#video").fadeIn("slow");
                   $("#canvas").fadeOut("slow");
                   $("#snap").show();
                   $("#reset").hide();
                   $("#upload").hide();
               });
               // Upload image to sever 
               document.getElementById("save").addEventListener("click", function(e){
                   var dataUrl = canvas.toDataURL("image/jpeg", 0.85);
                   $("#uploading").show();
                  	e.preventDefault();
                   $.ajax({
                     type: "POST",
                     url: "save",
                     data: { 
                        imgBase64: dataUrl,
                        fname: $('#first_name').val(),
                        mname: $('#middle_name').val(),
                        lname: $('#last_name').val(),
                        bdate: $('#date_of_birth').val(),
	               	    age: $('#age').val(),
	               	    gender: $('#gender').val(),
	               	    stat: $('#marital_status').val(),
	               	    occ: $('#occupation').val(),
	               	    com: $('#company').val(),
	               	    con: $('#contact').val(),
	               	    add: $('#address').val()
                         
                     }
                   }).done(function(msg) {
                     console.log("saved");
                     window.location.replace("../main");
                     
                   });
               });
           }, false);

	
	});
   </script>
   <script>
   navigator.getUserMedia = (navigator.getUserMedia || 
                             navigator.webkitGetUserMedia || 
                             navigator.mozGetUserMedia );
   if (navigator.getUserMedia) 
    {
       navigator.getUserMedia(
          {
             video:true,
             audio:false
          },        
          function(stream) { /* do-say something */ },
          function(error) { alert('Something went wrong. (error code ' + error.code + ')');
               return; }
       );
    }
    else {
       alert("Sorry, the browser you are using doesn't support the HTML5 webcam API");
       return;
    }
    
   </script>
	<script src="{!! URL::asset('js/picker.js') !!}"></script>
	<script src="{!! URL::asset('js/picker.date.js') !!}"></script>
	<script src="{!! URL::asset('js/picker.time.js') !!}"></script>

   <script>
   	$('.datepicker').pickadate({
	    selectMonths: true, // Creates a dropdown to control month
	    selectYears: 150 // Creates a dropdown of 15 years to control year
  	});
   </script>
   
@endsection
