@extends('templates/main')
{!! Html::style('css/style.css') !!}  

@section('header')
	

@endsection
@section('search')
		<span >
			<input name="search_input"  type="text" placeholder="Search Patient">
			{!! Form::submit('Search')!!}
		</span>
@endsection
@section('content')

<div class="page">

	<div class="row">
		
		<div class="col s12 table-height" >

			<h5>List of All Patients</h5>
			
			<table class="striped ">
				<thead>
				<tr>
					  <th data-field="Actions"> Actions</th>
					  <th data-field="avatar">  </th>
					  <th data-field="lastName">Patient Name</th>
					  <th data-field="lastName">Age</th>
					  <th data-field="lastName">Gender</th>
					  <th data-field="lastName">Marital Status</th>
				</tr>	
				</thead>

				<tbody>
				@if (count($patients) > 0)
					@foreach ($patients as $patient)
					<tr>
						
						<td ><a href="{!! URL::route('patient',array('id' => $patient->patient_id)) !!}" class="waves-effect waves-light btn">View</a></td>
						<td style="border-radius:0px; display:inline-block;"> 
			            	<div class="mini-avatar" >
				 				<img src="{!!  URL::asset(''.$patient->img_path) !!}" class="materialboxed">
				 			</div>
						</td>
						<td style="text-transform: capitalize;">{!! $patient->last_name !!}, {!! $patient->first_name !!} {!! $patient->middle_name !!}</td>
						<td> {!! $patient->age!!}</td>
						<td>{!! $patient->gender!!}</td>
						<td>{!! $patient->marital_status!!}</td>
					</tr>
					@endforeach
			
				@endif	
				</tbody>
			</table>

		</div>
		
			
	</div>
	<div class="pagination-holder row">
			@if (count($patients) > 0)
				{!! str_replace('/?', '?', $patients->render()) !!}
			@endif
	</div>
</div>

<!-- <script type="text/javascript" src="{!! URL::asset('js/materialize.min.js') !!}"></script>	 -->	

@endsection
