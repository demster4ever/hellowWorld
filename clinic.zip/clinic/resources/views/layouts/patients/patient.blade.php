@extends('templates/main')
<!-- {!! Html::style('css/style.css') !!}  -->

@section('search')
	<div class="rows">
		<div class="cols s8 offset-s2">
		
			<input name="search_input"  type="text" placeholder="Search Patient">
			<a href="{!! URL::route('search_patients') !!}">Search</a>
		
		</div>
	</div>
@endsection

@section('content')
	
	<div class="page" ng-app="todoApp">
		
		<div class="row">
			<div class="continue-f-button">
			<!-- 	@if (count($patient) > 0)
					@if($patient->patient_id == Session::get('cur_id') && Session::get('roleid')!= 3)	
					<div class="fixed-action-btn " style="top: 10px; right: 25px;">
					    <a href="{!! URL::route('consult',array('id' => $patient->patient_id)) !!}" class="btn btn-large orange tooltipped" data-position="bottom" data-delay="50" data-tooltip="Contintue Consultation">
					      continue 
					    </a>			    
				  	</div>
					@else

					@endif
				@endif -->
			
			</div>
		    <div class="col s12">
		      <ul class="tabs">
		        <li class="tab col s3">
		        	<a class="active" href="#personal-data">Personal Data</a>
		        </li>
		        <li class="tab col s3">
		        	<a href="#vital_statistics">Vital Statistics</a>
		        </li>
		        <li class="tab col s3">
		        	<a href="#laboratory-test">Laboratory Tests</a>
		        </li>
		        <li class="tab col s3">
		        	<a href="#diagnostics">Diagnosis</a>
		        </li>
		   
		        <!-- <li class="tab col s3">
		        	<a href="#bills">Bills</a>
		        </li> -->
		      </ul>
		    </div>
		
			<div id="personal-data" class="col s12">
				<!-- Contetnt 1 -->
		    
				<div class="content">
					

					<div class="patient-info card-panel grey lighten-3 col s9">
						<div class="row">
		    			<div class="vital-header grey darken-4"><d class="orange-text">Personal Data</d></div>

						</div>
						{!! Form::open(array('route' => 'update_patient'))!!}
						<div class="row">
							
							<div class="col s4">
								<div class="">
												
												<input class="block-group" name="first_name" id="first_name"  type="text" class="validate" value="{!! $patient->first_name!!}">
								 				<label for="first_name">First Name</label>

								</div>
							</div>
									
							<div class="col s4">
									<div class="">

											 
											<input class="block-group" name="middle_name" di="middle_name" type="text" class="validate" value="{!! $patient->middle_name!!}">
											<label for="middle_name">Middle Name</label>
									
									</div>
							</div>
							
							<div class="col s4">
									<div class="">

											
											<input class="block-group" name="last_name" id="last_name" type="text" class="validate" value="{!! $patient->last_name!!}">
											<label for="last_name">Last Name</label>
									</div>
							</div>

						</div>
						
						<div class="row">
							<div class="col s3">	
									<div class="">
									
	 										<input type="date" class="datepicker" name="date_of_birth" id="date_of_birth" value="{!! $patient->date_of_birth!!}">
											<label for="date_of_birth">Date Of Birth</label>


									</div>
							</div>
							<div class="col s3">
									<div class="">
												
												<input class="block-group" name="age" id="age" type="text" class="validate" value="{!! $patient->age!!}">
												<label for="age">Age</label>
									</div>
							</div>
							<div class="col s3">
								<div class=" col s12">
									<select class="browser-default" name="gender" value="{!! $patient->gender!!}">
										<option value="" disabled >Gender</option>
										<option value="Male">Male</option>
										<option value="Female">Female</option>
									</select>
								</div>
							</div>
							<div class="col s3">	
								<div class=" col s12">
										<select class="browser-default" name="marital_status" value="{!! $patient->marital_status!!}">
											<option value="" disabled >Marital Status</option>
											<option value="Single">Single</option>
											<option value="Married">Married</option>
											<option value="Widowed">Widowed</option>
											<option value="Separated">Seperated</option>
										</select>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col s4">
								<div class="">

										
										<input class="block-group" name="occupation" id="occupation" type="text" class="validate" value="{!! $patient->occupation!!}">
										<label for="occupation">Occupation</label>
								</div>
							</div>
							<div class="col s4">
								<div class="">

										
										<input class="block-group" name="company" id="company" type="text" class="validate" value="{!! $patient->company!!}">
										<label for="company">Company</label>

								</div>
							</div>
							<div class="col s4">
								<div class="">

										
										<input class="block-group" name="contact" id="contact" type="text" class="validate" value="{!! $patient->contact!!}">
										<label for="contact">Contact</label>

								</div>
							</div>	
						</div>		
						
						<div class="row">
							<div class="col s12">
								<div class="">
										
										<input class="block-group" name="address" id="address" type="text" class="validate" value="{!! $patient->address!!}">
										<label for="address">Address</label>
								</div>
							</div>
						</div>
							
						<!-- <div class="floating-buttons" style="text-align:right;margin-top:90px;">
						 -->	<button type="submit"  class="tooltipped btn" id="update" data-position="left" data-delay="50" data-tooltip="Update" >
								<i class="white-text large mdi-content-save left" ></i>save
							</button>
						<!-- </div> -->
						<input type="hidden" name="test_id" value="{!! $patient->patient_id !!}">
						{!! Form::close() !!}
					</div>

					<div class="card grey lighten-3 col s3">				     			
	      				<div class="card-image col s12">
			              <img src="{!! URL::asset(''.$patient->img_path) !!}" style="margin-bottom:10px;margin-top:10px;">
			          	</div>
	    			</div>
	    			
				</div>
			</div>
		
			<!-- End Content1 -->

		    <div id="vital_statistics" class="col s12">
		    	<div class="content">
		    		<div class="card-panel col s3 grey lighten-3" style="padding:0px;">
		    			<div class="vital-header grey darken-4"><d class="orange-text">Vital Statistics</d></div>
		    			
		    			<div class="vital-content">
		    			{!! Form::open(array('route' => 'update_vital'))!!}
			    			<div class="">
								
								<input class="block-group" name="height" id="height" type="text" class="validate" value="{!! $vital->height !!}">
								<label for="contact">Height (cm)</label>
							</div>
							<div class="">

								
								<input class="block-group" name="weight" id="weight" type="text" class="validate" value="{!! $vital->weight !!}">
								<label for="contact">Weight (kgs)</label>
							</div>
							<div class="">

								
								<input class="block-group" name="pr" id="pulse-rate" type="text" class="validate" value="{!! $vital->pulse_rate !!}">
								<label for="contact">Pulse Rate (beats/min)</label>
							</div>
							<div class="">

								
								<input class="block-group" name="hr" id="breathing-rate" type="text" class="validate" value="{!! $vital->heart_rate !!}">
								<label for="contact">Breathing Rate (breaths/min)</label>
							</div>
							<div class="">

								
								<input class="block-group" name="bp" id="blood-pressure" type="text" class="validate" value="{!! $vital->blood_pressure !!}">
								<label for="contact">Blood Pressure (mm Hg)</label>
							</div>
							<div class="">
								<button class="btn waves-effect waves-light" type="submit" name="action" style="    margin-top: 15px;">
									Save
								    <i class="mdi-content-save left"></i>
								</button>
							</div>
							<input type="hidden" name="id" value="{!! $vital->id !!}">
						{!! Form::close() !!}
						</div>

		    		</div>
		    	</div>

		    </div>

		    <div id="laboratory-test" class="col s12">
		    	<!-- labContent -->

		    	<div class="content">
		    			<div class="card-panel grey lighten-3 row">

		    		 		
		    				<div class="vital-header grey darken-4"><d class="orange-text">Laboratory Tests</d></div>

					      	<div class="lab-test-collection col s12" style="height:50%; font-size:14px; padding:0; overflow-x: hidden ;overflow-y:auto;">
					      		
					      		<ul class="collapsible" data-collapsible="accordion" style="width:inherit;">
								    @if (count($archives) > 0)
								    	@foreach($archives as $archive)	
									    <li>
									      	<div class="collapsible-header" style="padding: 2px 2px 0 0;">
										      	<div class="col s3 truncate">Click to Open</div>
										      	<div class="col s9 btn green"> Laboratory Test:  {!! $archive->test_group_name !!}</div>
									      	</div>
									      	<div class="collapsible-body ">
									      		<div class="result-content row" style="margin: 15px 0 15px 0; color:teal">
									      			<div class="col s4  s-border-b test-res-name">Test Name</div>
									      			<div class="col s3  s-border-b test-res-name">Result</div>
									      			<div class="col s3  s-border-b test-res-range">Range</div>
									      			<div class="col s2  s-border-b test-res-unit">Unit</div>
									      			@foreach($archive->labhistory as $history)
									      			<div class="col s4 border-r s-border-b test-res-name">{!! $history->test !!}</div>
									      			<div class="col s3 border-r s-border-b test-res-name">{!! $history->result !!}</div>
									      			<div class="col s3 border-r s-border-b test-res-range">{!! $history->range !!}</div>
									      			<div class="col s2 s-border-b test-res-unit">{!! $history->units !!}</div>
									      			@endforeach
									      		</div>			     
									      	</div>
									    </li>
									    
									    @endforeach
								    @else
								    	<div style="font-style:italic;">No laboratory tests yet.</div>
								    @endif

								</ul>
								
					      	</div>
					      	<div class="">
					      		<a data-target="add-lab-modal" id="add-lab" href="#add-lab-modal" class="waves-effect waves-light btn"><i class="mdi-content-add left"></i>Add laboratory</a>
					      	</div>
		   
		    			</div>

		    	</div>

		    </div>
			<!-- End Lab Content -->

		    <div id="diagnostics" class="col s12">
		    	<div class="content">


		    			<div class="card-panel grey lighten-3 row">

		    		 		
		    				<div class="vital-header grey darken-4"><d class="orange-text">Diagnostics</d></div>

					      	<div class="lab-test-collection col s12" style="height:50%; font-size:14px; padding:0; overflow-x: hidden ;overflow-y:auto;">
					      		
					      		<ul class="collapsible" data-collapsible="accordion" style="width:inherit;">
								   		@if (count($consultations) > 0)
								   			@foreach($consultations as $consultation)
											    <li>
											      <div class="collapsible-header" style="padding: 2px 2px 0 0;">
											      	<div class="col s3 truncate">{!! $consultation->date !!} </div>
											      	<div class="col s9 btn green">Click to Open Consultation: {!! $consultation->consultation_id !!} </div>
											      </div>
											      <div class="collapsible-body ">
											      		<div class="result-content row" style="margin: 15px 0 15px 0; color:teal;">
											      			<div class="row">
																<div class="col s2  s-border-b test-res-name">Findings</div>
												      			<div class="col s2  s-border-b test-res-name">Treatments</div>
												      			<div class="col s8  s-border-b test-res-range">Prescriptions</div>
											      			</div>
											      			
											      			<div class="row">
											      				
											      				
											      				<div class="col s2 border-r test-res-name">
											      					*@foreach($consultation->findings as $f)
											      					{!! $f->findings !!} <br>
											      					@endforeach
											      					  
											      				</div>
											      				
												      			
												      			<div class="col s2 border-r test-res-name">

												      				*@foreach($consultation->treatments as $t)
												      					{!! $t->treatment !!} <br>
												      				@endforeach

												      			</div>

												      			<div class="col s8 border-r test-res-range">

												      				<div class="col s4  s-border-b test-res-name">Greneric Name</div>
													      			<div class="col s3  s-border-b test-res-name">Brand Name</div>
													      			<div class="col s3  s-border-b test-res-range">Dosage</div>
													      			<div class="col s2  s-border-b test-res-unit">Duration</div>

													      			<div class="row">
																		@foreach($consultation->prescriptions as $p)
															      			<div class="col s4 border-r test-res-name">
															      				{!! $p->generic !!}
															      			</div>
															      			<div class="col s3 border-r test-res-name">
															      				{!! $p->brand !!}
															      			</div>
															      			<div class="col s3 border-r test-res-range">
															      				{!! $p->dosage !!}
															      			</div>
															      			<div class="col s2 test-res-unit">
															      				{!! $p->days !!}
															      			</div>
														      			@endforeach	
													      			</div>
												      			

											      				</div>
											      			</div>

											      			<div class="row">
											      				<div class="col s2 test-res-name">Remarks</div>
											      				<div class="col s10 test-res-range">

											      				{!! $consultation->remarks !!}

											      				</div>
											      			</div>
											      			
											      		</div>			     
											      </div>
											      
											    </li>
											@endforeach

									    
									   	@else
								    	 <div style="font-style:italic;">No Diagnostics yet.</div>
								  		@endif

								</ul>
								
					      	</div>
					      	
		   
		    			</div>

		    	</div>
		    </div>

		    <div ng-controller="subtestController">
				<!-- Lab Test -->
				<div id="add-lab-modal" class="modal bottom-sheet" >
					<div class="closer right">
				    		<a href="#!" class="waves-effect waves-light btn col s12 modal-action modal-close red tooltipped" data-position="left" data-delay="50" data-tooltip="Close" 
				    		style="margin: 10px 10px;"><i class="large mdi-navigation-close" ></i></a>
					</div>
					<div class="modal-content grey darken-4"style="height: inherit;">
					    	<!-- Content of MOdal -->
					    	<h4 class="white-text">Add Laboratory Test</h4>

					    <div class="card" style="height:100%; font-size: 1.5rem; color: teal;">

					    	<ng-form id="test" name="test" >
						    	<div class="card-panel row">
						    		<div class="col s10">
						    				<div class="row" style="" >
							     				<div class="col s8 ">
								     				<div class="col s4">
														<input  required id="testgroup_name" ng-model="test_group_name" placeholder="Ex. Complete Blood Count"name="test_group_input" type="text" autocomplete="on" class="validate"/>
														<label for="testgroup_name">Test Group</label> <div class="help-block error" ng-show="test.test_group_input.$error.required">Required</div>

													</div>
												
													<div class="col s4">
														<input  id="datepicker" class="datepicker" ng-model="date_taken" name="date_taken" type="date"/>
														<label for="datepicker">Test Taken</label>
													</div>
													or Select Test Group Template
												</div>
												<div class="col s4">
													<select style="display:block; height:50px; width: 250px; color: #000; margin:0px;" ng-options="template as template.test_group_name for template in templates"
									     				 ng-model="selected" ng-change="hasChanged()"><option value="" disabled selected>Test Group</option></select>
												</div>
									     	</div>

									     	<div class="row"  >
									      		<div class="col s8">									
														<div class="col s4">
															<input  ng-model="test_name" id="test_name"  name="test_input" Type="text" autocomplete="on" />
															<label for="test_name">Test Name</label><div id="cont" class=""></div>
														</div>
														<div class="col s4">
															<input  ng-model="testresult"id="testresult"  name="result_input" Type="text" autocomplete="on" />
															<label for="testresult">Result</label><div id="cont" class=""></div>
														</div>
														<div class="col s4">
															<input  ng-model="testrange" id="testrange"  name="range_input" Type="text" autocomplete="on" />
															<label for="testrange">Range and Unit</label><div id="cont" class=""></div>
														</div>					
												</div>
												<div class="col s2">
														<button ng-click="addTempTests()" class="btn orange">Add Test</button>
												</div><br><br> 
									      	</div>	
						    		</div>
						    		<div class="col s2">
						    			<div>
						    					<input type="text"  style="display:none;" id="id" name="patient_id" ng-init="patient_id = {!! $patient->patient_id !!}" ng-model="patient_id">
										 		<button  ng-hide="test.test_group_input.$error.required" ng-click="saveTempToPermanentResults()" style="height: 100px; padding: 5px; color:#fff;" class="waves-effect waves-light btn green tooltipped" data-position="left" data-delay="50" data-tooltip="Add">
												Save Test
												</button>
										 </div>
						    		</div>
						    		
						    	</div>
						    </ng-form> 	 
						    <div class="card-panel grey lighten-3 row" style="font-size: 1rem; color: green;">
						    	
						      	<table class="collection" style="text-align:left;" >
								<thead>
									<tr>
										<td> <div style="width:300px;" class="border-r">Test Name</div></td>
										
										<td> <div class="border-r"> Result</div></td>
										<td> <div style="width:300px;" >Range & Unit</div></td>
										
										<td>  </td>
									</tr>
								</thead>
								<tbody>
									<tr class="row collection-item" ng-repeat='temptest in temptests'>
										<td><div style="width:300px;" class="border-r"> <% temptest.test_name %></div> </td>
										<td><input  class="border-r" style="width:200px;" ng-model="temptest.result" id="testresult"  
											name="result" Type="text" value="<% temptest.result %>" /></td>
										<td><div style="width:300px;"><% temptest.rangeunit %></div></td>
										<td >
											<a href="#!"  ng-click="deleteTempTests($index)" class="col s6 offset-s6 btn-flat red tooltipped" data-position="left" data-tooltip="Remove" >
												<i class="white-text small mdi-navigation-close "></i>	
										</td>
									</tr>
								</tbody>
								
								</table>
						    </div>	
						    	
					    </div>
					      			      
					</div>			   
				</div>
		    
		   	</div>

		</div>
	</div>
	
	
<!-- <script type="text/javascript" src="{!! URL::asset('js/jquery-2.1.1.min.js') !!}"></script>
<script type="text/javascript" src="{!! URL::asset('js/materialize.min.js') !!}"></script> -->
@endsection

@section('autosearch')

	<script type="text/javascript">
		$('#add-lab').leanModal({
	      dismissible: true, // Modal can be dismissed by clicking outside of the modal
	      opacity: .5, // Opacity of modal background
	      in_duration: 300, // Transition in duration
	      out_duration: 200, // Transition out duration
	      }
	  	);

		$(document).ready(function(){
			$('input:text').bind({

			});

			$("#auto_find").autocomplete({
				minLength:1,
				autoFocus: true,	
				source: '{!! URL('getdata') !!}'
			});

		});

	</script>

	<script src="{!! URL::asset('js/picker.js') !!}"></script>
	<script src="{!! URL::asset('js/picker.date.js') !!}"></script>
	<script src="{!! URL::asset('js/picker.time.js') !!}"></script>

	<script>
		$('.datepicker').pickadate({
	    selectMonths: true, // Creates a dropdown to control month
	    selectYears: 150, // Creates a dropdown of 15 years to control year
		format: 'yyyy-mm-dd'
		});


		function openWindow(pid,cid) {
    		window.open("http://192.168.254.5/clinic/public/doc/medold?pid="+pid+"&d="+cid, "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=0, left=0, width=1050, height=900");
    	}
    	
    	function openPrescriptions() {
    		window.open("http://192.168.254.5/clinic/public/doc/presc", "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=0, left=0, width=1050, height=750");
    	}

    	function openFitToWork(pid,cid) {
    		window.open("http://192.168.254.5/clinic/public/doc/ftwold?pid="+pid+"&d="+cid, "_blank", "toolbar=no, scrollbars=yes, resizable=no, top=0, left=0, width=1050, height=900");
    	}
	</script>

@endsection