@extends('templates/main')
{!! Html::style('css/style.css') !!} 

@section('header')
<!-- <div class="row">
		<div class="col s3 offset-s1">
			<div class="card-panel teal lighten-2">
				<div class="head-container">
					<i class="material-icons large center ">account_circle</i>Welcome!<h3> {!! $name !!}</h3>
				</div>
			</div>
		</div>
	</div> -->
@endsection
@section('search')
	<span>
		<input name="search_input"  type="text" placeholder="Search Patient">
		<!-- <a href="{!! URL::route('search_patients') !!}">Search</a> -->
	</span>
@endsection
@section('content')
	
	<div class="page-main">
			<div class="card-panel teal lighten-4">
				<h5>You have <strong>{!! $rcount !!}</strong> result(s).</h5>
			</div>
		<!-- @foreach ($pats as $patient)
		<div class="block-group-btn">
			<a href="{!! URL::route('patient',array('id' => $patient->patient_id)) !!}" class="a-btn">View</a> <p class="text-p">{!! $patient->last_name !!},{!! $patient->first_name !!} {!! $patient->middle_name !!}</p>
		</div>
		
		
		@endforeach -->
<div class="row">	
	<div class="col s6">
		<table class="hoverable">
        <thead>
          <tr>
              <th data-field="name">Patient's Name</th>
              <th data-field="Actions">Actions</th>
          </tr>
        </thead>

        <tbody>
          @foreach ($pats as $patient)
          <tr>
            <td>{!! $patient->last_name !!}, {!! $patient->first_name !!} {!! $patient->middle_name !!} </td>
            <td><a href="{!! URL::route('patient',array('id' => $patient->patient_id)) !!}" class="waves-effect waves-light btn">View</a></td>
          </tr>
          @endforeach
        </tbody>
      </table>
	</div>
</div>
	</div>
@endsection