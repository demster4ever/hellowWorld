@extends('templates/main')
{!! Html::style('css/style.css') !!} 

@section('message')
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Send message</div>
                    {!! Form::open(array('url' => 'sendmessage')) !!}

                        <input type="text" name="message" >
                        <button class="btn-large waves-effect waves-light col s12" type="submit" name="action">Send
                            <i class="material-icons"></i>
                        </button>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>

@endsection