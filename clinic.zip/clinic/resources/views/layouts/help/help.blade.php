@extends('templates/main')
{!! Html::style('css/style.css') !!} 

@section('content')
	
	<div class="page-main help_page" >
		
    <div class="col s12">
      <ul class="tabs">
        <li class="tab "><a href="#test9">I.	How to Create a User</a></li>
        <li class="tab "><a href="#test2">II.	How to Login</a></li>
        <li class="tab "><a href="#test3">III.	How to Add A Patient</a></li>
        <li class="tab "><a href="#test4">IV.	How to Consult</a></li>
        <li class="tab "><a href="#test5">V.	Payment</a></li>
        <li class="tab "><a href="#test6">VI.	Add medcines</a></li>
        <li class="tab "><a href="#test7">VII.	Add Laboratories</a></li>
      </ul>
    </div>

    <div id="test9" class="help-content col s12">
        	<p>
        		<h4>Steps</h4>
        		<ol>
        			<li>Click “Create New User”.</li>
                    <div class="help_pic col s12"><img src="{!!  URL::asset('img/help/user/step1.png') !!}"></div>
        			<li>Fill in the Necessary information needed .</li>
        			<li>Click choose a role for the user.</li>
        			<li>Using the “CAPTURE” button, click it to take a picture of the user.**Note: Allow camera to be accessed!**</li>
        			<li>Click “SAVE USER”.</li>
                    <div class="help_pic col s12"><img src="{!!  URL::asset('img/help/user/step2.png') !!}"></div>
        			<li>Proceed To login</li>

        		</ol>		
        	</p>
            	
            	

    </div>

    <div id="test2" class=" help-content col s12">

            <p>
                <h4>Steps</h4>
                <ol>
                    <li>Fill in your Username and Password in their corresponding fields.</li>
                    <li>Click Login.</li>
                    <!-- <li>Click choose a role for the user.</li>
                    <li>Using the “CAPTURE” button, click it to take a picture of the user.</li>
                    <li>Click “SAVE USER”.</li>
                    <li>Proceed To login</li>
         -->        <div class="help_pic col s12"><img src="{!!  URL::asset('img/help/login/howtologin.png') !!}"></div>
                </ol>       
            </p>
               
                <!-- <div class="col s12"><img src="{!!  URL::asset('img/help/user/step2.png') !!}"></div> -->



    </div>

    <div id="test3" class="help-content col s12">
        <p>
            <h4>Steps</h4>
            <ol>
                <li>On the right side of the screen, click the box “NEW PATIENT”.</li>
                <div class="help_pic col s12"><img src="{!!  URL::asset('img/help/add_patient/step1.png') !!}"></div>
                <li>Fill-up the necessary information needed.</li>
                <li>Take a picture of the Patient by clicking “CAPTURE”</li>
                <li>Then, Click “ADD”.</li>
                <!-- <li>Click “SAVE USER”.</li>
                <li>Proceed To login</li> -->
                <div class="help_pic col s12"><img src="{!!  URL::asset('img/help/add_patient/step234.png') !!}"></div>
            </ol>       
        </p>

            
            



    </div>

    <div id="test4" class="help-content col s12">

        <p>
            <h4>Steps</h4>
            <ol>
                <li>On left side of the screen click “APOINTMENTS”.</li>
                <div class="help_pic col s12"><img src="{!!  URL::asset('img/help/consult/step1.png') !!}"></div>
                <li>Once inside the Appointments page, select a patient to consult by clicking “CONSULT”.</li>
                  <div class="help_pic col s12"><img src="{!!  URL::asset('img/help/consult/step2.png') !!}"></div>
                <li>Click enter the findings in the findings area. If the findings are already in the system, it will be provided and should be clicked to select. If not, enter it manually. Then, click the “+” button. If  there are more than one(1) value for findings, repeat this step and enter it individually.</li>
                <li>Click enter the findings in the findings area. If the findings are already in the system, it will be provided and should be clicked to select. If not, enter it manually. Then, click the “+” button. If  there are more than one(1) value for findings, repeat this step and enter it individually.</li>
                <li>Just like in the findings area, enter a value in the Treatments area. The values will be provided if available, if not, enter manually. Then, click “+” to confirm.
                *If there are other details to the patient’s case, you can put it in the remarks field.*
                </li>

                <li>To Release Documents like Medical Certificates and Fit-to-Work, click their corresponding buttons.

                    <ol>
                        <li>Medical certificates- everything is inserted. Check or edit the values if needed. Note area is provided, fill-in if needed.</li>
                        <li>Click print. Setup then print.</li>
                        <li>Fit to Work- everything is inserted. Check or edit the values if needed. Note area is provided, fill-in if needed.</li>
                    </ol>   
                </li>
                <li>Prescriptions
                    <ol>

                        <li>Click the prescriptions button.</li>
                        <li>Enter the needed medicine for the patient by filling the values needed (values are supplied if available) , then, click the add button. Repeat step for the next medicine</li>
                        <li>Click Done.</li>
                        <li>Check or edit the values if needed. Note area is provided, fill-in if needed.</li>
                        <li>Click print. Setup then print.</li>


                    </ol>
                </li> 
                <div class="help_pic col s12"><img src="{!!  URL::asset('img/help/consult/step345678.png') !!}"></div>
                <li>Add Laboratory.
                    <ol>
                        <li>Click Add Laboratory</li>
                        <li>Select Group</li>
                        <li>Select Examinations  and Enter Values.</li>
                        <li>Click ADD.</li>

                    </ol>
                
                </li>
                <div class="help_pic col s12"><img src="{!!  URL::asset('img/help/consult/step81234.png') !!}"></div>
                <li> Done.
                 <div class="help_pic col s12"><img src="{!!  URL::asset('img/help/consult/step9.png') !!}"></div> 
                    <ol>
                        <li> Enter charge description and price. Repeat step for multiple charges. Then, submit.</li>
                    </ol>
                </li>
                <div class="help_pic col s12"><img src="{!!  URL::asset('img/help/consult/step91.png') !!}"></div>

            </ol>       
        </p>
            
          
          
           
           
            

    </div>

    <div id="test5" class="help-content col s12">

        <p>
            <h4>Steps</h4>
            <ol>
                <li>On your right side, select the paying patient by clicking the pay button.</li>
                <div class="help_pic col s12"><img src="{!!  URL::asset('img/help/payment/step1.png') !!}"></div>
                <li>Enter the amount rendered then click pay</li>
                <div class="help_pic col s12"><img src="{!!  URL::asset('img/help/payment/step2.png') !!}"></div>

            </ol>       
        </p>

    </div>
    <div id="test6" class="help-content col s12">

          <p>
            <h4>Steps</h4>
            <ol>



                <li>Click “ADMIN” on your left side</li>
                <li>Click “MEDICINES”</li>
                <li>Fill in the Values Needed</li>              
                <li>Click “ADD”</li>
                <div class="help_pic col s12"><img src="{!!  URL::asset('img/help/medicines/step12.png') !!}"></div>
               

            </ol>       
        </p>

    </div>
    <div id="test7" class="help-content col s12">


         <p>
            <h4>Steps</h4>
            <ol>



                <li>Click “ADMIN” on your left side</li>
                <li>Click “Laboratories”</li>
                              
                <li>Test Group
                    <ol>
                        <li>Click New Test Group.</li>
                        <li>Enter Values needed.</li>
                        <li>Click save</li>
                    </ol>
                </li> 
                <div class="help_pic col s12"><img src="{!!  URL::asset('img/help/labs/group.png') !!}"></div>
                <li>Sub Test Group
                    <ol>
                        <li>Click New Sub Test Group.</li>
                        <li>Enter Values needed.</li>
                        <li>Click save</li>
                    </ol>
                </li>
                <div class="help_pic col s12"><img src="{!!  URL::asset('img/help/labs/sub.png') !!}"></div>
                <li>Detailed Test
                    <ol>
                        <li>Click New Test</li>
                        <li>Enter Values needed.</li>
                        <li>Click save</li>
                    </ol>
                </li>
                <div class="help_pic col s12"><img src="{!!  URL::asset('img/help/labs/detailed.png') !!}"></div>           
               

            </ol>       
        </p>


    </div>
  </div>

	</div>
	<script type="text/javascript" src="{!! URL::asset('js/materialize.min.js') !!}"></script>

@endsection