@extends('templates/landing')

@section('content')
	{!! Html::style('css/style.css') !!}

	<div class="page_login">
	<div id="content">
		{!! Form::open(array('route' => 'login')) !!}
		<!-- <form action="/users/login" method="post" > -->
		<div class="row">	
				<div class="col s8 offset-s2">
					<div class="card-panel grey lighten-4">	
						<div class="row">
							<br><br>	
							<div class="cols s6">
								
				        		<div class="input-field col s8 offset-s2">
				        			<i class="mdi-action-account-circle prefix"></i>
									<input class="validate" id="username"  name="username" Type="text" />
									<label for="username">Username</label>
								</div>
							</div>
							<div class="cols s6">
								<div class="input-field col s8 offset-s2">
									<i class="mdi-communication-vpn-key prefix"></i>
									<input class="validate" id="password"  name="password" Type="password"/>
									<label for="password">Password</label>									
								</div>
								<!-- {!! Form::text('password',null,['class'=>'form-control']) !!} -->
							</div>
							
							
							<div class="input-field col s8 offset-s2">

				           			 <button class="btn-large waves-effect waves-light col s12" type="submit" name="action">Login<i class="material-icons"></i>
									</button>
				       		</div>

				       		<div class="col s8 offset-s2" style="text-align: center;">
				       			<br>
								<p><a href="users/create">Create New User</a></p>
							</div>	
							
						</div>
					</div>
		<!-- </form> -->
		{!! Form::close() !!}
			</div>
		</div>
	</div>
</div>
@endsection