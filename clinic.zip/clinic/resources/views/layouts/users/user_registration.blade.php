@extends('templates/landing')

@section('content')
	{!! Html::style('css/style.css') !!} 
	{!! Html::style('css/materialize.min.css') !!} 
	{!! Html::style('css/mat-icon.css') !!} 
	
	<div class="page">
		<div class="row register_input">
			<div class="card grey lighten-3 col s8 offset-s2">
		<!-- 	{!! Form::open(array('route' => 'save_user')) !!} -->
					<h4>Creat User</h4>
					<div class=" col s6 ">						
						<input id="username"  name="username" type="text" class="validate"/>
						<label for="userName">Username</label>
					</div>
					<div class=" col s6">
						
						<input id="password"  name="password" type="password"/>
						<label for="password">Password</label>

					</div>
					<div class=" col s12">
						<input id="first_name"  name="first_name" type="text" >

						<label for="firstName">First Name</label>
					</div>
					<div class=" col s12">
						<input id="middle_name"  name="middle_name" type="text" />
						<label for="middleName">Middle Name</label>
					</div>
					<div class=" col s12">						
						<input id="last_name"  name="last_name" type="text" />
						<label for="lastName">Last Name</label>
					</div>
					<div class=" col s4">			
						<input type="date" class="datepicker" name="date_of_birth" id="date_of_birth">
						<label for="date_of_birth">Date Of Birth</label>
					</div>
					<div class=" col s2">						
						<input id="age"  name="age" type="text" />
						<label for="age">Age</label>
					</div>
					<div class=" col s2">
						<select class="browser-default" id="gender" name="gender" value="">
							<option value="Male" selected>Male</option>
							<option value="Female">Female</option>
						</select>
					</div>
					
					<div class=" col s4">					
							<select id="roleid" class="browser-default" name="role_id" value="">
								<option value="2" selected>[1] Doctor</option>
								<option value="3" >[2] Staff</option>
							</select>
					</div>
					<div class=" col s12">						
						<input id="address"  name="address" type="text"/>
						<label for="address">Address</label>
					</div>
					<div class=" col s12 " style="margin-top: 20px;">	
							<!-- Div for buttons -->
							<div class="cam-controls col s4" style="margin-bottom: 13em;">
								
									<!-- first set of shown button -->
							<div class="cam-button1 col s12">

								<a class="waves-effect waves-light btn col s12"id="snap" style="display:none;"><i class="mdi-image-camera-alt left"></i>Capture</a>

							</div>
							<!-- second set of shown button -->
							<div class="cam-button1 col s12">
							
								
									<a class="waves-effect waves-light btn col s12"id="reset" style="display:none;"><i class="mdi-navigation-refresh left"></i>Reset</a>
								
								
									<a class="waves-effect waves-light btn col s12"id="upload" style="display:none;"><i class="mdi-file-file-upload left"></i>Upload</a>								
							</div>


								
							</div>	
							<!-- Div for PHOTO -->
							<div class="col s6">
								<div class="photo-holder ">
									<video id="video" style="width:400px; height:300px;"autoplay></video>
			       					<canvas id="canvas" width="400" height="300">
								</div>
							</div>
							
					</div>
					<!-- Submit -->
					<div style="display:block; height:auto;">
						<div class=" col s4 offset-s4 " >		
							<a href="#!" class="col s12 btn-large green waves-effect waves-light" id="save"style="margin-bottom: 1.5em;margin-top: 115px;" name="action">Save User
							    <i class="large mdi-content-save left"></i>
							</a>
						</div>
						<div class=" col s4" >		
							<a href="{!! URL::route('index') !!}" class="col s12 btn-large red waves-effect waves-light" style="margin-bottom: 1.5em;margin-top: 115px;" type="submit" name="action">Cancel
							    <i class="large mdi-navigation-cancel left"></i>
							</a>
						
						
						</div>
					</div>
					
			</div>	
		</div>
	</div>
	<script>
	$(function () {
      
      $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
	  });
           // Put event listeners into place
           window.addEventListener("DOMContentLoaded", function() {
               // Grab elements, create settings, etc.
               var canvas = document.getElementById("canvas"),
                   context = canvas.getContext("2d"),
                   video = document.getElementById("video"),
                   videoObj = { "video": true },
                   image_format= "jpeg",
                   jpeg_quality= 100,
                   errBack = function(error) {
                       console.log("Video capture error: ", error.code); 
                   };


               // Put video listeners into place
               if(navigator.getUserMedia) { // Standard
                   navigator.getUserMedia(videoObj, function(stream) {
                       video.src = stream;
                       video.play();
                       $("#snap").show();
                   }, errBack);
               } else if(navigator.webkitGetUserMedia) { // WebKit-prefixed
                   navigator.webkitGetUserMedia(videoObj, function(stream){
                       video.src = window.webkitURL.createObjectURL(stream);
                       video.play();
                       $("#snap").show();
                   }, errBack);
               } else if(navigator.mozGetUserMedia) { // moz-prefixed
                   navigator.mozGetUserMedia(videoObj, function(stream){
                       video.src = window.URL.createObjectURL(stream);
                       video.play();
                       $("#snap").show();
                   }, errBack);
               }
                     // video.play();       these 2 lines must be repeated above 3 times
                     // $("#snap").show();  rather than here once, to keep "capture" hidden
                     //                     until after the webcam has been activated.  

               // Get-Save Snapshot - image 
               document.getElementById("snap").addEventListener("click", function() {
                   context.drawImage(video, 0, 0, 400, 300);
                   // the fade only works on firefox?
                   $("#video").fadeOut("slow");
                   $("#canvas").fadeIn("slow");
                   $("#snap").hide();
                   $("#reset").show();
                   //$("#upload").show();
               });
               // reset - clear - to Capture New Photo
               document.getElementById("reset").addEventListener("click", function() {
                   $("#video").fadeIn("slow");
                   $("#canvas").fadeOut("slow");
                   $("#snap").show();
                   $("#reset").hide();
                   $("#upload").hide();
               });
               // Upload image to sever 
               document.getElementById("save").addEventListener("click", function(){
                   var dataUrl = canvas.toDataURL("image/jpeg", 0.85);
                   $("#uploading").show();
                   $.ajax({
                     type: "POST",
                     url: "save",
                     data: { 
                        imgBase64: dataUrl,
                        username:$('#username').val(),
                        password:$('#password').val(), 
                        fname: $('#first_name').val(),
                        mname: $('#middle_name').val(),
                        lname: $('#last_name').val(),
                        bdate: $('#date_of_birth').val(),
	               	    age: $('#age').val(),
	               	    gender: $('#gender').val(),
	               	    role: $('#roleid').val(),
	               	    add: $('#address').val(),

                         
                     }
                   }).done(function(msg) {
                     console.log("saved");
                     
                     window.location.replace("../users");
                     
                   });
               });
           }, false);

	
	});
   </script>
   <script>
   navigator.getUserMedia = (navigator.getUserMedia || 
                             navigator.webkitGetUserMedia || 
                             navigator.mozGetUserMedia );
   if (navigator.getUserMedia) 
    {
       navigator.getUserMedia(
          {
             video:true,
             audio:false
          },        
          function(stream) { /* do-say something */ },
          function(error) { alert('Something went wrong. (error code ' + error.code + ')');
               return; }
       );
    }
    else {
       alert("Sorry, the browser you are using doesn't support the HTML5 webcam API");
       return;
    }
    
   </script>
	<script type="text/javascript" src="{!! URL::asset('js/materialize.min.js') !!}"></script>
	<script type="text/javascript" src="{!! URL::asset('js/jquery-2.1.1.min.js') !!}"></script>

	<script src="{!! URL::asset('js/picker.js') !!}"></script>
	<script src="{!! URL::asset('js/picker.date.js') !!}"></script>
	<script src="{!! URL::asset('js/picker.time.js') !!}"></script>

   <script>
   	$('.datepicker').pickadate({
	    selectMonths: true, // Creates a dropdown to control month
	    selectYears: 150 // Creates a dropdown of 15 years to control year
  	});
   </script>
@endsection