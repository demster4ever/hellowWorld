var app = angular.module('todoApp', [], function($interpolateProvider) {
	$interpolateProvider.startSymbol('<%');
	$interpolateProvider.endSymbol('%>');
});

app.controller('todoController', function($scope, $http) {

	$scope.todos = [];
	$scope.loading = false;

	$scope.init = function() {
		$scope.loading = true;
		$http.get('/clinic/public/api/currfindings').
		success(function(data, status, headers, config) {
			$scope.todos = data;
				$scope.loading = false;

		});
	}

	$scope.addTodo = function() {
				$scope.loading = true;

		$http.post('/clinic/public/api/currfindings', {
			findings: document.getElementById("auto_find").value
			//findings: $scope.todo.title
			//done: $scope.todo.done
		}).success(function(data, status, headers, config) {
			$scope.todos.push(data);
			$scope.todo = '';
				$scope.loading = false;

		});
	};

	$scope.updateTodo = function(todo) {
		$scope.loading = true;

		$http.put('/clinic/public/currfindings/' + todo.id, {
			title: todo.title,
			done: todo.done
		}).success(function(data, status, headers, config) {
			todo = data;
				$scope.loading = false;

		});;
	};

	$scope.deleteTodo = function(index) {
		$scope.loading = true;

		var todo = $scope.todos[index];

		$http.delete('/clinic/public/api/currfindings/' + todo.id)
			.success(function() {
				$scope.todos.splice(index, 1);
					$scope.loading = false;

			});;
	};
	$scope.init();
	

});

app.controller('todo2Controller', function($scope, $http) {

	$scope.todos2 = [];
	$scope.loading = false;
	$scope.dosageT = '';
	$scope.durationT ='';
	$scope.init = function() {
		$scope.loading = true;
		$http.get('/clinic/public/api/currtreatments').
		success(function(data, status, headers, config) {
			$scope.todos2 = data;
				$scope.loading = false;

		});
	}

	$scope.addTodo2 = function() {

		$http.post('/clinic/public/api/currtreatments', {
			treatment: $scope.todo2.title
			//done: $scope.todo.done
		}).success(function(data, status, headers, config) {
			$scope.todos2.push(data);
			$scope.todo2 = '';
				$scope.loading = false;

		});
	};

	

	$scope.deleteTodo2 = function(index) {
		$scope.loading = true;

		var todo2 = $scope.todos2[index];

		$http.delete('/clinic/public/api/currtreatments/' + todo2.id)
			.success(function() {
				$scope.todos2.splice(index, 1);
					$scope.loading = false;

			});;
	};
 
 	$scope.prescriptions = [];

	$scope.initPres = function() {
		
		$http.get('/clinic/public/api/currprescriptions').
		success(function(data, status, headers, config) {
			$scope.prescriptions = data;

		});
	}

	$scope.addPrescription = function() {
				
		$http.post('/clinic/public/api/currprescriptions', {
			generic: $('#generic').val(),
			brand: document.getElementById("brand").value,
			dosage: document.getElementById("dosage").value,
			intake: document.getElementById("dosageType").value,
			intakeType : $scope+' '+dosageT,
			duration: document.getElementById("durationType").value,
			durationType: $scope.durationT
			
		}).success(function(data, status, headers, config) {
			$scope.prescriptions.push(data);
			$scope.prescription = '';

		});
	};

	$scope.deletePrescription = function(index) {
		
		var pres = $scope.prescriptions[index];

		$http.delete('/clinic/public/api/currprescriptions/' + pres.id)
			.success(function() {
				$scope.prescriptions.splice(index, 1);
					
			});;
	};

	$scope.showSelectValue = function(mySelect) {
   	 console.log(mySelect);
   	 $scope.dosageT = mySelect;
	}

	$scope.showSelectDur = function(mySelect) {
   	 console.log(mySelect);
   	 $scope.durationT = mySelect;
	}

	$scope.init();
	$scope.initPres();

});

app.controller('subtestController', function($scope, $http, $window) {

	$scope.tests = [];
	$scope.stests = [];
	$scope.results = [];
	$scope.testgroups = [];
	$scope.labhistory = [];
	
	$scope.templates = [];

	 /*  $scope.selected = $scope.fieldTable[0];*/

	  $scope.hasChanged = function() {
			alert($scope.selected.test_group_name);
			$scope.test_group_name = $scope.selected.test_group_name
			$http.post('/clinic/public/labtest/tests',{
				test_group_name: $scope.test_group_name

			}).success(function(data, status, headers, config) {
				$scope.temptests = data;
					

			});
	  }


	$scope.init = function() {
		
		$http.get('/clinic/public/tests').
		success(function(data, status, headers, config) {
			$scope.tests = data;
				

		});
	};
	
	// $scope.initHistory = function() {
		
	// 	$http.get('results/history')
	// 	.success(function(data, status, headers, config) {
			
	// 		 $scope.added = data;

	// 	});
	// };

	// $scope.initHistory();
	$scope.showSubTests = function(index) {
		var sub = $scope.tests[index];
		$http.get('/clinic/public/sub/' + sub.id )
		.success(function(data, status, headers, config) {
			$scope.stests = data;

		});
	}

	$scope.showResults = function(index) {
		var res = $scope.stests[index];
		$http.get('/clinic/public/results/' + res.id )
		.success(function(data, status, headers, config) {
			$scope.results = data;

		});
	}
	$scope.added = [];
	$scope.saveResults = function() {


        localStorage.setItem('remarks', $('#remarks').val());
		$http.post('/clinic/public/results/save', {
			results: $scope.results

		}).success(function(data, status, headers, config) {
				
				location.reload();
		});
	}

	$scope.history = function(index) {
		var his = $scope.testgroups[index];
		$http.get('/clinic/public/labhistory/' + his.id )
		.success(function(data, status, headers, config) {
			$scope.labhistory = data;

		});
	}

	$scope.testgroups = function() {
		
		$http.get('/clinic/public/labtestgroups/show' )
		.success(function(data, status, headers, config) {
			$scope.testgroups = data;

		});
	}

	$scope.deleteHistory = function(index) {
		
		var pres = $scope.testgroups[index];

		$http.delete('/clinic/public/testgroups/remove/' + pres.id)
			.success(function() {
				$scope.testgroups.splice(index, 1);
				$scope.labhistory = [];
					
			});;
	};

	$scope.bills = [];
	
	$scope.initBill = function() {
		$scope.loading = true;
		$http.get('/clinic/public/bills').
		success(function(data, status, headers, config) {
			$scope.bills = data;
		});
	}
	$scope.addBill = function() {

		$http.post('/clinic/public/bill/add', {
			description: $scope.desc,
			amount: $scope.amt
			
		}).success(function(data, status, headers, config) {
			$scope.bills.push(data);
			$scope.desc='';
			$scope.amt='';
			$scope.initBill();
		});
	};
	$scope.deleteBill = function(index) {

		var bill = $scope.bills[index];

		$http.delete('/clinic/public/bill/delete/' + bill.id)
			.success(function() {
				$scope.bills.splice(index, 1);
		
		});;
	};

	$scope.temptests = [];
	$scope.initTempTests = function() {
		$scope.loading = true;
		$http.get('/clinic/public/temptests',{
		}).
		success(function(data, status, headers, config) {
			$scope.temptests = data;
		});
	}
	$scope.addTempTests = function() {

		$http.post('/clinic/public/temptests/add', {
			patient_id: $scope.Id,
			test_name: $scope.test_name,
			result: $scope.testresult,
			rangeunit: $scope.testrange
			
		}).success(function(data, status, headers, config) {
			$scope.temptests.push(data);
			$scope.test_name='';
			$scope.testresult='';
			$scope.testrange='';
			$scope.initTempTests();
		});
	};
	$scope.deleteTempTests = function(index) {

		var temptest = $scope.temptests[index];

		$http.delete('/clinic/public/temptests/delete/' + temptest.id)
			.success(function() {
				$scope.temptests.splice(index, 1);
				
		});;
	};

	$scope.saveTempToPermanentResults = function() {

		$http.post('/clinic/public/labtest/saveTempToPermanentResults', {
			patient_id: $scope.Id,
			test_group_name: $scope.test_group_name,
			results: $scope.temptests,
			date_taken: $scope.date_taken
			
		}).success(function(data, status, headers, config) {
			$scope.date_taken='';
			$scope.test_group_name='';
			$scope.initTempTests();
			$window.alert("Test Reults Saved!");
			$window.location.reload();
		});
	};
	
	$scope.initTemplates = function() {
		
		$http.get('/clinic/public/labtest/showTemplates').
		success(function(data, status, headers, config) {
			$scope.templates = data;
				

		});
	};


	$scope.initBill();
	$scope.initTempTests();
	$scope.init();
	$scope.testgroups();
	$scope.initTemplates();	
	
});

app.directive('autoCompleteDirective', function($http){
	return{
		restrict: 'A',
		scope:{ url : '@'},
		link:function(scope,elm,attrs){
			elm.autocomplete({
				source:function(request,response){
					$http({

						method:'jsonp',
						url:scope.url,
						params: {q:request.term}

						}).success(function(data){
							response(data);
						})

				},
				minLength : 3
			})
		}
	}
});
