var app2 = angular.module('todo2App', [], function($interpolateProvider) {
	$interpolateProvider.startSymbol('<%');
	$interpolateProvider.endSymbol('%>');
});

app2.controller('todo2Controller', function($scope, $http) {

	$scope.todos2 = [];
	$scope.loading = false;

	$scope.init = function() {
		$scope.loading = true;
		$http.get('api/currtreatments').
		success(function(data, status, headers, config) {
			$scope.todos2 = data;
				$scope.loading = false;

		});
	}

	$scope.addTodo2 = function() {
				$scope.loading = true;

		$http.post('api/currtreatments', {
			treatment: $scope.todo2.title
			//done: $scope.todo.done
		}).success(function(data, status, headers, config) {
			$scope.todos2.push(data);
			$scope.todo2 = '';
				$scope.loading = false;

		});
	};

	

	$scope.deleteTodo2 = function(index) {
		$scope.loading = true;

		var todo2 = $scope.todos2[index];

		$http.delete('api/currtreatments/' + todo2.id)
			.success(function() {
				$scope.todos2.splice(index, 1);
					$scope.loading = false;

			});;
	};
 

	$scope.init();

});