<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vitals extends Model
{
    protected $table = 'vital';
    protected $primaryKey = 'id';


	public function patient()
	{
		return $this->belongsTo('App\Patients');
	}
}
