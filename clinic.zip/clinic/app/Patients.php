<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Validator;
class Patients extends Model
{
   protected $table = 'patients'; 
   protected $primaryKey = 'patient_id';
   protected $fillable = ['first_name', 'middle_name', 'last_name', 'age', 'gender','date_of_birth','marital_status','current_appts_id','occupation', 'address', 'contact'];

   public static $rules = array
   (
		'first_name' => 'required|min:4:max:50',
		'middle_name' => 'required|min:4:max:50',
		'last_name' => 'required|min:4:max:50',
		'age' => 'required|min:1',
		'gender' => 'required|min:4',
		'date_of_birth' => 'required|min:4:max:50'

		 );

	public static function validate($data)
	{
		return Validator::make($data,static::$rules);
	}

	public function appointments()
	{
		return $this->belongsTo('App\CurrentAppointments');
	}

	public function consultations()
	{
		return $this->hasMany('App\Consultation');
	}

	public function vitals()
	{
		return $this->hasOne('App\Vitals');
	}
}
