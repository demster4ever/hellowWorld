<?php

namespace App\Events;

use App\Events\Event;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class ConsultationStatus extends Event implements ShouldBroadcast
{
    use SerializesModels;

    public $stat;

    public function __construct($patient, $docAvailable)
    {
        $this->stat = array( 
            'name' => $patient,
            'status' => $docAvailable
            );
    }

    public function broadcastOn()
    {
        return ['test-channel'];
    }
}
