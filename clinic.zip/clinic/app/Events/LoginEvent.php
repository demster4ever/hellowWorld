<?php

namespace App\Events;

use App\Users;
use Session;
use App\Events\Event;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class LoginEvent extends Event implements ShouldBroadcast
{
    use SerializesModels;

    //public $data;
    public $user;

    
    public function __construct($u,$p)
    {
       
        $this->user = array( 
            'user' => $u,
            'p_waiting' => $p

            );
        
    }

    public function broadcastOn()
    {   
        
        return ['test-channel'];
    }
}
