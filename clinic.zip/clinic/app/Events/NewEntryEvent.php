<?php

namespace App\Events;

use App\Events\Event;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class NewEntryEvent extends Event implements ShouldBroadcast
{
    use SerializesModels;

    //public $data;
    public $stat;

    public function __construct()
    {
        
        $this->stat = array( 
            'stat' => 'New Patient Added.'
            );
        
    }

    public function broadcastOn()
    {
        return ['test-channel'];
    }
}
