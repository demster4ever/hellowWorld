<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Validator;
use App\UserInterface;
use App\RemindableInterface;

class Users extends Model 
{
	protected $table = 'users'; 
    protected $primaryKey = 'id';
    //protected $fillable = ['username', 'password', 'first_name', 'middle_name', 'last_name', 'age', 'gender', 'address', 'role_id'];

    public static $rules = array
   (
		'username' => 'required|min:1:max:50',
		'password' => 'required|min:1:max:50'
	);

	public static function validate($data)
	{
		return Validator::make($data,static::$rules);
	}

	public function notifications()
	{
	    return $this->hasMany('Notification');
	}

	public function newNotification()
	{
	    $notification = new Notification;
	    $notification->user()->associate($this);
	 
	    return $notification;
	}
}
