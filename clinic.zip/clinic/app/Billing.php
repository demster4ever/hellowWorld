<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Billing extends Model
{
    protected $table = 'billings';
    protected $primaryKey = 'id';


	public function bills()
	{
		return $this->hasMany('App\Bill');
	}
}
