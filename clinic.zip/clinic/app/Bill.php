<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bill extends Model
{
    protected $table = 'bill';
    protected $primaryKey = 'id';


	public function billing()
	{
		return $this->belongsTo('App\Billing');
	}
}
