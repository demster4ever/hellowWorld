<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CurrPrescriptions extends Model
{
    protected $table = 'curr_prescriptions';

    public function consultation()
 	{
 		return $this->belongsTo('App\Consultation','consultation_id');
 	}
}
