<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LabArchives extends Model
{
    protected $table = 'lab_archives';
    protected $primaryKey = 'id';
    
    public function labhistory()
	{
		return $this->hasMany('App\LabTestHistory');
	}
}
