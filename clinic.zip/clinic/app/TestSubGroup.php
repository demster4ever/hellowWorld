<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TestSubGroup extends Model
{
	protected $table = 'test_sub_group';
	
	protected $fillable = ['groud_id', 'name','description'];

    public function group()
	{
		return $this->belongsTo('App\TestGroup');
	}

	public function test()
    {
    	return $this->hasMany('Test');
    }
}
