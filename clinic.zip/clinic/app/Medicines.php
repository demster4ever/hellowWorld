<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Validator;

class Medicines extends Model
{
    public static $rules = array
   (
		'generic_name' => 'required|min:1:max:500',
		// 'brand_name' => 'required|min:0:max:500',
		'dosage' => 'required|min:1:max:500'
	);

	public static function validate($data)
	{
		return Validator::make($data,static::$rules);
	}
}
