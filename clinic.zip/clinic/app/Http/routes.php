<?php
Route::resource('api/currtreatments','CurrTreatmentsController');  
Route::resource('api/currfindings','CurrFindingsController');  
Route::resource('api/currprescriptions','CurrPrescriptionsController'); 

Route::get('todoapp','TodoAppController@index');        

Route::post('/users/login', ['uses' =>'UsersController@login', 'as'=>'login']);
Route::get('/users', ['uses' =>'UsersController@index', 'as'=>'index']);
Route::get('/users/create',['uses'=>'UsersController@create' , 'as' => 'create']);
Route::post('/users/save',['uses'=>'UsersController@save' , 'as' => 'save_user']);

Route::get('/main',['uses' =>'MainController@index', 'as' => 'main_index']);
Route::get('help',['uses' =>'MainController@help', 'as' => 'help']);

Route::get('/patient/create',['uses' => 'PatientController@create','as' => 'add_patient']);
Route::post('/patient/save',['uses' => 'PatientController@save','as' => 'save_patient']);
Route::get('/patient',['uses' => 'PatientController@index','as' => 'view_patients']);
Route::post('patient/update',['uses' => 'PatientController@updatePatientInfo','as' => 'update_patient']);
Route::post('vitals/update',['uses' => 'PatientController@updateVital','as' => 'update_vital']);

Route::get('patient/{id}',array('as' => 'patient','uses' => 'PatientController@show'));
Route::post('/patient/search',['as' => 'search_patients',function(){
		$name = Input::get('search_input');
        $rCount =  DB::table('patients')->where('last_name','like','%'.$name.'%')
        ->orWhere('first_name','like','%'.$name.'%')->count();
        $patients = DB::table('patients')->where('last_name','like','%'.$name.'%')
        ->orWhere('first_name','like','%'.$name.'%')->orderBy('last_name','asc')->get();
        return View::make('layouts.patients.searchresults')->with('pats', $patients)
        ->with('title','Search results')->with('rcount', $rCount)->with('name',Session::get('name'));
}]);

Route::get('/appointments',['uses' => 'AppointmentsController@index', 'as' => 'cur_appt']);
Route::get('/appointments/current/{id}',['uses' => 'AppointmentsController@consult', 'as' => 'consult']);
//Route::get('current',['uses' => 'AppointmentsController@consultCurrent', 'as' => 'consultC']);
Route::get('next',['uses' => 'AppointmentsController@doneCurrent', 'as' => 'nextC']);
Route::get('markAsDone/{id}',['uses' => 'AppointmentsController@markAsDone', 'as' => 'markAsDone']);
Route::post('schedule/{id}',['uses' => 'AppointmentsController@schedulePatient', 'as' => 'schedule']);

Route::get('doc/rec',['uses' => 'DocumentsController@rec', 'as' => 'medc']);
Route::get('doc/rectemplate',['uses' => 'DocumentsController@rectemplate', 'as' => 'medctemplate']);
Route::get('doc/medcert',['uses' => 'DocumentsController@medcert', 'as' => 'medc']);
Route::get('doc/medcerttemplate',['uses' => 'DocumentsController@medcerttemplate', 'as' => 'medctemplate']);
Route::get('doc/medold',['uses' => 'DocumentsController@medold', 'as' => 'medc']);
Route::get('doc/presc',['uses' => 'DocumentsController@prescriptions', 'as' => 'pres']);
Route::get('doc/presctemplate',['uses' => 'DocumentsController@prescriptionstemplate', 'as' => 'prestemplate']);
Route::get('doc/ftw',['uses' => 'DocumentsController@fittowork', 'as' => 'ftw']);
Route::get('doc/ftwtemplate',['uses' => 'DocumentsController@fittoworktemplate', 'as' => 'ftwtemplate']);
Route::get('doc/ftwold',['uses' => 'DocumentsController@fittoworkold', 'as' => 'ftwold']);

Route::get('reports',['uses' => 'ReportsController@index', 'as' => 'view_reports']);

Route::get('/medicines/add',['uses'=> 'MedicinesController@index', 'as' => 'medicines']);
Route::post('/medicines/save',['uses'=> 'MedicinesController@save', 'as' => 'add_medicines']);
Route::get('medicines/generics/{any}',['uses'=> 'MedicinesController@generics', 'as' => 'generics']);
Route::get('medicines/brands/{any}',['uses'=> 'MedicinesController@brands', 'as' => 'brands']);
Route::get('medicines/dosages/{generic}/{brand}',['uses'=> 'MedicinesController@dosage', 'as' => 'brands']);
Route::get('medicines/list',['uses'=> 'MedicinesController@viewAllMedicines', 'as' => 'list']);
Route::post('medicines/update',['uses'=> 'MedicinesController@updateMed', 'as' => 'medup']);
Route::delete('medicines/delete',['uses'=> 'MedicinesController@deleteMed', 'as' => 'deleteUp']);

Route::get('/findings/add',['uses'=> 'FindingsAndTreatmentsController@index', 'as' => 'findings']);
//Route::post('/findings/save',['uses'=> 'FindingsAndTreatmentsController@save', 'as' => 'add_findings']); //Original
Route::get('/findings/save',['uses'=> 'FindingsAndTreatmentsController@save', 'as' => 'add_findings']);

Route::get('getdata', function(){
	$term = Input::get('term');

	$data = DB::table('findings')->where('findings', 'like',$term.'%')
								  ->groupBy('findings')
								  ->take(10)
								  ->get();
	$return_array = array();
	foreach ($data as $v) {
		$return_array[]  = ['value' => $v->findings ];
	}
	return Response::json($return_array);
});

Route::get('socket', 'SocketController@index');
Route::post('sendmessage', 'SocketController@sendMessage');
Route::get('writemessage', 'SocketController@writemessage');

Route::get('writemessage', function () {
    // this fires the event
    event(new App\Events\LoginEvent('OK!'));
    return "event fired";
});

Route::get('labtest',['uses' => 'LaboratoryTestController@labtest','as' => 'labtest']);
Route::get('group',['uses' => 'LaboratoryTestController@index','as' => 'group']);
Route::get('sub',['uses' => 'LaboratoryTestController@subgroup','as' => 'sub']);

Route::post('groupUp',['uses' => 'LaboratoryTestController@updateTestGroup','as' => 'groupup']);
Route::get('groupDel/{id}',['uses' => 'LaboratoryTestController@deleteTestGroup','as' => 'groupdel']);
Route::post('sgroupUp',['uses' => 'LaboratoryTestController@updateSTestGroup','as' => 'sgroupup']);
Route::get('sgroupDel/{id}',['uses' => 'LaboratoryTestController@deleteSTestGroup','as' => 'sgroupdel']);
Route::post('testUp',['uses' => 'LaboratoryTestController@updateTest','as' => 'testup']);
Route::get('testDel/{id}',['uses' => 'LaboratoryTestController@deleteTest','as' => 'testdel']);

Route::get('tests',['uses' => 'LaboratoryTestController@showTests','as' => 'tests']);
Route::get('sub/{id}',['uses' => 'LaboratoryTestController@showSubtest','as' => 'subs']);
Route::get('results/{id}',['uses' => 'LaboratoryTestController@showResults','as' => 'results']);
Route::get('labtestgroups/show',['uses' => 'LaboratoryTestController@showTestGroups','as' => 'tgroups']);
Route::get('labhistory/{id}',['uses' => 'LaboratoryTestController@showHistory','as' => 'lhistory']);
Route::delete('testgroups/remove/{id}',['uses' => 'LaboratoryTestController@deleteHistory','as' => 'dhistory']);

Route::post('save_testgroup', function(){
 
	DB::table('test_group')->insert(
	            ['group_name' => Input::get('name'), 'group_description' => Input::get('description')]);

	return Redirect::route('group');
});

Route::post('save_subtest', function(){

    $tgroup = App\TestGroup::find(Input::get('group_name'));        
	
	$sub = new App\TestSubGroup();
    $sub->group_id = Input::get('group_name');
    $sub->name = Input::get('sub_name');
    $sub->description = Input::get('sub_description');
    

    $tgroup->sub_group()->save($sub);

	return Redirect::route('sub');
});

Route::post('save_test', function(){

	$desc = Input::get('description');
	$units = Input::get('units');
	$range = Input::get('range');

 	DB::table('test')->insert(
	            ['sgroup_id' => Input::get('sub_id'),
	             'name' => Input::get('name'),'description' => $desc,
	            'units' => $units,'range' => $range
	            ]);

	return Redirect::route('labtest');
}); 

Route::post('results/save',['uses' => 'LaboratoryTestController@saveResults']); 

Route::get('results/history',['uses' => 'LaboratoryTestController@showHistory']); 

Route::get('search', function(){

	$term = Request::get('name');
	$data = DB::table('patients')->where('first_name', 'like',$term.'%')
								 ->orWhere('last_name', 'like',$term.'%')
								  ->groupBy('last_name')
								  ->get();
	return $data;
});

Route::get('bills',['uses' => 'BillingController@index']);
Route::post('bill/add',['uses' => 'BillingController@add']);
Route::get('bill/update',['uses' => 'BillingController@createBillingInfo']);
Route::get('bill/skip',['uses' => 'BillingController@skipBillingInfo']);
Route::delete('bill/delete/{id}',['uses' => 'BillingController@delete']);
Route::get('bill/getBillingInfo',['uses' => 'BillingController@getBillingInfo']);
Route::get('bill/getBillingInfo_paid',['uses' => 'BillingController@getBillingInfo_paid']);
Route::get('bill/viewBillingInfo/{id}',['uses' => 'BillingController@viewBillingInfo']);
Route::post('bill/pay',['uses' => 'BillingController@payBill', 'as' => 'paybill']);

Route::get('temptests',['uses' => 'TempTestsController@index']);
Route::post('temptests/add',['uses' => 'TempTestsController@add']);
Route::delete('temptests/delete/{id}',['uses' => 'TempTestsController@delete']);

Route::post('labtest/saveTempToPermanentResults',['uses' => 'LaboratoryTestController@saveTempToPermanentResults']);
Route::get('labtest/showTemplates',['uses' => 'LaboratoryTestController@showTemplates']);
Route::post('labtest/tests',['uses' => 'LaboratoryTestController@showTemplateTests']);

Route::get('main/consultation', function()
{
	
	$cnt = DB::table('curr_consultation')->count();
	$patient;
	if($cnt>0){
		$pat = DB::table('curr_consultation')->select('patient_id')->first();
		$patient = DB::table('patients')->where('patient_id','=', $pat->patient_id)->first();
		
		$patfullname = $patient->first_name . " " .$patient->last_name;
		
		return response()->json(['name'=> $patfullname,'id'=>$patient->patient_id,'stat'=>1]);
	}else{

		return response()->json(['stat'=>0]);;
	}

	

    //return Session::get('pName');
});

            