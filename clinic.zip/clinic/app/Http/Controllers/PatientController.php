<?php

namespace App\Http\Controllers;

use App\Patients;
use Carbon\Carbon;
use App\Consultation;
use App\Events\LoginEvent;
use App\Events\NewEntryEvent;
use App\CurrentAppointments;
use View,Request,Redirect,Input,DB,Session,Event;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;
use App\LabArchives;
use App\TestHistory;
use App\Billing;
use App\Vitals;

class PatientController extends Controller
{
    public function index()
    {
            
        $patients = DB::table('patients')->orderBy('last_name','asc')->paginate(10);

        if (Session::has('name')) {
          $name = Session::get('name');
          
          return View::make('layouts.patients.viewpatients')->with('patients',$patients)
              ->with('title', 'Patients')->with('name',$name);
         }else{
          return Redirect::route('index');
         }
        
    }

    public function create()
    {   
        
         if (Session::has('name')) {
          $name = Session::get('name');
          return View::make('layouts.patients.addpatient')->with('title', 'New Patient')->with('name',$name );
         }else{
          return Redirect::route('index');
         }
         
    }

    public function show($id)
    {
            $patient = Patients::find($id);

            $archives = LabArchives::where('patient_id',$id)->with('labhistory')->get();

            $consultations = Consultation::with('findings','prescriptions','treatments')->where('patient_id',$id)->get();

            $vital = Vitals::where('patient_id',$id)->get()->first();

            if(!$vital){
                $this->saveVital($id);
                $vital = Vitals::where('patient_id',$id)->get()->first();
            }
            Session::put('view_pat_id',$patient->patient_id);
            $name = Session::get('name');

            return View::make('layouts.patients.patient')
                    ->with('patient',$patient)
                    ->with('title', 'Patient')
                    ->with('name',$name)
                    ->with('consultations',$consultations)
                    ->with('archives',$archives)
                    ->with('vital',$vital);
    }

    public function save(){

        // $validation = Patients::validate(Input::all());

        // if($validation->fails()){
        //     return Redirect::route('add_patient')
        //     ->withErrors($validation)->withInput();

        // }else{}
            if($_POST['fname']){
                if (Session::has('name')) {
                    $name = Session::get('name');
                }

                $dt  = Carbon::now();
                $appt_id = $dt->toDateString(); 

                $cnt = DB::table('curr_appts')->where('curr_appts_id', '=',$appt_id)->count();
                
                if($cnt<1){
                    DB::table('curr_appts')->insert(['curr_appts_id' => $appt_id]);
                }

                $appointment = CurrentAppointments::find($appt_id);
                
                $rawData = $_POST['imgBase64'];
                $filteredData = explode(',', $rawData);
                $unencoded = base64_decode($filteredData[1]);

                $datime = date("Y-m-d-H.i.s", time() ) ; # - 3600*7

                $userid  = 'bac';

                // name & save the image file 
                $fp = fopen('photos/'.$datime.'-'.$userid.'.jpg', 'w');
                fwrite($fp, $unencoded);
                fclose($fp);

                $path = 'photos/'.$datime.'-'.$userid.'.jpg';

                $patient = new Patients();
                $patient->first_name = $_POST['fname'];
                $patient->middle_name = $_POST['mname'];
                $patient->last_name = $_POST['lname'];
                $patient->age = $_POST['age'];
                $patient->gender = $_POST['gender'];
                $patient->date_of_birth = $_POST['bdate'];
                $patient->marital_status = $_POST['stat'];
                $patient->occupation = $_POST['occ'];
                $patient->address = $_POST['add'];
                $patient->contact = $_POST['con'];
                $patient->company = $_POST['com'];
                $patient->current_appointments_id = $appt_id;
                $patient->status_id = 1;
                $patient->img_path = $path;

                $appointment->patients()->save($patient);

                $count =  DB::table('patients')->where('current_appointments_id','=',$appt_id)->count();

                /*Event::fire(new LoginEvent($name, $count));
                Event::fire(new NewEntryEvent());*/
                
                $id = $patient->patient_id;
                $this->saveVital($id);

                return Redirect::route('patient', array('id' => $id));

            }else{

                if (Session::has('name')) {
                    
                  $name = Session::get('name');

                  return View::make('layouts.patients.addpatient')->with('title', 'New Patient')->with('name',$name );

                }else{

                  return Redirect::route('index');

                }

            }
            

                    
    }

    public function search()
    {
        if (Input::has('search_input'))
        {
            $name = Input::get('search_input');
        }else{
            $name = '1731923721030';
        }
        
        
        $rCount = Patients::where('last_name', 'like',$name.'%')->orWhere('first_name', 'like',$name.'%')->count();

        $patients = DB::table('patients')->where('last_name','like',$name.'%')
                                        ->orWhere('first_name', 'like',$name.'%')
                                        ->orderBy('last_name','asc')->get();


        return View::make('layouts.patients.searchresults')->with('pats', $patients)->with('title','Search results')->with('rcount', $rCount);
    }

    public function updatePatientInfo(){

        $patient = Patients::find(Request::get('test_id'));
        $id = $patient->patient_id;
        $patient->first_name = Request::get('first_name');
        $patient->middle_name = Request::get('middle_name');
        $patient->last_name = Request::get('last_name');
        $patient->age = Request::get('age');
        $patient->gender = Request::get('gender');
        $patient->date_of_birth = Request::get('date_of_birth');
        $patient->marital_status = Request::get('marital_status');
        $patient->occupation = Request::get('occupation');
        $patient->address = Request::get('address');
        $patient->contact = Request::get('contact');
        $patient->company = Request::get('company');
        $patient->save();

        return Redirect::route('patient',array('id'=>$id));
    }

    public function saveVital($id){

        $vital = new Vitals();
        $vital->id = mt_rand(0000000001, 9999999999);
        $vital->patient_id = $id;
        $vital->save();

    }


    public function updateVital(){

        $vital = Vitals::find(Request::get('id'));
        $vital->height = Request::get('height');
        $vital->weight =Request::get('weight');
        $vital->pulse_rate = Request::get('pr');
        $vital->heart_rate = Request::get('hr');
        $vital->blood_pressure = Request::get('bp');
        $vital->save();

        return Redirect::route('patient',array('id'=> $vital->patient_id));
    }

}
