<?php

namespace App\Http\Controllers;

use DB,Request,Session;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class TempTestsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        $patient_id = Request::get('patient_id');
        if(Session::get('view_pat_id')){
            $patient_id = Session::get('view_pat_id');
        }
        

        $temptests = DB::table('temporary_test')->where('patient_id','=',$patient_id)
                                ->where( 'test_archive_id','=', 999 )
                                ->get();

        return $temptests;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function add()
    {
        $id = mt_rand(0000000001, 9999999999);
        $patient_id = Request::get('patient_id');
        if(Session::get('view_pat_id')){
            $patient_id = Session::get('view_pat_id');
        }
        $test_archive_id = 999;
        $test_group_name = "temp";
        $test_name = Request::get('test_name');
        $result = Request::get('result');
        $rangeunit = Request::get('rangeunit');

        DB::table('temporary_test')->insert(
                    ['id' => $id, 'patient_id' => $patient_id,'test_archive_id' => $test_archive_id,
                    'test_group_name' => $test_group_name, 'test_name' => $test_name,'result' => $result,'rangeunit' => $rangeunit]);

        $temptests = DB::table('temporary_test')->where('patient_id','=',$patient_id)
                                ->where( 'test_archive_id','=', $test_archive_id )
                                ->get();

        return $temptests;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function delete($id)
    {
        DB::table('temporary_test')->where('id','=',$id)->delete();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    
}
