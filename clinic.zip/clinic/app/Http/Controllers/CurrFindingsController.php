<?php

namespace App\Http\Controllers;

use Request,Session, DB;
use App\CurrFindings;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Carbon\Carbon;

class CurrFindingsController extends Controller
{
   
    public function index()
    {
        $findings = DB::table('curr_findings')
                ->where('patient_id', '=',Session::get('cur_id'))
                ->where( DB::raw('DATE(created_at)'),'=',Carbon::today())
                ->get();
        return $findings;
    }

    public function store()
    {
        $finding = new CurrFindings();

        $finding->patient_id = Session::get('cur_id');
        $finding->findings =  Request::get('findings');
        $finding->save();

        //$finding = CurrFindings::create(Request::all());
        return $finding;
    }

    public function destroy($id)
    {
        CurrFindings::destroy($id);
    }
}
