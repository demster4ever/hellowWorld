<?php

namespace App\Http\Controllers;

use App\Users;
use Carbon\Carbon;
use View,Redirect,Log,DB,Input,Request;
use App\Http\Requests,Session;
//use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class UsersController extends Controller
{
    
    public function index()
    {
       /* if(!Session::get('user'))*/
        return View::make('layouts.users.user_login')->with('title','User Login');
    }

    public function create()
    {
        return View::make('layouts.users.user_registration')->with('title','Create User');
    }

    public function login(){
        
        
        $validation = Users::validate(Input::all());

        if($validation->fails()){
            return Redirect::route('index')
            ->withErrors($validation)->withInput();

        }else{

            $i_user = Input::get('username');
            $i_pwd = Input::get('password');

            $dt  = Carbon::now();
            $appt_id = $dt->toDateString(); 

            $cnt = DB::table('curr_appts')->where('curr_appts_id', '=',$appt_id)->count();

            $pwd = DB::table('users')->where('username', $i_user)->value('password');
            $user_id = DB::table('users')->where('username', $i_user)->value('id');

            if($pwd == $i_pwd){
                $user = DB::table('users')->where('id', $user_id)->first();
                Session::put('name', $user->first_name);
                Session::put('id',$user->id);
                Session::put('roleid', $user->role_id);
                
                if($cnt<1){
                    DB::table('curr_appts')->insert(['curr_appts_id' => $appt_id]);
                }

                    Session::put('img', $user->user_img_path);
                               
                return Redirect::route('main_index')->with('user', $user);
            }else{
                error_log('Username or Password is incorrect.');
                return Redirect::route('index');
            }
        }
        
            
    }

    public function save(){

        $rawData = $_POST['imgBase64'];
        $filteredData = explode(',', $rawData);
        $unencoded = base64_decode($filteredData[1]);

        $datime = date("Y-m-d-H.i.s", time() ) ; # - 3600*7

        $userid  = 'bac';

        // name & save the image file 
        $fp = fopen('photos/'.$datime.'-'.$userid.'.jpg', 'w');
        fwrite($fp, $unencoded);
        fclose($fp);

        $path = 'photos/'.$datime.'-'.$userid.'.jpg';

        $user = new Users();
        $user->username = $_POST['username'];
        $user->password = $_POST['password'];
        $user->first_name = $_POST['fname'];
        $user->middle_name = $_POST['mname'];
        $user->last_name = $_POST['lname'];
        $user->date_of_birth = $_POST['bdate'];
        $user->age = $_POST['age'];
        $user->gender = $_POST['gender'];
        $user->role_id = $_POST['role'];
        $user->address = $_POST['add'];
        $user->status_id = 0;
        $user->user_img_path = $path;

        $user->save();

        return Redirect::route('index');
    }

}
