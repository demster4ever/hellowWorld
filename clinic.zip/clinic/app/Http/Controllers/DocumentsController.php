<?php

namespace App\Http\Controllers;


use App\Patients;
use View,Session,DB,Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Carbon\Carbon;

class DocumentsController extends Controller
{
    
    public function medcert()
    {

        $patient = Patients::find(Session::get('cur_id'));
        $fname =  $patient->first_name ;
        $fullname =  $fname + 'Mark';

        $findings = DB::table('curr_findings')->where('patient_id',Session::get('cur_id'))
                                            ->where( DB::raw('DATE(created_at)'),'=',Carbon::today())
                                            ->get();

        return View::make('layouts.docs.medical_certificate')->with('patient',$patient)
                                        ->with('fullname',$fullname)
                                        ->with('findings', $findings);
    }

    public function medcerttemplate()
    {

        return View::make('layouts.docs.medical_certificate_template');
    }

    public function rec()
    {
        $patient = DB::table('patients')
                ->where('patient_id', '=',Session::get('cur_id'))
                ->first();
        
        return View::make('layouts.docs.rec')->with('patient',$patient);
    }

    public function rectemplate()
    {
              
        return View::make('layouts.docs.rec_template');
    }

    public function prescriptions()
    {
        $curr_prescriptions = DB::table('curr_prescriptions')
                ->where('patient_id', '=',Session::get('cur_id'))
                ->where( DB::raw('DATE(created_at)'),'=',Carbon::today())
                ->get();
        
        $patient = DB::table('patients')
                ->where('patient_id', '=',Session::get('cur_id'))
                ->first();
        
        return View::make('layouts.docs.prescriptions')->with('prescriptions',$curr_prescriptions)->with('patient',$patient);
    }

    public function prescriptionstemplate()
    {
              
        return View::make('layouts.docs.prescriptions_template');
    }

    public function fittowork()
    {

        $patient = Patients::find(Session::get('cur_id'));
        
        $findings = DB::table('curr_findings')->where('patient_id',Session::get('cur_id'))
                    ->where( DB::raw('DATE(created_at)'),'=',Carbon::today())->get();

        return View::make('layouts.docs.fit_to_work')->with('patient',$patient)
                                        ->with('findings', $findings);
    }

    public function fittoworktemplate()
    {

        return View::make('layouts.docs.fit_to_work_template');
    }


    public function medold()
    {

        $patient = Patients::find(Request::get('pid'));
        $fname =  $patient->first_name ;

        $findings = DB::table('curr_findings')->where('patient_id',$patient->patient_id)
                                            ->where( 'consultation_id','=',Request::get('cid'))
                                            ->get();

        return View::make('layouts.docs.medical_certificate')->with('patient',$patient)
                                        ->with('findings', $findings);
    }

    public function fittoworkold()
    {

        $patient = Patients::find(Request::get('pid'));
        $fname =  $patient->first_name ;

        $findings = DB::table('curr_findings')->where('patient_id',$patient->patient_id)
                                            ->where( 'consultation_id','=',Request::get('cid'))
                                            ->get();

        return View::make('layouts.docs.fit_to_work')->with('patient',$patient)
                                        ->with('findings', $findings);
    }

}
