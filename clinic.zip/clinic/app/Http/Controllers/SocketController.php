<?php

namespace App\Http\Controllers;

use LRedis,Request,Event,Session;
use App\Http\Requests;
use App\Events\LoginEvent;
use App\Http\Controllers\Controller;

class SocketController extends Controller
{
    public function __construct()
    {
        $this->middleware('guest');
    }
    public function index()
    {
         if (Session::has('name')) {
          $name = Session::get('name');
            return view('layouts.messages.sockets')->with('title','SOCKETS')->with('name', $name);
        }
    }
    public function writemessage()
    {
         if (Session::has('name')) {
          $name = Session::get('name');
            return view('layouts.messages.writemessage')->with('title','WRITE')->with('name', $name);
        }
    }
    public function sendMessage(){
        $redis = LRedis::connection();
        $redis->publish('message', Request::input('message'));
        Event::fire(new LoginEvent(Request::input('message')));
        return redirect('writemessage');
    }
}
