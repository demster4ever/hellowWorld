<?php

namespace App\Http\Controllers;

use Request,Session,DB;
use App\CurrPrescriptions;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Carbon\Carbon;

class CurrPrescriptionsController extends Controller
{
   
    public function index()
    {

        $prescriptions = DB::table('curr_prescriptions')
                ->where('patient_id', '=',Session::get('cur_id'))
                ->where( DB::raw('DATE(created_at)'),'=',Carbon::today())
                ->get();
        return $prescriptions;
    }

    
    public function store()
    {
        $prescription = new CurrPrescriptions();

        $prescription->patient_id = Session::get('cur_id');
        $prescription->generic =  Request::get('generic');
        $prescription->brand =  Request::get('brand');
        $prescription->dosage =  Request::get('dosage');
        $prescription->intake =  Request::get('intake') . Request::get('intakeType');
        $prescription->days =  Request::get('duration') . Request::get('durationType');
        $prescription->save();

        return $prescription;
    }

    public function destroy($id)
    {
        CurrPrescriptions::destroy($id);
    }
}
