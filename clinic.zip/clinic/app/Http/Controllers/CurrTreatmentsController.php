<?php

namespace App\Http\Controllers;

use Request,Session,DB;
use App\CurrTreatments;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Carbon\Carbon;

class CurrTreatmentsController extends Controller
{
    public function index()
    {
        $treatments = DB::table('curr_treatment')
                ->where('patient_id', '=',Session::get('cur_id'))
                ->where( DB::raw('DATE(created_at)'),'=',Carbon::today())
                ->get();
        return $treatments;
    }

    public function store()
    {
        $treatment = new CurrTreatments();

        $treatment->patient_id = Session::get('cur_id');
        $treatment->treatment =  Request::get('treatment');
        $treatment->save();

       
        return $treatment;
    }

    public function destroy($id)
    {
        CurrTreatments::destroy($id);
    }
}
