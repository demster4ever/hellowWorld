<?php

namespace App\Http\Controllers;

use App\Patients;
use App\Http\Requests;
use Carbon\Carbon;
use App\Http\Controllers\Controller;
use View, DB, Input, Redirect, Request, Session;

class BillingController extends Controller
{
   
    public function index()
    {
        $patient_id = Session::get('cur_id');

        $bill = DB::table('bill')->where('patient_id','=',$patient_id)
                                ->where( DB::raw('DATE(date)'),'=',Carbon::today())
                                ->get();

        return $bill;
    }

    public function add()
    {   
        $id = mt_rand(0000000001, 9999999999);
        $patient_id = Session::get('cur_id');
        $date = Carbon::today();
        $desc = Request::get('description');
        $amount = Request::get('amount');
        $amt = floatval($amount);

        DB::table('bill')->insert(
                    ['id' => $id,'date'=>$date, 'patient_id' => $patient_id,'charge_description' => $desc,'amount' => $amt]);

        $bill = DB::table('bill')->where('patient_id','=',$patient_id)->where('id','=',$id)
                                ->where( DB::raw('DATE(date)'),'=',Carbon::today())
                                ->get();

        return $bill;
        
    }
    
    public function delete($id)
    {
        DB::table('bill')->where('id','=',$id)->delete();
                                
    }

    public function createBillingInfo(){
        $patient_id = Session::get('cur_id');

        $remarks = Request::get('remarks');

        Session::put('remarks', $remarks);
        
        $charges = DB::table('bill')->where('patient_id','=',$patient_id)
                                ->where( DB::raw('DATE(date)'),'=',Carbon::today())
                                ->get();
                                        
        $billingid = mt_rand(0000000001, 9999999999);
        $total=0;
        if($charges){
            foreach ($charges as $amt) {
                $total=$total + (float)($amt->amount);
            }
        }

        $billingdate = Carbon::today();
        $status_id = 1;

        DB::table('billings')->insert(['id' => $billingid,
         'patient_id' => $patient_id, 'billing_date' => $billingdate,
         'billing_amount' =>  floatval($total), 'status_id'=> $status_id]);

        //return Redirect::route('nextC');
    }

    /*public function skipBillingInfo(){
        $patient_id = Session::get('cur_id');

        $remarks = Request::get('remarks');

        Session::put('remarks', $remarks);

        DB::table('bill')->where('patient_id','=',$patient_id)
                                ->where( DB::raw('DATE(date)'),'=',Carbon::today())
                                ->delete();

        return Redirect::route('nextC');
    }*/

    public function skipBillingInfo(){
        $patient_id = Session::get('cur_id');

        $remarks = Request::get('remarks');

        Session::put('remarks', $remarks);

        
        return Redirect::route('nextC');
    }


    public function payBill(){
        $amount = floatval(Request::get('amount'));
        $remarks = Request::get('remarks');

        Session::put('remarks', $remarks);

        $paid = DB::table('bills_payment')->insert(['billing_id' => Request::get('id'), 'billing_date' => Request::get('billing_date'),
                'amount_rendered' => $amount ]);
        if($paid){
             DB::table('billings')->where('id','=',Request::get('id'))->update(['status_id' => 2, 'amount_paid' =>Request::get('amount') ]);
        }

        return Redirect::route('main_index');
    }

    public function getBillingInfo(){
       $billings =  DB::table('billings')
                ->join('patients', 'billings.patient_id', '=', 'patients.patient_id')
                ->select('billings.*', 'patients.first_name', 'patients.last_name')->where('billings.status_id','=',1)

                ->get();

       return $billings;
    }

    public function getBillingInfo_paid(){
       $billings =  DB::table('billings')
                ->join('patients', 'billings.patient_id', '=', 'patients.patient_id')
                ->select('billings.*', 'patients.first_name', 'patients.last_name')->where('billings.status_id','=',2)
                ->where( DB::raw('DATE(billings.billing_date)'),'=',Carbon::today())->orWhere( DB::raw('DATE(billings.billing_date)'),'=',Carbon::today()->subDays(1))
                ->get();

       return $billings;
    }

    public function viewBillingInfo($billingid){
        // $billing =  DB::table('billings')
        //         ->join('patients', 'billings.patient_id', '=', 'patients.patient_id')
        //         ->select('billings.*', 'patients.first_name', 'patients.last_name')->where('billings.status_id','=',1)
        //         ->first();

        $billing =  DB::table('billings')->where('id','=', $billingid)->where('status_id','=',1)->first();


             
        if($billing){

            $patient = Patients::find($billing->patient_id);
            $date = $billing->billing_date;

            $bills = DB::table('bill')->where(DB::raw('DATE(date)'),'=',$date)
                ->where('patient_id', '=',$billing->patient_id)
                ->get();
            $total=0;
            foreach ($bills as $bill) {
                $total = $bill->amount + $total;
            }   
            $t =floatval($total);

            return View::make('layouts.bills.bills')->with('billing',$billing)->with('patient',$patient)->with('bills', $bills)->with('total', $t);
        }
           
         return View::make('layouts.bills.bills')->with('billing',$billing);
    }
}
