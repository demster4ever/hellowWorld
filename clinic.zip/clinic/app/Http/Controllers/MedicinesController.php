<?php

namespace App\Http\Controllers;

use View,Redirect,Log,DB,Input,Request,Session,Response;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Medicines;

class MedicinesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        if (Session::has('name')) {
                $name = Session::get('name');
        }
        return View::make('layouts.medicines.med')->with('title', 'Add Medicines')->with('name', $name)->with('mess', '');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function save()
    {
        

        $validation = Medicines::validate(Input::all());

        if($validation->fails()){
            return Redirect::route('medicines')->with('mess', 'Failed to add new medicine. Try again.')
            ->withErrors($validation)->withInput();

        }else{
            DB::table('medicines')->insert(
                ['type_of_drug' => Input::get('type_of_drug'),'category' => Input::get('category'),'generic_name' => Input::get('generic_name'),'brand_name' => Input::get('brand_name'),'dosage' => Input::get('dosage')]

                );

            return Redirect::route('medicines')->with('mess', 'Successfully added new medicine.');
        }
    }


    public function generics($term)
    {   
        
        //$term = Input::get('term');

        $data = DB::table('medicines')->select('generic_name')->where('generic_name', 'like',$term.'%')
                                      ->distinct()->take(10)->get();
        $return_array = array();
        foreach ($data as $v) {
            $return_array[]  = ['value' => $v->generic_name ];
        }

        return Response::json($return_array);
    }

    public function brands($term)
    {   
        
        
        if(!$term){
            $term = Input::get('term');
            $data = DB::table('medicines')->select('brand_name')->where('brand_name', 'like',$term.'%')
                                      ->take(10)->distinct()->get();
          }else{
            $data = DB::table('medicines')->select('brand_name')->where('generic_name', '=',$term)
                                      ->take(10)->distinct()->get();
          }
        
        $return_array = array();
        foreach ($data as $v) {
            $return_array[]  = ['value' => $v->brand_name ];
        }

        return Response::json($return_array);
    }

    public function dosage()
    {   
        
        $generic = $_GET['generic'];
        $brand = $_GET['brand'];

        $data = DB::table('medicines')->select('dosage')->where('generic_name', '=',$generic)->where('brand_name','=',$brand)
                                  ->take(10)->distinct()->get();

        $return_array = array();
        foreach ($data as $v) {
            $return_array[]  = ['value' => $v->dosage ];
        }

        return Response::json($return_array);
    }

    public function viewAllMedicines()
    {   
        
        $medicines = Medicines::all();

        return $medicines;
    }
    
    public function updateMed()
    {   
        
        $medicine = DB::table('medicines')->where('id','=',Request::get('id'))->update(['type_of_drug' =>Request::get('type'),
          'category'=>Request::get('cat'),
          'generic_name'=>Request::get('generic'),
          'brand_name'=> Request::get('brand'),
          'dosage'=>Request::get('dosage')]);

        return Redirect::route('medicines')->with('mess', 'Successfully updated medicine with ID No.'.Request::get('id'));
    }

}
