<?php

namespace App\Http\Controllers;
use App;
use View,Redirect,Log,DB,Input,Request,PDF;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Findings;

class FindingsAndTreatmentsController extends Controller
{
    public function index()
    {

        return View::make('layouts.findingstreatments.findings')->with('title', 'Add Findings');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function save()
    {
        $data = array();
        $pdf = App::make('dompdf.wrapper');
        $pdf->loadHTML('<h1>Test</h1>');
        return $pdf->stream();

        // $pdf = PDF::loadView('layouts.findingstreatments.findings', $data);
        // return $pdf->download('invoice.pdf');
        // $validation = Findings::validate(Input::all());

        // if($validation->fails()){
        //     return Redirect::route('findings')
        //     ->withErrors($validation)->withInput();

        // }else{
        //     DB::table('findings')->insert(
        //         ['findings' => Input::get('findings'),'treatments' => Input::get('treatments')]

        //         );

        //     return Redirect::route('index');
        // }
    }
}
