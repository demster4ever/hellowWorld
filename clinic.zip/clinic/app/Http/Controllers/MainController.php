<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Events\LoginEvent;
use App\Events\NewEntryEvent;
use View,DB,Session,Redirect,Event, Exemption;
use App\Users;
use Carbon\Carbon;
use App\CurrentAppointments;
use App\Patients;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;

class MainController extends Controller
{
    
    public function index()
    {
        $dt  = Carbon::now();
        $cons_id = $dt->toDateString(); 
        
        $curr_appts = CurrentAppointments::where("curr_appts_id", "=", $cons_id)->orderBy('created_at')->get();
        
        $count =  DB::table('patients')->where('current_appointments_id','=',$cons_id)
                ->where('status_id','=',1)->orWhere('status_id','=',4)->count();

        //$cnt = DB::table('curr_consultation')->count();

        $current_cons = DB::table('curr_consultation')->first();
        $current_patient =null;
        if($current_cons){
            $current_patient = DB::table('patients')->where('patient_id','=', $current_cons->patient_id)->get();
        }
        
        if (Session::has('name')) {
          
            $name = Session::get('name');
            $user_id = Session::get('id');
            $user = Users::find($user_id);
            Session::put('pWait', $count);

            $curr_consultation = DB::table('curr_consultation')
                      ->where( DB::raw('DATE(created_at)'),'=',Carbon::today())
                      ->first();
            $scheduled_patients = Patients::where('current_appointments_id','=',$cons_id)->orderBy('status_id', 'asc')->paginate(20);

/*            if($curr_consultation){

                //checking current patient inside
                $curr_patient = DB::table('patients')
                ->where('patient_id','=',$curr_consultation->patient_id)
                ->where('status_id','=',4)
                ->first();

                //saving patient to session for display purposes only
                if($curr_patient){
                  Session::put('pName', $curr_patient->last_name.', '.$curr_patient->first_name);
                }else{
                  Session::put('pName', 'NONE');
                }

                //getting the user info
                $curr_doc = DB::table('users')->where('id','=',$curr_consultation->user_id)->first();
                //saving user to session
                Session::put('dName', $curr_doc->first_name);
          
            }
            //getting all patients scheduled today & paginate by 15
            $patients = Patients::all();//where("current_appointments_id", "=", $cons_id)->get();//orderBy('created_at', 'desc')->paginate(15);
            //filtering all patients scheduled for today's checkup with a WAITING STATUS
            */
        

                //firing event notification
                //Event::fire(new LoginEvent($name, $pats->count()));

          /*return View::make('layouts.main.main_index')->with('patients',$patients)
                ->with('name',$name)->with('title', 'Main Panel')->with('pWait',$count);*/
            if($current_patient){
                 return View::make('layouts.main.main_index')->with('patients',$scheduled_patients)->with('title', 'Main Panel')->with('current_patient',  $current_patient);
            }else{
                 return View::make('layouts.main.main_index')->with('patients',$scheduled_patients)->with('title', 'Main Panel')->with('current_patient',  null);        
            }
            
        
        }else{

          return Redirect::route('index');

        }
        
    }

    public function help()
    {
        return View::make('layouts.help.help')->with('title', 'Help');
    }

}
