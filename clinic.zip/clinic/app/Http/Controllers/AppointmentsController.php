<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\CurrentAppointments;
use App\Events\ConsultationStatus;
use App\Events\LoginEvent;
use App\LabArchives;
use App\Patients;
use App\Consultation;
use View, Session,DB,Redirect,Request,Event;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class AppointmentsController extends Controller
{
    public function index()
    {
        $dt  = Carbon::now();
        $cons_id = $dt->toDateString(); 
        
        $curr_appts = DB::table('patients')->where('current_appointments_id','=',$cons_id)
        ->where('status_id','=',1)->orWhere('status_id','=',4)->get();
        $count =  DB::table('patients')->where('current_appointments_id','=',$cons_id)
        ->where('status_id','=',1)->count();

        $current_cons = DB::table('curr_consultation')->first();

        $current_patient =null;

        if($current_cons){
            $current_patient = DB::table('patients')->where('patient_id','=', $current_cons->patient_id)->get();
        }

        $name = 'User';
        $id='';
        $role_id='';
        if (Session::has('name')) {
          $name = Session::get('name');

        }
        if (Session::has('id')) {
          $id = Session::get('id');

        }
        if (Session::has('roleid')) {
          $role_id = Session::get('roleid');

        }

        if($current_patient){
            return View::make('layouts.appointments.appointments')->with('patients',$curr_appts)
                ->with('count',$count)->with('name',$name)->with('title', 'Appointments')->with('current_patient',  $current_patient);
        }else{
            return View::make('layouts.appointments.appointments')->with('patients',$curr_appts)
                ->with('count',$count)->with('name',$name)->with('title', 'Appointments')->with('current_patient',  null);      
        }

       
        
    }

    public function consult($id)
    {
        
        $patient;
        $name;
        $dt  = Carbon::today();
        $appt_id = $dt->toDateString();
         
        $patient = Patients::find($id);
        Session::put('cur_id', $id);
        if (Session::has('name')) {
          $name = Session::get('name');
        }

        $test_sub_group = DB::table('test_sub_group')
                ->join('test_group', 'test_sub_group.group_id', '=', 'test_group.id')
                ->select('test_sub_group.*', 'test_group.group_name')
                ->get();

        $test_group = DB::table('test_group')->get();

        $cons = DB::table('curr_consultation')->get();

        if($cons){
             DB::table('curr_consultation')->update(['patient_id' => $patient->patient_id, 'user_id' => 1]);
        }else{
            DB::table('curr_consultation')->insert(
            ['id'=> $appt_id,'patient_id' => $patient->patient_id, 'user_id' => 1]
            );    
        }
        

        DB::table('patients')
                ->where('patient_id', $patient->patient_id)
                ->update(['status_id' => 4]);
   
        DB::table('users')->where('id', Session::get('id'))
                            ->update(['status_id' => 0]);
        $stat = 1; 
        $pName = $patient->first_name .' '. $patient->last_name;                
        Event::fire(new ConsultationStatus($pName, $stat));
        $archives = LabArchives::where('patient_id',$id)->with('labhistory')->get();
       

        $cnt = Patients::where("current_appointments_id", "=", $appt_id)
                ->where('status_id','=',1)->count();
                Event::fire(new LoginEvent($name, $cnt));
                Session::put('pName', $pName);
        return View::make('layouts.appointments.consult')->with('patient',$patient)
                    ->with('title', $patient->last_name)
                    ->with('test_group',$test_group)
                    ->with('archives',$archives);
        
    }

    /*public function consultCurrent()
    {
        $patient;
        $name;
        $dt  = Carbon::today();
        $appt_id = $dt->toDateString();

        if (Session::has('cur_id')) {

          $id = Session::get('cur_id');
          $patient = Patients::find($id);
          
        }
        
        if (Session::has('name')) {
          $name = Session::get('name');
        }

        $test_sub_group = DB::table('test_sub_group')
                ->join('test_group', 'test_sub_group.group_id', '=', 'test_group.id')
                ->select('test_sub_group.*', 'test_group.group_name')
                ->get();

        $test_group = DB::table('test_group')->get();

        DB::table('curr_consultation')
                ->where('id', 123)
                ->update(['patient_id' => Session::get('cur_id')]);

        DB::table('patients')
                ->where('patient_id', Session::get('cur_id'))
                ->update(['status_id' => 4]);
   
        DB::table('users')->where('id', Session::get('id'))
                            ->update(['status_id' => 0]);
        $stat = 1; 
        $pName = $patient->first_name .' '. $patient->last_name;                
        Event::fire(new ConsultationStatus($pName, $stat));

        $labs = LabArchives::where('patient_id', $id)->get();

        $cnt = Patients::where("current_appointments_id", "=", $appt_id)
                ->where('status_id','=',1)->count();
                Event::fire(new LoginEvent($name, $cnt));
                Session::put('pName', $pName);
        return View::make('layouts.appointments.consult')->with('patient',$patient)
                    ->with('title', $patient->last_name)
                    ->with('test_group',$test_group)
                    ->with('labs',$labs);
    }   */

    public function doneCurrent(){

        $id = mt_rand(0000000001, 9999999999);
        $pid = Session::get('cur_id');
        $consultation = new Consultation;
        $consultation->consultation_id = $id;
        $consultation->date = Carbon::today();
        $consultation->patient_id = $pid;
        $consultation->remarks = Session::get('remarks');
        $consultation->save();

        Session::forget('remarks');

        DB::table('curr_findings')
                ->where('patient_id',$pid)
                ->where( DB::raw('DATE(created_at)'),'=',Carbon::today())
                ->update(['consultation_id' => $id]);

         DB::table('curr_treatment')
                ->where('patient_id', $pid)
                ->where( DB::raw('DATE(created_at)'),'=',Carbon::today())
                ->update(['consultation_id' => $id]);

         DB::table('curr_prescriptions')
                ->where('patient_id', $pid)
                ->where( DB::raw('DATE(created_at)'),'=',Carbon::today())
                ->update(['consultation_id' => $id]);

        DB::table('patients')
                ->where('patient_id', $pid)
                ->update(['status_id' => 3]);


        DB::table('curr_consultation')
                ->where('patient_id', $pid)
                ->delete();    

        Event::fire(new ConsultationStatus(Session::get('name'), 0));

        return Redirect::route('cur_appt');
    }

    public function markAsDone($pid){

        $id = mt_rand(0000000001, 9999999999);

        $consultation = new Consultation;
        $consultation->consultation_id = $id;
        $consultation->date = Carbon::today();
        $consultation->patient_id = $pid;
        $consultation->remarks = Session::get('remarks');
        $consultation->save();

        Session::forget('remarks');

        DB::table('curr_findings')
                ->where('patient_id',$pid)
                ->where( DB::raw('DATE(created_at)'),'=',Carbon::today())
                ->update(['consultation_id' => $id]);

         DB::table('curr_treatment')
                ->where('patient_id', $pid)
                ->where( DB::raw('DATE(created_at)'),'=',Carbon::today())
                ->update(['consultation_id' => $id]);

         DB::table('curr_prescriptions')
                ->where('patient_id', $pid)
                ->where( DB::raw('DATE(created_at)'),'=',Carbon::today())
                ->update(['consultation_id' => $id]);

        DB::table('patients')
                ->where('patient_id', $pid)
                ->update(['status_id' => 3]);


        DB::table('curr_consultation')
                ->where('patient_id', $pid)
                ->delete();    
                    
        /*DB::table('users')
                ->where('id', Session::get('id'))
                ->update(['status_id' => 0]);*/

        //Event::fire(new ConsultationStatus(Session::get('name'), 0));

        return Redirect::route('cur_appt');
    }

    public function schedulePatient(){

        $year = Request::get('year');
        $month = Request::get('month');
        $day = Request::get('day');
        $id = Request::get('id');
        $dt = Carbon::createFromFormat('Y-m-d', $year.'-'.$month.'-'.$day);
        $current_appointments_id = $dt->toDateString(); 
        $cnt = DB::table('curr_appts')->where('curr_appts_id', '=',$current_appointments_id)->count();

        if($cnt<1){
                    DB::table('curr_appts')->insert(['curr_appts_id' => $current_appointments_id]);
        }

        $patient = Patients::find($id);

        $patient->current_appointments_id = $current_appointments_id;
        $patient->status_id = 1;

        $patient->save();

        return Redirect::route('main_index');
    }

}
