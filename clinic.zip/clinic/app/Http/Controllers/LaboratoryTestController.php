<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Session,DB, Redirect,Input, Request,Log;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\TestGroup;
use App\LabTestHistory;
use App\LabArchives;

class LaboratoryTestController extends Controller
{
    
    public function index()
    {
        $test_group = DB::table('test_group')->get();
    
        if (Session::has('name')) {
          
            return view('layouts.labs.group')->with('title','Lab Tests')->with('test_group', $test_group);
        }
        else{
          return Redirect::route('index');
        }
    }

    public function subgroup()
    {
        $test_sub_group = DB::table('test_sub_group')
                ->join('test_group', 'test_sub_group.group_id', '=', 'test_group.id')
                ->select('test_sub_group.*', 'test_group.group_name')
                ->get();
        $test_group = DB::table('test_group')->get();

        if (Session::has('name')) {
          
            return view('layouts.labs.sub')->with('title','Lab Tests')->with('test_sub_group', $test_sub_group)
            ->with('test_group', $test_group);
        }
        else{

          return Redirect::route('index');

        }
    }

    public function labtest()
    {
        $test = DB::table('test')->get();
                       
        $test_sub_group = DB::table('test_sub_group')->get();

        if (Session::has('name')) {
          
            return view('layouts.labs.labtest')->with('title','Lab Tests')->with('test_sub_group', $test_sub_group)->with('test', $test);
        }
        else{

          return Redirect::route('index');

        }
    }

    public function showTests()
    {   
        $test_group = DB::table('test_group')->get();

        return $test_group;
    }

    public function showSubtest($id)
    {
         $subtest_group = DB::table('test_sub_group')->where('group_id','=',$id)->get();

         return $subtest_group;
    }

    public function showResults($id)
    {
         $results = DB::table('test')->where('sgroup_id','=',$id)->get();

         return $results;
    }

    public function showHistory($id)
    {
         $results = DB::table('lab_history')->where('labtest_id','=',$id)
                 ->where( DB::raw('DATE(created_at)'),'=',Carbon::today())
                 ->get();

         return $results;
    }

    public function showTestGroups()
    {
        $dt  = Carbon::now();
        $appt_id = $dt->toDateString(); 

        if(Session::has('cur_id')){
            $patient_id=Session::get('cur_id');
        }
         $results = DB::table('lab_archives')->where('patient_id','=',$patient_id)
                 ->where( DB::raw('DATE(created_at)'),'=',Carbon::today())
                 ->get();

         return $results;
    }

    public function saveResults()
    {

        $dt  = Carbon::now();
        $appt_id = $dt->toDateString(); 

        $inputs = Input::get('results');

        $patient_id = '';

        if(Session::has('cur_id')){
            $patient_id=Session::get('cur_id');
        }

        $labtestid = mt_rand(10000000, 99999999);

        $cnt = DB::table('lab_archives')->where('id', '=',$labtestid)->count();

        if($cnt<1){
            DB::table('lab_archives')->insert(['id' => $labtestid,'patient_id'=> $patient_id]);
        }

        foreach ($inputs as $input){ 

            DB::table('lab_history')->insert(
                    ['sgroup_id' => $input['sgroup_id'],'lab_archives_id'=>$labtestid, 'patient_id' => $patient_id,'labtest_id' => $labtestid,'test' => $input['name'],
                     'result'=> $input['result'],'units' => $input['units'],'range' => $input['range'],'date_taken' => $appt_id
                    ]);
        }

        return Redirect::route('consultC');
    }

    public function deleteHistory($id)
    {
        LabTestHistory::where('labtest_id', '=', $id)->delete();
        LabArchives::where('id', '=', $id)->delete();

    }

    public function updateTestGroup()
    {

        DB::table('test_group')->where('id','=',Request::get('test_id'))->update(
            [
            'group_name' => Request::get('group_name'),
            'group_description' => Request::get('group_description')
            ]);

        $test_group = DB::table('test_group')->get();

        return Redirect::route('group')->with('test_group', $test_group);
    }

    public function deleteTestGroup($id)
    {

        try{
            DB::table('test_group')->where('id','=',$id)->delete();
            $test_group = DB::table('test_group')->get();
            return Redirect::route('group')->with('test_group', $test_group);
        }catch (\Exception $e){

        return Redirect::route('group')
                        ->with("error_message", "Sorry can't delete item. Deleting this item may affect some tests.");
        }
    }

    

    public function updateSTestGroup()
    {

        DB::table('test_sub_group')->where('id','=',Request::get('test_id'))->update(
            [
            'name' => Request::get('sgroup_name'),
            'description' => Request::get('sgroup_description')
            ]);

        $test_sub_group = DB::table('test_sub_group')
                ->join('test_group', 'test_sub_group.group_id', '=', 'test_group.id')
                ->select('test_sub_group.*', 'test_group.group_name')
                ->get();
        $test_group = DB::table('test_group')->get();

        
        return view('layouts.labs.sub')->with('title','Lab Tests')->with('test_sub_group', $test_sub_group)
            ->with('test_group', $test_group);
    }

    public function deleteSTestGroup($id)
    {

        
        try{
             DB::table('test_sub_group')->where('id','=',$id)->delete();
             Redirect::route('sub');
        }catch (\Exception $e){

        return Redirect::route('sub')
                        ->with("error_message", "Sorry can't delete item. Deleting this item may affect detailed tests.");
        }
       
    }

    public function updateTest()
    {

        DB::table('test')->where('id','=',Request::get('test_id'))->update(
            [
            'name' => Request::get('name'),
            'description' => Request::get('description'),
            'units' => Request::get('units'),
            'range' => Request::get('range')
            ]);

        return  Redirect::route('labtest');
    }

    public function deleteTest($id)
    {
        try{
             DB::table('test')->where('id','=',$id)->delete();
             Redirect::route('labtest');
        }catch (\Exception $e){

        return Redirect::route('labtest')
                        ->with("error_message", "Sorry can't delete item. Deleting this item may affect detailed tests.");
        }
       
    }

    public function saveTempToPermanentResults()
    {

        $inputs = Input::get('results');

        $patient_id = Request::get('patient_id');
        if(Session::get('view_pat_id')){
            $patient_id = Session::get('view_pat_id');
        }

        $labtestid = mt_rand(10000000, 99999999);

        $test_group_name = Input::get('test_group_name');
        $date_taken = Input::get('date_taken');

        $cnt = DB::table('lab_archives')->where('id', '=',$labtestid)->count();

        if($cnt<1){
            DB::table('lab_archives')->insert(['id' => $labtestid,'date_taken'=> $date_taken,'patient_id'=> $patient_id,'test_group_name'=> $test_group_name]);
        }

        foreach ($inputs as $input){ 

            DB::table('lab_history')->insert(
                    ['sgroup_id' => 0,'lab_archives_id'=>$labtestid, 'patient_id' => $patient_id,'labtest_id' => $labtestid,'test' => $input['test_name'],
                     'result'=> $input['result'],'range' => $input['rangeunit']
                    ]);
             Log::info('Input from angular(test group name received: '.$input['result']. " rangeunit:" .$input['rangeunit']);
            //Saving Template if not exist

            $tnameExist = DB::table('test_templates')->select('test_name')->where('test_name','=', $input['test_name'])->get();
            if(!$tnameExist){
                 DB::table('test_templates')->insert([
                    'test_group_name' => $test_group_name, 'test_name' => $input['test_name'],
                     'result'=> "",'rangeunit' => $input['rangeunit']
                    ]);
            }
        }

        

        DB::table('temporary_test')->delete();

        return Redirect::route('patient', array('id' => $patient_id ));
    }

    public function showTemplates()
    {
        //$test_group_name = Input::get('test_group_name');
        $templates = DB::table('test_templates')->select('test_group_name')->whereNotNull('test_group_name')
                    ->distinct()->get();

         return $templates;
    }

    public function showTemplateTests()
    {
        $test_group_name = Input::get('test_group_name');
        Log::info('Input from angular(test group name received: '.$test_group_name);

       
        if(Session::get('view_pat_id')){
            $patient_id = Session::get('view_pat_id');
        }
        $test_archive_id = 999;
        //$test_group_name = "CBC";
        $templateTests = DB::table('test_templates')->where('test_group_name','=',$test_group_name)
                    ->distinct()->get();

        DB::table('temporary_test')->delete();            
        foreach ($templateTests as $test) {
                     $id = mt_rand(0000000001, 9999999999);
                     DB::table('temporary_test')->insert(
                        ['id' => $id, 'patient_id' => $patient_id,'test_archive_id' => $test_archive_id,
                        'test_group_name' => $test_group_name, 'test_name' => $test->test_name,'result' => $test->result,'rangeunit' => $test->rangeunit]);
        }

        return $templateTests;
    }

    // public function updateTest($id)
    // {

    //     DB::table('test')->where('id','=',$id)->update(
    //         [
    //         'group_name' => Request::get('group_name'),
    //         'group_description' => Request::get('group_description')
    //         ]);

    //     Redirect::route('group');
    // }

    // public function deleteTest($id)
    // {

    //     DB::table('test')->where('id','=',$id)->delete();

    //     Redirect::route('group');
    // }
}
