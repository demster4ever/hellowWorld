<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TestGroup extends Model
{
	protected $table = 'test_group'; 
	
    public function sub_group()
    {
    	return $this->hasMany('App\TestSubGroup');
    }

}
