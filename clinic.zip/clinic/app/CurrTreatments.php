<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CurrTreatments extends Model
{
    protected $table = 'curr_treatment';
	protected $fillable = ['patient_id', 'treatment'];

	public function consultation()
 	{
 		return $this->belongsTo('App\Consultation','consultation_id');
 	}
}
