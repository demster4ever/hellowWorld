<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LabTestHistory extends Model
{
    protected $table = 'lab_history';
    protected $primaryKey = 'id';
    public function archives()
	{
		return $this->belongsTo('App\LabArchives');
	}
}
