<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Validator;

class Findings extends Model
{
   public static $rules = array
   (
		'findings' => 'required|min:1:max:500'
	);

	public static function validate($data)
	{
		return Validator::make($data,static::$rules);
	}
}
