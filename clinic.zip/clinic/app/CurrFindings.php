<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CurrFindings extends Model
{
	protected $table = 'curr_findings';
	protected $fillable = ['patient_id', 'findings'];
	
    public function consultation()
 	{
 		return $this->belongsTo('App\Consultation','consultation_id');
 	}
}
