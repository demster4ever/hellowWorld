<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TempTests extends Model
{
    protected $table = 'temporary_test';
    protected $primaryKey = 'id';

}
