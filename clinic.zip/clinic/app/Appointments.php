<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Appointments extends Model
{
   protected $table = 'consultations';
   protected $primaryKey = 'consulation_id';
 
 	public function patients()
 	{
 		return $this->belongsTo('Patients');
 	}
}
