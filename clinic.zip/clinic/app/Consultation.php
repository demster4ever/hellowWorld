<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Consultation extends Model
{
    protected $table = 'consultations';
    protected $primaryKey = 'consultation_id';


	public function findings()
	{
		return $this->hasMany('App\CurrFindings');
	}

	public function treatments()
	{
		return $this->hasMany('App\CurrTreatments');
	}

	public function prescriptions()
	{
		return $this->hasMany('App\CurrPrescriptions');
	}


}
