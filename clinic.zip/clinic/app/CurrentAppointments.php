<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CurrentAppointments extends Model
{
	protected $table = 'curr_appts';
    protected $primaryKey = 'curr_appts_id';

    public function patients()
    {
    	return $this->hasMany('App\Patients');
    }
}
