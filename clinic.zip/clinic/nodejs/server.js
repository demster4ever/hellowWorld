 
// var app = require('express')();
// var server = require('http').Server(app);
// var io = require('socket.io')(server);
// var redis = require('redis');
 
// server.listen(6379);
// io.on('connection', function (socket) {
 
//   console.log("new client connected");
//   var redisClient = redis.createClient();
//   redisClient.subscribe('message');
 
//   redisClient.on("message", function(channel, message) {
//     console.log("mew message in queue "+ message + "channel");
//     socket.emit(channel, message);
//   });
 
//   socket.on('disconnect', function() {
//     redisClient.quit();
//   });
 
// });

var mongo = require('mongodb').MongoClient,
  client = require('socket.io').listen(8080).sockets;


// mongo.connect('mongodb://127.0.0.1/chat', function(err,db){

//   if(err) throw err;

  

// });
  
client.on('connection',function(socket){
    socket.on('input', function(data){

    })
  }); 